.. _MEP-index:

################################
Matplotlib Enhancement Proposals
################################

.. htmlonly::

   :Release: |version|
   :Date: |today|

.. toctree::
   :maxdepth: 1

   template
   MEP08
   MEP09
   MEP10
   MEP11
   MEP12
   MEP13
   MEP14
   MEP15
   MEP19
   MEP21
   MEP22
   MEP23
   MEP24
   MEP25
   MEP26
   MEP27
