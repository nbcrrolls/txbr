For changes which require an entry in `api_changes.rst` please create
a file in this folder with the name :file:`YYYY-MM-DD-[initials].rst`
(ex :file:`2014-07-31-TAC.rst`) with contents following the form: ::

    Brief description of change
    ```````````````````````````

    Long description of change, justification, and work-arounds to
    maintain old behavior (if any).
