***********
patheffects
***********


:mod:`matplotlib.patheffects`
=============================

.. automodule:: matplotlib.patheffects
   :members:
   :undoc-members:
   :show-inheritance:
