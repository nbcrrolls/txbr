******
ticker
******


:mod:`matplotlib.ticker`
========================

.. automodule:: matplotlib.ticker
   :members:
   :undoc-members:
   :show-inheritance:
