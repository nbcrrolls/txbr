*****
lines
*****


:mod:`matplotlib.lines`
=======================

.. automodule:: matplotlib.lines
   :members:
   :undoc-members:
   :show-inheritance:
