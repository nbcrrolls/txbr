
# THIS FILE IS GENERATED FROM SCIPY SETUP.PY
short_version = '0.11.0'
version = '0.11.0'
full_version = '0.11.0'
git_revision = '827679b6f0149abb2c0e121749887012946b99c3'
release = True

if not release:
    version = full_version
