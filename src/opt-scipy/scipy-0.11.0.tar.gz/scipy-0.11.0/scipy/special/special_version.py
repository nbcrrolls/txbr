major = 0
minor = 4
micro = 9
release_level = 'beta'


special_version = '%(major)d.%(minor)d.%(micro)d' % (locals ())
