===================
Physical quantities
===================

.. automodule:: sympy.physics.unitsystems.quantities

.. autoclass:: Quantity
   :members:
