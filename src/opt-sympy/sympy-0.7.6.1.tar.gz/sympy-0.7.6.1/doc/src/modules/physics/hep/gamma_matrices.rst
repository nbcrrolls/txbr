High energy physics
===================

.. module:: sympy.physics.hep.gamma_matrices

.. autoclass:: sympy.physics.hep.gamma_matrices._LorentzContainer
    :members:

.. autoclass:: sympy.physics.hep.gamma_matrices.GammaMatrixHead
    :members:
