======
Qapply
======

.. automodule:: sympy.physics.quantum.qapply
   :members:
