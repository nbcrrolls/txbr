================================
Dimensions and dimension systems
================================

.. automodule:: sympy.physics.unitsystems.dimensions

.. autoclass:: Dimension
   :members:

.. autoclass:: DimensionSystem
   :members:
