=========
Decorator
=========

.. automodule:: sympy.utilities.decorator
   :members:
