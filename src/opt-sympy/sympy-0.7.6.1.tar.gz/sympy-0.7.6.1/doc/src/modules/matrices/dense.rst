Dense Matrices
==============

Matrix Class Reference
----------------------

.. autoclass:: sympy.matrices.dense.MutableDenseMatrix
   :members:

ImmutableMatrix Class Reference
-------------------------------

.. autoclass:: sympy.matrices.immutable.ImmutableMatrix
   :members:
   :noindex:
