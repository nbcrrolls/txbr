Vector for Geometric Algebra
============================

.. module:: sympy.galgebra.vector

Class Reference
---------------

.. autoclass:: Vector
   :members:

Function Reference
------------------

.. autofunction:: flatten

.. autofunction:: TrigSimp
