Debug code for Geometric Algebra
================================

.. module:: sympy.galgebra.debug

Function Reference
------------------

.. autofunction:: ostr

.. autofunction:: oprint

.. autofunction:: print_product_table

.. autofunction:: print_sub_table
