import os,sys,platform,re
from distutils.core import setup, Extension
from Pyrex.Distutils import build_ext

if '--gpu' in sys.argv: buildGPUCode = True
else: buildGPUCode = False

system = platform.system()
node = platform.node()

imod_dir = os.environ['IMOD']
txbr_dir = os.environ['TXBR']

import numpy
numpy_dir_include = sys.modules['numpy'].__path__[0] + '/core/include'

imod_dir_include = 'txbr/include/imod'
txbr_dir_include = 'txbr/include/txbr'
pxd_dir_include = 'txbr/include/pxd'

imod_dir_lib = imod_dir + '/lib'
txbr_dir_lib = txbr_dir + '/lib'

mrc = Extension( 'mrc.mrcfile',
                 include_dirs = [imod_dir_include, txbr_dir_include, numpy_dir_include],
                 libraries = ['tiff', 'iimod', 'imod', 'cfshr'],
                 library_dirs = [ imod_dir_lib],
                 sources = ['txbr/mrc/mrcfile.c','txbr/mrc/txbrstack.c','txbr/util/util_C/txbrutil.c']
                 )

imodel = Extension( 'modl.modfile',
                 include_dirs = [imod_dir_include, txbr_dir_include, numpy_dir_include],
                 libraries = [ 'tiff', 'iimod', 'imod', 'cfshr' ],
                 library_dirs = [ imod_dir_lib ],
                 sources = ['txbr/modl/modfile.c']
                 )

filter = Extension( 'txbr.filter.filter',
                 include_dirs = [imod_dir_include, txbr_dir_include],
                 libraries = [ 'iimod', 'imod', 'cfshr', 'txbrutil' ],
                 library_dirs = [ imod_dir_lib, txbr_dir_lib ],
                 sources = ['txbr/txbr/filter/3D/filter.c','txbr/txbr/filter/3D/filter_3D.c','txbr/txbr/filter/3D/txbrtraj.c']
                 )

contres = Extension("txbr.align.residualSupp",
                    sources = ["txbr/txbr/align/residualSupp.pyx"],
                    include_dirs = [ numpy.get_include(), pxd_dir_include ]
                    )

preconstruction = Extension("txbr.prefil",
                    include_dirs = [imod_dir_include, txbr_dir_include],
                    libraries = [ 'iimod', 'imod', 'cfshr', 'fftw3', 'fftw3f', 'cv', 'cxcore' ],
                    library_dirs = [ imod_dir_lib, ],
                    sources = ["txbr/txbr/filter/run_prefil.c","txbr/txbr/filter/filter_1D.c","txbr/txbr/filter/utilities.c","txbr/txbr/filter/utilities_base.c","txbr/txbr/filter/edgetaper_2D.c"],
                    extra_compile_args = ["-std=gnu99"]
                    )

backprojection_0 = Extension("txbr.bckprj",
                 sources = ['txbr/txbr/bckprj/run_bckprj.c','txbr/txbr/bckprj/back.0/backprojection.0.c',
                            'txbr/util/util_C/txbrutil.c','txbr/txbr/utilities/util_C/txbrtext.c',
                            'txbr/mrc/txbrstack.c'],
                 include_dirs = [imod_dir_include, txbr_dir_include],
                 libraries = [ 'iimod', 'imod', 'cfshr' ],
                 library_dirs = [ imod_dir_lib],
                 extra_compile_args = ['-ffast-math','-O3']
                 )

backprojection_1 = Extension("txbr.bckprj",
                 sources = ['txbr/txbr/bckprj/run_bckprj.c','txbr/txbr/bckprj/back.f/backprojection.f.c',
                            'txbr/util/util_C/txbrutil.c','txbr/txbr/utilities/util_C/txbrtext.c',
                            'txbr/mrc/txbrstack.c'],
                 include_dirs = [imod_dir_include, txbr_dir_include],
                 libraries = [ 'iimod', 'imod', 'cfshr' ],
                 library_dirs = [ imod_dir_lib],
                 extra_compile_args = ['-fno-math-errno','-ffast-math','-O3']
                 )

backprojection_2 = Extension("txbr.bckprj",
                 sources = ['txbr/txbr/bckprj/run_bckprj.c','txbr/txbr/bckprj/back.2/backprojection.2.c',
                            'txbr/txbr/bckprj/back.2/calculateBox.c',
                            'txbr/txbr/bckprj/back.2/initializeGPU.c', 'txbr/txbr/bckprj/back.2/evaluateSegmentGPU.c',
                            'txbr/txbr/bckprj/back.2/backprojectionGPUsupport.c',
                            'txbr/util/util_C/txbrutil.c', 'txbr/txbr/utilities/util_C/txbrtext.c',
                            'txbr/mrc/txbrstack.c'],
                 include_dirs = [imod_dir_include, txbr_dir_include ],
                 libraries = [ 'iimod', 'imod', 'cfshr'],
                 library_dirs = [ imod_dir_lib],
                 )

backprojection_cu2 = Extension("txbr.bckprj_cu",
                 sources = ['txbr/txbr/bckprj/run_bckprj_cuda.c','txbr/txbr/bckprj/back.cu.2/backprojection.2.c',
                            'txbr/txbr/bckprj/back.cu.2/calculateBox.c',
                            'txbr/util/util_C/txbrutil.c', 'txbr/txbr/utilities/util_C/txbrtext.c',
                            'txbr/mrc/txbrstack.c'],
		         extra_objects = ['txbr/txbr/bckprj/back.cu.2/backprojectionGPUsupport.o'],
                 include_dirs = [imod_dir_include, txbr_dir_include],
                 libraries = [ 'iimod', 'imod', 'cfshr','cudart'],
                 library_dirs = [ imod_dir_lib,'/usr/local/cuda/lib'],
                 )

combine = Extension("txbr.combine",
                 sources = ['txbr/txbr/combine/combine.c','txbr/txbr/combine/merge.c',
                            'txbr/txbr/combine/crossval.c', 'txbr/util/util_C/txbrutil.c' ],
                 include_dirs = [imod_dir_include, txbr_dir_include ],
                 libraries = [ 'iimod', 'imod', 'cfshr' ],
                 library_dirs = [ imod_dir_lib, ],
                 )

remap = Extension( "misc.remap.remapSupp",
                    sources = [ "txbr/misc/remap/remapSupp.pyx" ],
                    include_dirs = [ numpy.get_include(), pxd_dir_include ]
                    )

ginac_plug = Extension( "util.ginacplug",
                        sources = [ "txbr/util/ginacplug.cc" ],
                        include_dirs = [ numpy.get_include() ],
                        libraries = [ 'cln' ]
                        )

backproj_cpu = backprojection_1
backproj_gpu = backprojection_cu2

# Setup the TxBR pakage

scripts_ = [ 'scripts/runtxbr.py', \
             'scripts/txbr_align.py', \
             'scripts/txbr_filter.py', \
             'scripts/txbr_pitch.py', \
             'scripts/txbr_bckprj.py', \
             'scripts/txbr_finalize_bckprj.py', \
             'scripts/txbr_test.py', \
             'scripts/txbr_view.py', \
             'scripts/txbr_flatten.py', \
             'scripts/txbr_stack.py', \
             'scripts/txbr_combine.py', \
             'scripts/txbr_proj.py', \
             'scripts/txbr_clean.py', \
             'scripts/fidtrans.py', \
             'scripts/remap_4000#2.py', \
             'scripts/plot_boundaries.py', \
            ]

packages_ = [ 'txbr', \
              'txbr.align', \
              'txbr.filter', \
              'txbr.setup', \
              'txbr.stack', \
              'txbr.utilities', \
              'modl', \
              'util', \
              'mrc', \
              'misc', \
              'misc.remap', \
              'misc.series' ]

package_dir_ = { 'txbr':'txbr/txbr', \
                 'modl':'txbr/modl', \
                 'util':'txbr/util', \
                 'mrc':'txbr/mrc', \
                 'misc':'txbr/misc'}

package_data_ = {'txbr': ['log.conf','txbr.cfg'],'misc.remap': ['log.conf']}

data_files_ = [('config',['data/machinefile.gpu.txt','data/machinefile.mpi.txt'])]

ext_modules_ = [ mrc, imodel, contres, backproj_cpu, combine, preconstruction, remap, ginac_plug]

if buildGPUCode:
    
    if len(sys.argv)>1 and sys.argv[1]=='clean':
        os.system('make --directory=./txbr/txbr/bckprj/cuda clean')
        os.system('make --directory=./txbr/txbr/bckprj/back.cu.2 clean')
        
    if len(sys.argv)>1 and ( sys.argv[1].startswith('build') or sys.argv[1]=='install' ):
        os.system('make --directory=./txbr/txbr/bckprj/cuda')
        os.system('make --directory=./txbr/txbr/bckprj/back.cu.2')
        
    ext_modules_.append(backproj_gpu)
    

setup(
       name = 'TxBR',
       version = '3.0.0',
       description = 'TxBR is an Electron Tomography package',
       author = ['Sebastien Phan','Alexander Ward Kulungowski','Raj Singh','Masako Terada','James Obayashi'],
       scripts = scripts_,
       packages = packages_,
       package_dir = package_dir_,
       package_data = package_data_,
       data_files = data_files_,
       ext_modules = ext_modules_,
       cmdclass = {'build_ext': build_ext}
    )
