import platform,os,shutil

system = platform.system()
node = platform.node()

setup_file = 'setup.cfg'

if os.path.lexists(setup_file): os.unlink(setup_file)

if system=='Darwin':
    os.symlink('./config/setup.cfg.darwin',setup_file)
elif system=='Linux' and node=='login-4-0.local':
    os.symlink('./config/setup.cfg.linux.triton',setup_file)
elif system=='Linux' and node=='calit2-137-110-111-67.ucsd.edu':
    os.symlink('./config/setup.cfg.linux.gpu',setup_file)
elif system=='Linux':
    os.symlink('./config/setup.cfg.linux',setup_file)
    
    
if node=='calit2-137-110-111-67.ucsd.edu':
    shutil.copyfile('./config/machinefile.gpu.137.110.111.67.txt', './data/machinefile.gpu.txt')
