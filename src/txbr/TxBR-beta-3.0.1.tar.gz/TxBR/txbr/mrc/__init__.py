"""mcr -- MRC package.

Package allowing to manipulate MRC files.
"""

from mrc import *
from vimrc import *
from mrcfile import *