#include <Python.h>
#include <numpy/arrayobject.h>

#include "txbrutil.h"
#include "mrcslice.h"

int get_size_of(char* mrcFileName, int *nx, int *ny, int *nz);
int get_mode_of(char* mrcFileName, int *mode);
int get_description_of(char* mrcFileName, int *nlabels, char** labels);
int get_statistics_of(char* mrcFileName, float *m0, float *m1, float *m2, float *min, float *max);

static PyObject *mrc_size(PyObject *self, PyObject *args) {

    char *fileName;

	if (!PyArg_ParseTuple(args, "s", &fileName)) return NULL;

    int sts, nx=0, ny=0, nz=0;

    sts = get_size_of(fileName, &nx, &ny, &nz);

	if (sts!=NO_ERROR) return NULL;

    return Py_BuildValue( "(i,i,i)", nx, ny, nz );

}

static PyObject *mrc_mode(PyObject *self, PyObject *args) {

    char *fileName;

	if (!PyArg_ParseTuple(args, "s", &fileName)) return NULL;

    int sts, mode=0;

    sts = get_mode_of(fileName, &mode);

	if (sts!=NO_ERROR) return NULL;

    return Py_BuildValue( "i", mode );

}

static PyObject *mrc_description(PyObject *self, PyObject *args) {

    char *fileName;

	if (!PyArg_ParseTuple(args, "s", &fileName)) return NULL;

	int sts,i,nlabels;
	char *labels[MRC_NLABELS];

	for (i=0;i<MRC_NLABELS;i++) {
		labels[i]  = (char *)malloc((MRC_LABEL_SIZE+1)*sizeof(char));
	}

    sts = get_description_of(fileName, &nlabels, &labels);

    PyObject *description = PyList_New(nlabels);

    for (i=0;i<nlabels;i++) {
		PyList_SetItem(description,i,PyString_FromString(labels[i]));
		free(labels[i]);
	}

	if (sts!=NO_ERROR) return NULL;

    return description;

}

static PyObject *mrc_stats(PyObject *self, PyObject *args) {

    char *fileName;

	if (!PyArg_ParseTuple(args, "s", &fileName)) return NULL;

    int sts;
    float m0=0, m1=0, m2=0, min=0, max=0;

    sts = get_statistics_of(fileName, &m0, &m1, &m2, &min, &max);

	if (sts!=NO_ERROR) return NULL;

    return Py_BuildValue( "(f,f,f,f,f)", m0, m1, m2, min, max );

}


static PyObject *update_header(PyObject *self, PyObject *args) {

    char *fileName;
    PyObject *stats;

	if (!PyArg_ParseTuple(args, "sO", &fileName, &stats)) return NULL;

	MrcHeader *input_file_header  = (MrcHeader *)malloc(sizeof(MrcHeader));
	FILE* input_file;

	if (!input_file_header) {
		txbr_error(stderr, "ERROR: read_slice - getting memory.\n");
		return NULL;
	}

	if ((input_file = fopen(fileName,"r+"))==NULL) {
		txbr_error(stderr, "ERROR: read_slice - cannot open file %s.\n", fileName);
		return NULL;
	}

	mrc_head_read(input_file,input_file_header);

    int sts=NO_ERROR;

    float m0=0, m1=0, m2=0, min=0, max=0;

	if (PyDict_Check(stats)) {
		m0 =  (float)PyFloat_AsDouble(PyDict_GetItemString(stats,"m0"));
		m1 =  (float)PyFloat_AsDouble(PyDict_GetItemString(stats,"mean"));
		m2 =  (float)PyFloat_AsDouble(PyDict_GetItemString(stats,"m2"));
		min =  (float)PyFloat_AsDouble(PyDict_GetItemString(stats,"min"));
		max =  (float)PyFloat_AsDouble(PyDict_GetItemString(stats,"max"));
	} else {
		sts = get_statistics_of(fileName, &m0, &m1, &m2, &min, &max);
	}

    input_file_header->amean = m1;
    input_file_header->amin = min;
    input_file_header->amax = max;

    mrc_head_write(input_file,input_file_header);

	if (fclose(input_file)) {
		txbr_error(stderr, "ERROR: write_slice - closing file %s.\n", &input_file[0]);
		return NULL;
	}

	free(input_file_header);

	if (sts!=NO_ERROR) return NULL;

	return Py_BuildValue( "(f,f,f)", min, m0, max );

}


static PyObject *create_header(PyObject *self, PyObject *args) {

    char *fileName;
    int nx=0, ny=0, nz=0, mode = MRC_MODE_FLOAT;

	if (!PyArg_ParseTuple(args, "siiii", &fileName, &nx, &ny, &nz, &mode)) return NULL;

	FILE* input_file;

	if ((input_file = fopen(fileName,"w+"))==NULL) {
		txbr_error(stderr, "ERROR: write_header - cannot open file %s.\n", fileName);
		return NULL;
	}

	MrcHeader *input_file_header  = (MrcHeader *)malloc(sizeof(MrcHeader));

	if (!input_file_header) {
		txbr_error(stderr, "ERROR: write_header - getting memory.\n");
		return NULL;
	}

	mrc_head_new(input_file_header, nx, ny, nz, mode);

	mrc_head_write(input_file, input_file_header);

	//mrc_data_new(input_file, input_file_header);

	if (fclose(input_file)) {
		txbr_error(stderr, "ERROR: write_header - closing file %s.\n", &input_file[0]);
		return NULL;
	}

	free(input_file_header);

	return Py_BuildValue( "i", 1 );

}


static PyObject *create_header_from(PyObject *self, PyObject *args) {

    char *fileName, *tplFileName;

	if (!PyArg_ParseTuple(args, "ss", &fileName, &tplFileName)) return NULL;

	MrcHeader *tpl_file_header  = (MrcHeader *)malloc(sizeof(MrcHeader));

	if (!tpl_file_header) {
		txbr_error(stderr, "ERROR: create_header_from - getting memory.\n");
		return NULL;
	}

	FILE* template_file;

	if ((template_file = fopen(tplFileName,"r"))==NULL) {
		txbr_error(stderr, "ERROR: create_header_from - cannot open template file %s.\n", tplFileName);
		return NULL;
	}

	mrc_head_read(template_file, tpl_file_header);

	if (fclose(template_file)) {
		txbr_error(stderr, "ERROR: create_header_from - closing template file %s.\n", tplFileName);
		return NULL;
	}

	FILE* file;

	if ((file = fopen(fileName,"w+"))==NULL) {
		txbr_error(stderr, "ERROR: create_header_from - cannot open new file %s.\n", fileName);
		return NULL;
	}

	mrc_head_write(file, tpl_file_header);
	mrc_data_new(file, tpl_file_header);

	if (fclose(file)) {
		txbr_error(stderr, "ERROR: create_header_from - closing new file %s.\n", fileName);
		return NULL;
	}

	free(tpl_file_header);

	return Py_BuildValue( "i", 1 );

}


static PyObject *read_slice(PyObject *self, PyObject *args) {

    char *fileName, *axis;
    int slice = 0;

	if (!PyArg_ParseTuple(args, "ssi", &fileName, &axis, &slice)) return NULL;

	MrcHeader *input_file_header  = (MrcHeader *)malloc(sizeof(MrcHeader));
	FILE* input_file;

	if (!input_file_header) {
		txbr_error(stderr, "ERROR: read_slice - getting memory.\n");
		return NULL;
	}

	if ((input_file = fopen(fileName,"rbe"))==NULL) {
		txbr_error(stderr, "ERROR: read_slice - cannot open file %s.\n", fileName);
		return NULL;
	}

	mrc_head_read(input_file,input_file_header);

	int nx = input_file_header->nx;
	int ny = input_file_header->ny;
	int nz = input_file_header->nz;

	int n1,n2;

	switch (axis[0]) {

		case 'x':
		case 'X':
			n1 = ny;
			n2 = nz;
			if (slice >= nx) return NULL;
		break;

		case 'y':
		case 'Y':
			n1 = nx;
			n2 = nz;
			if (slice >= ny) return NULL;
		break;

		case 'z':
		case 'Z':
			n1 = nx;
			n2 = ny;
			if (slice >= nz) return NULL;
		break;

		default:
			txbr_error(stderr, "ERROR: mrc_slice - axis error.\n");
			return NULL;

	}

	PyArrayObject *array = NULL;

	int i,j,k,index = 0;

//	char* c_array_buffer = NULL;
	unsigned char* uc_array_buffer = NULL;
	short* s_array_buffer = NULL;
	float* f_array_buffer = NULL;
	unsigned short* us_array_buffer = NULL;

	if (input_file_header->mode==SLICE_MODE_BYTE) {

		npy_intp dimensions[2] = { n1, n2 };
		array = PyArray_SimpleNew(2, dimensions, PyArray_DOUBLE);
		char *data = (char *)PyArray_DATA(array);

		uc_array_buffer = (unsigned char*)mrc_mread_slice(input_file, input_file_header, slice, axis[0]);

		for (j=0; j<dimensions[1]; j++) {
			for (i=0; i<dimensions[0]; i++) {
				*(double *)(data + i*array->strides[0] + j*array->strides[1]) = uc_array_buffer[index++];
			}
		}

	}

	if (input_file_header->mode==SLICE_MODE_SHORT) {

		npy_intp dimensions[2] = { n1, n2 };
		array = PyArray_SimpleNew(2, dimensions, PyArray_DOUBLE);
		char *data = (char *)PyArray_DATA(array);

		s_array_buffer = (short*)mrc_mread_slice(input_file, input_file_header, slice, axis[0]);

		for (j=0; j<dimensions[1]; j++) {
			for (i=0; i<dimensions[0]; i++) {
				*(double *)(data + i*array->strides[0] + j*array->strides[1]) = s_array_buffer[index++];
			}
		}

	}

	if (input_file_header->mode==SLICE_MODE_FLOAT) {

		npy_intp dimensions[2] = { n1, n2 };
		array = PyArray_SimpleNew(2, dimensions, PyArray_DOUBLE);
		char *data = (char *)PyArray_DATA(array);

		f_array_buffer = (float*)mrc_mread_slice(input_file, input_file_header, slice, axis[0]);

		for (j=0; j<dimensions[1]; j++) {
			for (i=0; i<dimensions[0]; i++) {
				*(double *)(data + i*array->strides[0] + j*array->strides[1]) = f_array_buffer[index++];
			}
		}

	}

	if (input_file_header->mode==SLICE_MODE_COMPLEX_SHORT) {

		npy_intp dimensions[2] = { n1, n2 };
		array = PyArray_SimpleNew(2, dimensions, PyArray_CDOUBLE);
		char *data = (char *)PyArray_DATA(array);

		s_array_buffer = (short*)mrc_mread_slice(input_file, input_file_header, slice, axis[0]);

		for (j=0; j<dimensions[1]; j++) {
			for (i=0; i<dimensions[0]; i++) {
				*(double *)(data + i*array->strides[0] + j*array->strides[1]) = s_array_buffer[index++];
				*(double *)(data + i*array->strides[0] + j*array->strides[1] + sizeof(double)) = s_array_buffer[index++];
			}
		}

	}

	if (input_file_header->mode==SLICE_MODE_COMPLEX_FLOAT) {

		npy_intp dimensions[2] = { n1, n2 };
		array = PyArray_SimpleNew(2, dimensions, PyArray_CDOUBLE);
		char *data = (char *)PyArray_DATA(array);

		f_array_buffer = (float*)mrc_mread_slice(input_file, input_file_header, slice, axis[0]);

		for (j=0; j<dimensions[1]; j++) {
			for (i=0; i<dimensions[0]; i++) {
				*(double *)(data + i*array->strides[0] + j*array->strides[1]) = f_array_buffer[index++];
				*(double *)(data + i*array->strides[0] + j*array->strides[1] + sizeof(double)) = f_array_buffer[index++];
			}
		}

	}

	if (input_file_header->mode==SLICE_MODE_USHORT) {

		npy_intp dimensions[2] = { n1, n2 };
		array = PyArray_SimpleNew(2, dimensions, PyArray_DOUBLE);
		char *data = (char *)PyArray_DATA(array);

		us_array_buffer = (unsigned short*)mrc_mread_slice(input_file, input_file_header, slice, axis[0]);

		for (j=0; j<dimensions[1]; j++) {
			for (i=0; i<dimensions[0]; i++) {
				*(double *)(data + i*array->strides[0] + j*array->strides[1]) = us_array_buffer[index++];
			}
		}

	}

	if (input_file_header->mode==SLICE_MODE_RGB) {

		npy_intp dimensions[3] = { n1, n2, 3 };
		array = PyArray_SimpleNew(3, dimensions, PyArray_UBYTE);
		char *data = (char *)PyArray_DATA(array);

		uc_array_buffer = (unsigned char*)mrc_mread_slice(input_file, input_file_header, slice, axis[0]);

		for (j=0; j<dimensions[1]; j++) {
			for (i=0; i<dimensions[0]; i++) {
				for (k=0; k<dimensions[2]; k++) {
					*(unsigned char *)(data + i*array->strides[0] + j*array->strides[1] + k*array->strides[2]) = uc_array_buffer[index++];
				}
			}
		}

	}

	if (fclose(input_file)) {
		txbr_error(stderr, "ERROR: read_slice - closing file %s.\n", &input_file[0]);
		return NULL;
	}

	if (input_file_header->mode==SLICE_MODE_BYTE) free(uc_array_buffer);
	if (input_file_header->mode==SLICE_MODE_SHORT) free(s_array_buffer);
	if (input_file_header->mode==SLICE_MODE_FLOAT) free(f_array_buffer);
	if (input_file_header->mode==SLICE_MODE_COMPLEX_SHORT) free(f_array_buffer);
	if (input_file_header->mode==SLICE_MODE_COMPLEX_FLOAT) free(f_array_buffer);
	if (input_file_header->mode==SLICE_MODE_USHORT) free(us_array_buffer);
	if (input_file_header->mode==SLICE_MODE_RGB) free(uc_array_buffer);

	free(input_file_header);

	if (array==NULL) return NULL;

    return PyArray_Return(array);

}

static PyObject *write_slice(PyObject *self, PyObject *args) {

    char *fileName, *axis;
    int slice = 0;

    PyArrayObject *array;

    if (!PyArg_ParseTuple(args, "ssiO", &fileName, &axis, &slice, &array)) return NULL;

//    if (array->nd!=2) {
//    	PyErr_SetString(PyExc_ValueError, "Array must be two-dimensional!");
//    	return NULL;
//    }
//
//    if ( array->descr->type_num!=PyArray_FLOAT && array->descr->type_num!=PyArray_DOUBLE) {
//    	PyErr_SetString(PyExc_ValueError, "Array must be of type float");
//    	return NULL;
//    }

	MrcHeader *input_file_header  = (MrcHeader *)malloc(sizeof(MrcHeader));
	FILE* input_file;

	if (!input_file_header) {
		txbr_error(stderr, "ERROR: write_slice - getting memory.\n");
		return NULL;
	}

	if ((input_file = fopen(fileName,"r+"))==NULL) {
		txbr_error(stderr, "ERROR: openMRCFile - cannot open file %s.\n", fileName);
		return NULL;
	}

	mrc_head_read(input_file,input_file_header);

	int n1,n2,length = 0;
	int nx = input_file_header->nx;
	int ny = input_file_header->ny;
	int nz = input_file_header->nz;
	int mode = input_file_header->mode;

	switch (axis[0]) {

		case 'x':
		case 'X':
			n1 = ny;
			n2 = nz;
			if (slice >= nx) return NULL;
		break;

		case 'y':
		case 'Y':
			n1 = nx;
			n2 = nz;
			if (slice >= ny) return NULL;
		break;

		case 'z':
		case 'Z':
			n1 = nx;
			n2 = ny;
			if (slice >= nz) return NULL;
		break;

		default:
			txbr_error(stderr, "ERROR: write_slice - axis error.\n");
			return NULL;

	}

	length = n1*n2;

	int i,j,k;

	unsigned char* uc_array_buffer = NULL;
	char* c_array_buffer = NULL;
	short* s_array_buffer = NULL;
	float* f_array_buffer = NULL;
	unsigned short* us_array_buffer = NULL;

	if (mode==SLICE_MODE_BYTE) {

		uc_array_buffer  = (float *)malloc(length*sizeof(short));

		if (!uc_array_buffer) {
			txbr_error(stderr, "ERROR: write_slice - getting memory.\n");
			return NULL;
		}

		if ( array->descr->type_num==PyArray_FLOAT ) {
			int index = 0;
			for (j=0; j<array->dimensions[1]; j++) {
				for (i=0; i<array->dimensions[0]; i++) {
					uc_array_buffer[index++] = *(unsigned char *)(array->data + i*array->strides[0] + j*array->strides[1]);
				}
			}
		}

		if ( array->descr->type_num==PyArray_DOUBLE ) {
			int index = 0;
			for (j=0; j<array->dimensions[1]; j++) {
				for (i=0; i<array->dimensions[0]; i++) {
					uc_array_buffer[index++] = (unsigned char)*(double *)(array->data + i*array->strides[0] + j*array->strides[1]);
				}
			}
		}

		mrc_write_slice(&uc_array_buffer[0], input_file, input_file_header, slice, axis[0]);

	}


	if (mode==SLICE_MODE_SHORT) {

		s_array_buffer  = (float *)malloc(length*sizeof(short));

		if (!s_array_buffer) {
			txbr_error(stderr, "ERROR: write_slice - getting memory.\n");
			return NULL;
		}

		if ( array->descr->type_num==PyArray_FLOAT ) {
			int index = 0;
			for (j=0; j<array->dimensions[1]; j++) {
				for (i=0; i<array->dimensions[0]; i++) {
					s_array_buffer[index++] = *(short *)(array->data + i*array->strides[0] + j*array->strides[1]);
				}
			}
		}

		if ( array->descr->type_num==PyArray_DOUBLE ) {
			int index = 0;
			for (j=0; j<array->dimensions[1]; j++) {
				for (i=0; i<array->dimensions[0]; i++) {
					s_array_buffer[index++] = (short)*(double *)(array->data + i*array->strides[0] + j*array->strides[1]);
				}
			}
		}

		mrc_write_slice(&s_array_buffer[0], input_file, input_file_header, slice, axis[0]);

	}

	if (mode==SLICE_MODE_FLOAT) {

		f_array_buffer  = (float *)malloc(length*sizeof(float));

		if (!f_array_buffer) {
			txbr_error(stderr, "ERROR: write_slice - getting memory.\n");
			return NULL;
		}

		if ( array->descr->type_num==PyArray_FLOAT ) {
			int index = 0;
			for (j=0; j<array->dimensions[1]; j++) {
				for (i=0; i<array->dimensions[0]; i++) {
					f_array_buffer[index++] = *(float *)(array->data + i*array->strides[0] + j*array->strides[1]);
				}
			}
		}

		if ( array->descr->type_num==PyArray_DOUBLE ) {
			int index = 0;
			for (j=0; j<array->dimensions[1]; j++) {
				for (i=0; i<array->dimensions[0]; i++) {
					f_array_buffer[index++] = (float)*(double *)(array->data + i*array->strides[0] + j*array->strides[1]);
				}
			}
		}

		mrc_write_slice(&f_array_buffer[0], input_file, input_file_header, slice, axis[0]);

	}

	if (mode==SLICE_MODE_COMPLEX_SHORT) {

		s_array_buffer  = (float *)malloc(length*sizeof(short));

		if (!s_array_buffer) {
			txbr_error(stderr, "ERROR: write_slice - getting memory.\n");
			return NULL;
		}

		if ( array->descr->type_num==PyArray_CFLOAT ) {
			int index = 0;
			for (j=0; j<array->dimensions[1]; j++) {
				for (i=0; i<array->dimensions[0]; i++) {
					s_array_buffer[index++] = *(short *)(array->data + i*array->strides[0] + j*array->strides[1]);
					s_array_buffer[index++] = *(short *)(array->data + i*array->strides[0] + j*array->strides[1] + sizeof(float));
				}
			}
		}

		if ( array->descr->type_num==PyArray_CDOUBLE ) {
			int index = 0;
			for (j=0; j<array->dimensions[1]; j++) {
				for (i=0; i<array->dimensions[0]; i++) {
					s_array_buffer[index++] = (short)*(double *)(array->data + i*array->strides[0] + j*array->strides[1]);
					s_array_buffer[index++] = (short)*(double *)(array->data + i*array->strides[0] + j*array->strides[1] + sizeof(double));
				}
			}
		}

		mrc_write_slice(&s_array_buffer[0], input_file, input_file_header, slice, axis[0]);

	}

	if (mode==SLICE_MODE_COMPLEX_FLOAT) {

		f_array_buffer  = (float *)malloc(2*length*sizeof(float));

		if (!f_array_buffer) {
			txbr_error(stderr, "ERROR: write_slice - getting memory.\n");
			return NULL;
		}


		if ( array->descr->type_num==PyArray_CFLOAT ) {
			int index = 0;
			for (j=0; j<array->dimensions[1]; j++) {
				for (i=0; i<array->dimensions[0]; i++) {
					f_array_buffer[index++] = *(float *)(array->data + i*array->strides[0] + j*array->strides[1]);
					f_array_buffer[index++] = *(float *)(array->data + i*array->strides[0] + j*array->strides[1] + sizeof(float));
				}
			}
		}

		if ( array->descr->type_num==PyArray_CDOUBLE ) {
			int index = 0;
			for (j=0; j<array->dimensions[1]; j++) {
				for (i=0; i<array->dimensions[0]; i++) {
					f_array_buffer[index++] = (float)*(double *)(array->data + i*array->strides[0] + j*array->strides[1]);
					f_array_buffer[index++] = (float)*(double *)(array->data + i*array->strides[0] + j*array->strides[1] + sizeof(double));
				}
			}
		}

		mrc_write_slice(&f_array_buffer[0], input_file, input_file_header, slice, axis[0]);

	}

	if (mode==SLICE_MODE_USHORT) {

		us_array_buffer = (unsigned short*)mrc_mread_slice(input_file, input_file_header, slice, axis[0]);

		if (!us_array_buffer) {
			txbr_error(stderr, "ERROR: write_slice - getting memory.\n");
			return NULL;
		}

		if ( array->descr->type_num==PyArray_FLOAT ) {
			int index = 0;
			for (j=0; j<array->dimensions[1]; j++) {
				for (i=0; i<array->dimensions[0]; i++) {
					us_array_buffer[index++] = *(unsigned short *)(array->data + i*array->strides[0] + j*array->strides[1]);
				}
			}
		}

		if ( array->descr->type_num==PyArray_DOUBLE ) {
			int index = 0;
			for (j=0; j<array->dimensions[1]; j++) {
				for (i=0; i<array->dimensions[0]; i++) {
					us_array_buffer[index++] = (unsigned char)*(double *)(array->data + i*array->strides[0] + j*array->strides[1]);
				}
			}
		}

		mrc_write_slice(&us_array_buffer[0], input_file, input_file_header, slice, axis[0]);

	}

	if (mode==SLICE_MODE_RGB) {

		uc_array_buffer  = (unsigned char *)malloc(3*length*sizeof(unsigned char));

		if (!uc_array_buffer) {
			txbr_error(stderr, "ERROR: write_slice - getting memory.\n");
			return NULL;
		}

		if ( array->descr->type_num==PyArray_UBYTE ) {
			int index = 0;
			for (j=0; j<array->dimensions[1]; j++) {
				for (i=0; i<array->dimensions[0]; i++) {
					for (k=0; k<array->dimensions[2]; k++) {
						uc_array_buffer[index++] = *(unsigned char *)(array->data + i*array->strides[0] + j*array->strides[1] + k*array->strides[2]);
					}
				}
			}
		}

		if ( array->descr->type_num==PyArray_FLOAT ) {
			int index = 0;
			for (j=0; j<array->dimensions[1]; j++) {
				for (i=0; i<array->dimensions[0]; i++) {
					for (k=0; k<array->dimensions[2]; k++) {
						uc_array_buffer[index++] = (unsigned char)*(float *)(array->data + i*array->strides[0] + j*array->strides[1] + k*array->strides[2]);
					}
				}
			}
		}

		if ( array->descr->type_num==PyArray_DOUBLE ) {
			int index = 0;
			for (j=0; j<array->dimensions[1]; j++) {
				for (i=0; i<array->dimensions[0]; i++) {
					for (k=0; k<array->dimensions[2]; k++) {
						uc_array_buffer[index++] = (unsigned char)*(double *)(array->data + i*array->strides[0] + j*array->strides[1] + k*array->strides[2]);
					}
				}
			}
		}

		mrc_write_slice(&uc_array_buffer[0], input_file, input_file_header, slice, axis[0]);

	}


	if (fclose(input_file)) {
		txbr_error(stderr, "ERROR: write_slice - closing file %s.\n", &input_file[0]);
		return NULL;
	}

	if (uc_array_buffer) free(uc_array_buffer);
	if (c_array_buffer) free(c_array_buffer);
	if (s_array_buffer) free(s_array_buffer);
	if (f_array_buffer) free(f_array_buffer);
	if (us_array_buffer) free(us_array_buffer);

	free(input_file_header);

	return Py_BuildValue( "i", 1 );

}

static PyMethodDef MRCMethods[] = {
	{ "size", mrc_size, METH_VARARGS, "Give the 3D size of an MRC file." },
	{ "mode", mrc_mode, METH_VARARGS, "Get the MRC File mode." },
	{ "description", mrc_description, METH_VARARGS, "Get the MRC File description." },
	{ "stats", mrc_stats, METH_VARARGS, "Calculate Statistics on an MRC File." },
	{ "update_header", update_header, METH_VARARGS, "Write the an MRC File header." },
	{ "write_header", create_header, METH_VARARGS, "Write the an MRC File header." },
	{ "create_header_from", create_header_from, METH_VARARGS, "Create an MRC File header from another MRCFile." },
	{ "read_slice", read_slice, METH_VARARGS, "Get a slice from an MRC File." },
	{ "write_slice", write_slice, METH_VARARGS, "Write a slice to an MRC File." },
	{NULL, NULL, 0, NULL} /* Sentinel */
};

PyMODINIT_FUNC initmrcfile(void) {

	(void)Py_InitModule("mrcfile", MRCMethods);

	import_array();

}

void main(int argc, char *argv[]){

	Py_SetProgramName(argv[0]);	/* Pass argv[0] to the Python interpreter */

	Py_Initialize(); /* Initialize the Python interpreter.	*/

	initmrcfile();	/* Add a static module */

}
