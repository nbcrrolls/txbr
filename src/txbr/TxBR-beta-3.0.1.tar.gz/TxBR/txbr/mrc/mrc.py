import os, numpy
import mrcfile

class MRCFile:


    def __init__(self,filename,template=None):

        self.filename = filename

        if os.path.exists(filename) and os.path.isfile(filename):
            self.getHeader()

        if template!=None and os.path.exists(template):
            mrcfile.create_header_from(filename,template)


    def getHeader(self):

        self.mode = mrcfile.mode(self.filename)
        self.nx,self.ny,self.nz = mrcfile.size(self.filename)


    def setHeader(self,nx,ny,nz,mode=2,stats=None):

        self.nx = nx
        self.ny = ny
        self.nz = nz
        self.mode = mode

        mrcfile.write_header(self.filename,nx,ny,nz,mode)
        if stats!=None: mrcfile.update_header(self.filename,stats)


    def updateHeader(self,stats=None):
        '''stats: a dictionary that could specify m0,mean,m2,min,max'''

        (self.min,self.mean,self.max) = mrcfile.update_header(self.filename,stats)


    def getXSliceAt(self,slice):

        u = mrcfile.read_slice(self.filename,'X',slice)
        return u


    def setXSliceAt(self,slice,u):

        mrcfile.write_slice(self.filename,'X',slice,u)


    def getYSliceAt(self,slice):

        u = mrcfile.read_slice(self.filename,'Y',slice)
        return u


    def setYSliceAt(self,slice,u):

        mrcfile.write_slice(self.filename,'Y',slice,u)


    def getZSliceAt(self,slice):

        u = mrcfile.read_slice(self.filename,'Z',slice)
        return u


    def setZSliceAt(self,slice,u):

        mrcfile.write_slice(self.filename,'Z',slice,u)


    def info(self):

        return '%s\n(nx=%i,ny=%i,nz=%i)' %(self.filename,self.nx,self.ny,self.nz)
