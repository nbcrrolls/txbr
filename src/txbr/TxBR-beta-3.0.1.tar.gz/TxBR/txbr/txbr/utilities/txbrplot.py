import os
import numpy, matplotlib, pylab

        
def plot3DMarkers( X, Y, Z, scale=(1.0,1.0,1.0), surfaces=() ):
    '''Surfaces is a list containing points of a surface'''
    
    try:
        from enthought.mayavi import mlab
    except ImportError:
        log.info('Mlab is not available!')
        return

    scale = numpy.array(scale)/25.0
    
    x = X.astype(float).ravel()/scale[0]
    y = Y.astype(float).ravel()/scale[1]
    z = Z.astype(float).ravel()/scale[2]
    
    fig = mlab.figure()
    
    mlab.points3d(x,y,z,scale_factor=1.0)
    
    for s in surfaces:
        x = s[0].astype(float)/scale[0]
        y = s[1].astype(float)/scale[1]
        z = s[2].astype(float)/scale[2]
        mlab.surf(x,y,z)
        
        
def plotErrorByTilt( E1byTilt, E2byTilt, EbyTilt, directory=None, basename=None):

    matplotlib.rc('text', usetex=True)
    matplotlib.rc('font',**{'family':'sans-serif','sans-serif':['Helvetica']})

    ntilt = EbyTilt.size
    tilts = numpy.arange(1,ntilt+1)

    pylab.figure()

    pylab.plot(tilts,EbyTilt,'bo-',tilts,E1byTilt, 'r:d',tilts,E2byTilt, 'g:1')

    pylab.xlim(1,ntilt)

    pylab.legend(('E',r'$E_P$',r'$E_T$'))
    pylab.title(r'Square Distance Error by Tilt')
    pylab.xlabel(r'Tilt \#')
    pylab.ylabel(r'Error')
    
    if directory==None or basename==None or not os.path.exists(directory):
        return

    file = os.path.join( directory, basename + '_err_by_tilt.png' )
    
    pylab.savefig(file,format='png')
    
    
def plotErrorByPatch( E1byPatch, E2byPatch, EbyPatch, directory=None, basename=None):

    matplotlib.rc('text', usetex=True)
    matplotlib.rc('font',**{'family':'sans-serif','sans-serif':['Helvetica']})

    npatch = EbyPatch.size
    patches = numpy.arange(1,npatch+1)

    pylab.figure()

    pylab.plot(patches,EbyPatch,'bo-',patches,E1byPatch, 'r:d',patches,E2byPatch, 'g:1')

    pylab.xlim(1,npatch)

    pylab.legend(('E',r'$E_P$',r'$E_T$'))
    pylab.title(r'Square Distance Error by Patch')
    pylab.xlabel(r'Patch \#')
    pylab.ylabel(r'Error')
    
    if directory==None or basename==None or not os.path.exists(directory):
        return

    file = os.path.join( directory, basename + '_err_by_patch.png' )
    
    pylab.savefig(file,format='png')
    
    
def plotErrorByTiltAndPatch( res1, res2, res, directory=None, basename=None):

    matplotlib.rc('text', usetex=True)
    matplotlib.rc('font',**{'family':'sans-serif','sans-serif':['Helvetica']})

    ntilt,npatch = res.shape
    tilts = numpy.arange(1,ntilt+1)

    pylab.figure()

    pylab.plot(tilts,res,'bo-',tilts,res1, 'r:d',tilts,res2, 'g:1')

    pylab.xlim(1,ntilt)

    pylab.legend(('e',r'$e_{P}$',r'$e_{T}$'))
    pylab.title(r'Square Distance Error by Tilt and Patch')
    pylab.xlabel(r'Tilt \#')
    pylab.ylabel(r'Error')
    
    if directory==None or basename==None or not os.path.exists(directory):
        return

    file = os.path.join( directory, basename + '_err_by_tilt_and_patch.png' )
    
    pylab.savefig(file,format='png')
    

def plot_projections(P, P_id):
    '''This routine plots the projection coefficients as a function of the tilt
    index'''
    
    (dim,nterm,ntilt) = P.shape

    t = range(ntilt)

    # Translation Coefficients

    pylab.figure()
    pylab.plot(P[0,0,:],'b')
    pylab.plot(P[1,0,:],'r')
    pylab.scatter(t,P_id[0,0,:],c='b',marker='o',s=8)
    pylab.scatter(t,P_id[1,0,:],c='r',marker='h',s=8)

    pylab.xlim(0,ntilt)
    #pylab.legend((r'$t_{x}$',r'$t_{y}$'))
    pylab.legend((r'$t_{1}$',r'$t_{2}$'))
    pylab.title(r'Projection Coefficients')
    pylab.xlabel(r'Tilt \#')
    pylab.ylabel(r'Translation Coefficients')

    # X coefficients

    pylab.figure()
    pylab.plot(t,P[0,1,:],'b')
    pylab.plot(t,P[0,2,:],'r')
    pylab.plot(t,P[0,3,:],'g')
    pylab.scatter(t,P_id[0,1,:],c='b',marker='o',s=8)
    pylab.scatter(t,P_id[0,2,:],c='r',marker='h',s=8)
    pylab.scatter(t,P_id[0,3,:],c='g',marker='^',s=8)

    pylab.xlim(0,ntilt)
    pylab.legend((r'$g_{11}$',r'$g_{12}$',r'$g_{13}$'))
    pylab.title(r'Projection Coefficients')
    pylab.xlabel(r'Tilt \#')
    pylab.ylabel(r'x linear coefficients')

    # Y coefficients

    pylab.figure()
    pylab.plot(t,P[1,1,:],'b')
    pylab.plot(t,P[1,2,:],'r')
    pylab.plot(t,P[1,3,:],'g')
    pylab.scatter(t,P_id[1,1,:],c='b',marker='o',s=8)
    pylab.scatter(t,P_id[1,2,:],c='r',marker='h',s=8)
    pylab.scatter(t,P_id[1,3,:],c='g',marker='^',s=8)

    pylab.xlim(0,ntilt)
    pylab.legend((r'$g_{21}$',r'$g_{22}$',r'$g_{23}$'))
    pylab.title(r'Projection Coefficients')
    pylab.xlabel(r'Tilt \#')
    pylab.ylabel(r'y linear coefficients')


def plot_angles(angles,anglesid):
    '''This routine is used to plot the angles intervening in the orthogonal 
    approximation for the TxBR projection map. They are plotted versus the 
    tilt index.'''
    
    (dim,nterm,ntilt) = angles.shape

        