import os,os.path
import re,numpy,modl
import util

import logging.config

log = logging.getLogger()

def load_transformations(file):
    """This routine load 2D transformations from an IMOD transformation
    file (such as .xf or .xg)."""
    
    if file==None or not os.path.exists(file):
        log.warning('File %s does not exist!' %file)
        
    transforms = []

    f = open(file)

    try:
        for line in f:
            print line
            items = line.rsplit()
            arg = [float(item) for item in items]
            transforms.append(util.AffineTransformation2D(*arg))
    finally:
        f.close()

    return transforms


def transfmod(modelPath,src='preali',dest='ali',prexgPath=None,xgPath=None):
    """Transform a model from a transformed state to another transformed state. Three
    states are possible in IMOD (state=st,preali,ali). The variable modelPath points
    to the model file (.fid). One at minimum of the two variables prexgPath and xgPath
    are needed depending on the source and destination of the transformation. Model
    is then saved in an appropriate file.
    """

    (directory,filename) = os.path.split(modelPath)
    (basename,ext) = os.path.splitext(filename)

    transformedModelPath = os.path.join(directory,basename + '_' + dest + ext)

    model = modl.Model(transformedModelPath)
    model.loadFromFile(modelPath)

    prexgTransforms = load_transformations(prexgPath)
    xgTransforms = load_transformations(xgPath)

    if len(prexgTransforms)!=len(xgTransforms):
        raise ValueError

    n = max(len(prexgTransforms),len(xgTransforms))

    transforms = []

    if src=='preali' and dest=='ali':
        for index in range(n):
            transforms.append(xgTransforms[index].compose(prexgTransforms[index].inv()))
    elif src=='preali' and dest=='st':
        for index in range(n):
            transforms.append(prexgTransforms[index].inv())
    elif src=='st' and dest=='ali':
        for index in range(n):
            transforms.append(xgTransforms[index])
    elif src=='st' and dest=='preali':
        for index in range(n):
            transforms.append(prexgTransforms[index])
    elif src=='ali' and dest=='st':
        for index in range(n):
            transforms.append(xgTransforms[index].inv())
    elif src=='ali' and dest=='preali':
        for index in range(n):
            transforms.append(prexgTransforms[index].compose(xgTransforms[index].inv()))
            
    print transforms

    imgCenter = numpy.array([model.xmax/2.0,model.ymax/2.0],dtype=float)

    for obj in model.objects:
        for contour in obj.contours:
            for point in contour.points:
                index = int(round(point[2],0))
                print index
                point_ = transforms[index].forward(point[:2],imgCenter)
                point[:2] = point_[:]

    log.debug(model.info())

    model.save()

    return model


def makeMarkerModel(directory, basename, work_directory=None):
    """Transform an IMOD fiducial file to a model where every fiducial tracks
    is an object"""

    log.info('Create a marker model for %s' %basename)
    
    if work_directory==None:
        work_directory = directory

    fidPath = os.path.join( directory, basename + '.fid' )
    mrkPath = os.path.join( work_directory, basename + '.mrk' )
    trkPath = os.path.join( work_directory, basename + '.trk' )

    if not os.path.exists(fidPath):
        log.info('File %s does not exist!' %fidPath)
        return None

    model = modl.Model(mrkPath)
    model.loadFromFile(fidPath,keepOnlyPointStructures=False) # Fiducial File for Etomo has a different structure

    object = model.objects[0]

    numberOfTracks = object.numberOfContours() # Number of tracks
    numberOfTilts = model.zmax # Number of tilts

    markers = numpy.zeros((numberOfTracks,numberOfTilts,2),dtype=float)    # markers[tilt #, marker #, X, Y]
    markers[:,:,:] = numpy.nan


    for itrack,contour in enumerate(object.contours):
        if numberOfTilts!=contour.npoints():
            log.info('Track #%i : missing %i points' %(itrack,numberOfTilts-contour.npoints()))
        log.info('track=%i    %i' %(itrack,len(contour.points)))
        for point in contour.points:
            itilt = int(round(point[2],0))
            markers[itrack,itilt,0] = point[0]
            markers[itrack,itilt,1] = point[1]

    model.removeObject(0)

    # Save the marker model

    for itrack in range(numberOfTracks):
        if numpy.all(numpy.isnan(markers[itrack,:,:])):    # do not consider empty tracks
            continue
        object = model.addNewObject()
        for itilt in range(numberOfTilts):
            if numpy.any(numpy.isnan(markers[itrack,itilt,:])):
                continue
            x = markers[itrack,itilt,0]
            y = markers[itrack,itilt,1]
            z = itilt
            contour = object.addNewContour()
            contour.addPoint(x,y,z)

    model.save()

    if os.path.lexists(trkPath):
        os.unlink(trkPath)

    os.symlink(mrkPath,trkPath)

    return model


def decimateModel(fidPath,n):
    """Decimate the number of contours in a given model.
    The Result is stored in a new file"""

    (directory,filename) = os.path.split(fidPath)
    (basename,ext) = os.path.splitext(filename)

    newPath = os.path.join(directory,basename + '_dec%i' %n + ext)

    model = modl.Model(newPath)
    model.loadFromFile(fidPath)

    for object in model.objects:
        object.contours = object.contours[::n]

    model.save()

