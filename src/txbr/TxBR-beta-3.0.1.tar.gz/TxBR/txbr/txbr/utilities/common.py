def extract_series_name(names):
    '''Extract the common basename among a list of names.'''

    if names==None: return None

    lmax = min([len(name) for name in names])

    basename = ''
    for index in range(lmax):
        basename += names[0][index]
        for i in range(1,len(names)):
            if basename!=names[i][:index+1]:
                 basename = basename[:index]
                 extensions = [name[index:] for name in names]
                 return [basename,extensions]

    extensions = [name[lmax:] for name in names]

    return [ basename, extensions ]



