import os,os.path,re
import logging,logging.config,ConfigParser
import numpy, modl, utilities
from mrc import MRCFile
from util import numberOfTerms,powerOrder,Point,Vector,Plane

# Set some plot configuration

import matplotlib

matplotlib.rc('text', usetex=True)
matplotlib.rc('font',**{'family':'sans-serif','sans-serif':['Arial','Helvetica'],'size':'18'})
matplotlib.rc('lines',**{'lw':2,'markersize':6})
matplotlib.rc('axes',**{'titlesize':24})
matplotlib.rc('figure',**{'edgecolor':'w'})
matplotlib.rc('xtick',**{'labelsize':16})
matplotlib.rc('ytick',**{'labelsize':16})

# Log

LOG_CONF = os.path.join(os.path.dirname(__file__),'log.conf')
logging.config.fileConfig(LOG_CONF)

log = logging.getLogger('align')

# Load configuration

global verbose, use_mayavi, enforce_tangency_constraint, \
        maximum_number_iteration, z_padding

verbose = False
use_mayavi = True
enforce_tangency_constraint = True
maximum_number_iteration = 0
z_padding = 10

def loadConfig():
    
    global verbose, use_mayavi, enforce_tangency_constraint, \
            maximum_number_iteration, z_padding
    
    file_config = os.path.join(os.path.dirname(__file__),'txbr.cfg')

    config = ConfigParser.RawConfigParser()
    config.read(file_config)

    verbose = config.getboolean('Configuration', 'verbose')
    use_mayavi = config.getboolean('Configuration', 'use-mayavi')
    enforce_tangency_constraint = config.getboolean('Configuration', 'enforce-tangency-constraint')
    maximum_number_iteration = config.getint('Configuration', 'maximum-number-iteration')
    z_padding = config.getint('Configuration', 'z-padding')
    
loadConfig()

log.debug('Verbose: %s' %verbose)
log.debug('Use Mayavi: %s' %use_mayavi)
log.debug('Enforce Tangency Constraint: %s' %enforce_tangency_constraint)
log.debug('Maximum Number of iteration: %i' %maximum_number_iteration)
log.debug('Padding in the Z direction: %i' %z_padding)


class TxBRproject:
    '''A TxBR project class.'''

    def __init__( self, directory, basenames, work_directory=None ):

        if type(basenames).__name__=='str':
            basenames = basenames.split(',')

        self.directory = directory
        self.basename, self.extensions = utilities.extract_series_name(basenames)
        
        if work_directory==None:
            self.work_directory = directory
        else:
            self.work_directory = work_directory
            
        if not os.path.exists(self.work_directory): # Eventually create the work directory
            os.mkdir(self.work_directory)
        
        self.reconstruction = Reconstruction( self.directory, self.basename, work_directory=self.work_directory )
        self.series = []
        
        self.available_series = {}
        for ext in self.extensions: 
            self.available_series[ext] = False
        

    def load(self):
        '''Load a project by scanning the files in a directory.'''

        log.info('Load the TxBR project...')

        if os.path.exists(self.directory):

            files = [file for file in os.listdir(self.directory) if file.startswith(self.basename)]

            # Scan the raw-tilt files

            for file in files:

                rwtlt_match = re.match(self.basename + '(\S*)\\.rawtlt$', file)
                
                if not rwtlt_match:
                    continue
                
                ext = rwtlt_match.group(1)
                
                self.available_series[ext] = True
                
            # Account for the possible series
                
            for extension in self.extensions:
                
                if self.available_series[extension] == False: 
                    continue
                self.addSerie(extensionOfSerie=extension)
        
            
            if len(self.series)==0: # if not series were added
                
                for extension in self.available_series.keys():
                    
                    if self.available_series[extension] == True:
                        
                        self.addSerie(extensionOfSerie=extension)
                

        else:

            log.info('Unable to load project %s from directory %s' %(self.directory, self.basename))

        # Load the reconstruction object

        self.reconstruction.load()

        align_dir = os.path.join(self.work_directory,'txbr-align')
        filter_dir = os.path.join(self.work_directory,'txbr-filter')
        setup_dir = os.path.join(self.work_directory,'txbr-setup')
        backprojection_dir = os.path.join(self.work_directory,'txbr-backprojection')

        if not os.path.exists(align_dir): os.mkdir(align_dir)
        if not os.path.exists(filter_dir): os.mkdir(filter_dir)
        if not os.path.exists(setup_dir): os.mkdir(setup_dir)
        if not os.path.exists(backprojection_dir): os.mkdir(backprojection_dir)


    def update(self):
        '''Update the project data from series parameters'''

        self.nx = None
        self.ny = None

        for serie in self.series:
            (nx,ny) = serie.dimensions()
            self.nx = max(self.nx,nx)
            self.ny = max(self.ny,ny)

        if len(self.series)==1:
            self.reconstruction.end.x = float(self.nx)
            self.reconstruction.end.y = float(self.ny)
            self.reconstruction.end.z = max(float(self.nx)/10.0,float(self.ny)/10.0)


    def numberOfSeries(self):
        '''Returns the number of series in the project'''

        return len(self.series)
    
    
    def numberOfEnabledSeries(self):
        '''Returns the number of enabled series in the project'''

        n = 0
        for s in self.series:
            if s.enabled: n += 1

        return n


    def getSerie(self,serieBasename):

        for serie in self.series:
            if serie.basename==serieBasename: return serie

        return None


    def addSerie(self,extensionOfSerie=None):

        basenameOfSerie = self.basename;

        if extensionOfSerie!=None:
            basenameOfSerie = basenameOfSerie + extensionOfSerie

        # Don't add a serie with the same basename
        if self.getSerie(basenameOfSerie)!=None: return

        log.info('Add Serie: "%s"' %extensionOfSerie)

        serie = TxBRSerie( self.directory, basenameOfSerie, work_directory=self.work_directory )
        self.series.append(serie)

        self.update()


    def stackedSeries(self):
        
        log.info('Stack Series %s' %self.basename)

        # Problem with the rotation axis....

        serie = TxBRSerie( self.directory, self.basename, work_directory=self.work_directory, load=False)
        order = 1
        for s in self.series:
            order = max(order,s.projection.approximationOrder())
        serie.projection.approximationOrder(approximationOrder=order)
        for s in self.series:
            serie.projection.scaling_coefficients = numpy.row_stack([serie.projection.scaling_coefficients,s.projection.scaling_coefficients])
            serie.projection.x_coefficients = numpy.row_stack([serie.projection.x_coefficients,s.projection.x_coefficients])
            serie.projection.y_coefficients = numpy.row_stack([serie.projection.y_coefficients,s.projection.y_coefficients])
            serie.prealignTranslations = numpy.row_stack([serie.prealignTranslations,s.prealignTranslations])
        return serie


    def saveAll(self,output=None):
        
        log.info('Save Project %s' %self.basename)

        nseries = len(self.series)

        if nseries==1:
            self.save(indexOfSerie=0,output=output)
        else:
            self.save(output=output)
            for i in range(nseries):
                self.save(indexOfSerie=i,output=output)


    def save( self, indexOfSerie=None, output=None ):

        if output!=None:
            (directory,file) = os.path.split(output)
        else:
            directory = self.work_directory
            file = None

        if os.path.exists(directory):

            try:
                serie = self.series[indexOfSerie]
                log.info('Save Series #%i' %indexOfSerie)
            except TypeError:
                serie = self.stackedSeries()
                log.info('Save Series Stack %s' %serie.basename)

            if file==None or len(file)==0:
                file = serie.basename + '.txbr'

            filename = os.path.join(directory,file)
            f = open(filename,'w')
            f.write('basename: %s\n' %serie.basename)
            f.write('directory: %s\n' %serie.directory)
            f.write('\n')
            f.write(self.reconstruction.toString())
            f.write(serie.toString())
            f.close()

        else:

            log.info('Directory %s does not exist!' %self.directory)

    def validate(self):
        
        for s in self.series:
            s.validate()


class Reconstruction:
    '''A reconstruction volume class associated with a TxBR project. It contains the final
    geometry (boundaries) of the reconstructed volume as well as information about on the
    specimen stage. Variable rotAxis is the axis of rotation of the stage for a tilt series.'''

    def __init__( self, directory, basename, work_directory=None ):

        self.directory = directory
        self.basename = basename
        self.work_directory = work_directory
        
        self.sizeOfBlock = 5
#        self.rotPoint = [0.0,0.0,0.0]
#        self.rotAxis = [0.0,1.0,0.0]
        self.origin = Point(1.0,1.0,1.0)
        self.end = Point(1.0,1.0,1.0)
        self.increment = Vector(1.0,1.0,1.0)
        self.bottomPlane = Plane(0.0,0.0,1.0,0.0)    # origin should normally belong to the bottom plane
        self.topPlane = Plane(0.0,0.0,1.0,0.0)    # end should normally belong to the top plane


    def update(self):

        self.nx = int(self.end.x - self.origin.x + 1)
        self.ny = int(self.end.y - self.origin.y + 1)
        self.nz = int(self.end.z - self.origin.z + 1)


    def getFrame(self,full=True):

        #return [[self.origin.x,self.origin.y,self.origin.z],[self.end.x,self.end.y,self.end.z]]

        P0 = [self.origin.x,self.origin.y,self.origin.z]
        P1 = [self.end.x,self.origin.y,self.origin.z]
        P2 = [self.origin.x,self.end.y,self.origin.z]
        P3 = [self.origin.x,self.origin.y,self.end.z]
        P4 = [self.end.x,self.end.y,self.origin.z]
        P5 = [self.end.x,self.origin.y,self.end.z]
        P6 = [self.origin.x,self.end.y,self.end.z]
        P7 = [self.end.x,self.end.y,self.end.z]

        if full:
            return numpy.column_stack((P0,P1,P2,P3,P4,P5,P6,P7))
        else:
            return numpy.column_stack((P0,P7))


    def setOrigin(self,x,y,z):

        try:
            self.origin.x = float(x)
        except TypeError:
            pass
        try:
            self.origin.y = float(y)
        except TypeError:
            pass
        try:
            self.origin.z = float(z)
        except TypeError:
            pass

        self.bottomPlane.d = self.origin.z


    def setIncrement(self,x,y,z):

        try:
            self.increment.x = float(x)
        except TypeError:
            pass
        try:
            self.increment.y = float(y)
        except TypeError:
            pass
        try:
            self.increment.z = float(z)
        except TypeError:
            pass


    def setEnd(self,x,y,z):
        try:
            self.end.x = float(x)
        except TypeError:
            pass
        try:
            self.end.y = float(y)
        except TypeError:
            pass
        try:
            self.end.z = float(z)
        except TypeError:
            pass

        self.topPlane.d = self.end.z


    def setBottomPlane(self,a,b,c,d):

        self.bottomPlane.a = a
        self.bottomPlane.b = b
        self.bottomPlane.c = c
        self.bottomPlane.d = d


    def setTopPlane(self,a,b,c,d):

        self.topPlane.a = a
        self.topPlane.b = b
        self.topPlane.c = c
        self.topPlane.d = d

    def getRotation(self):
        '''Rotation aroun the origin that brings the bottom and top planes parallel to
        the x-y plane'''

        a = (self.bottomPlane.a + self.topPlane.a)/2.0
        b = (self.bottomPlane.b + self.topPlane.b)/2.0
        c = (self.bottomPlane.c + self.topPlane.c)/2.0

        d1 = a**2 + b**2
        d1_sqr_root = numpy.sqrt(d1)

        d2 = a**2 + b**2 + c**2
        d2_sqr_root = numpy.sqrt(d2)

        if d1==0:
            cos_phi = 1.0
            sin_phi = 0.0
        else:
            cos_phi = a/d1_sqr_root
            sin_phi = b/d1_sqr_root

        cos_theta = c/d2_sqr_root
        sin_theta = d1_sqr_root/d2_sqr_root

        rot = numpy.zeros((3,3))

        rot[0,0] = cos_phi*cos_phi*(cos_theta-1.0) + 1.0
        rot[1,0] = cos_phi*sin_phi*(cos_theta-1.0)
        rot[2,0] = -cos_phi*sin_theta

        rot[0,1] = cos_phi*sin_phi*(cos_theta-1.0)
        rot[1,1] = sin_phi*sin_phi*(cos_theta-1.0) + 1.0
        rot[2,1] = -sin_phi*sin_theta

        rot[0,2] = cos_phi*sin_theta
        rot[1,2] = sin_phi*sin_theta
        rot[2,2] = cos_theta

        return rot


    def load(self):

        filename = os.path.join( self.work_directory, self.basename + '.txbr' )

        log.info('Load Reconstruction Parameters from %s' %filename)

        try:

            f = open(filename, 'r')

            for line in f:

                xLimit_match = re.match('x->(\S*)', line)
                if xLimit_match:
                    x_limits = xLimit_match.group(1).split(':')
                    (self.origin.x,self.increment.x,self.end.x) = (float(x_limits[0]),float(x_limits[1]),float(x_limits[2]))

                yLimit_match = re.match('y->(\S*)', line)
                if yLimit_match:
                    y_limits = yLimit_match.group(1).split(':')
                    (self.origin.y,self.increment.y,self.end.y) = (float(y_limits[0]),float(y_limits[1]),float(y_limits[2]))

                zLimit_match = re.match('z->(\S*)', line)
                if zLimit_match:
                    z_limits = zLimit_match.group(1).split(':')
                    (self.origin.z,self.increment.z,self.end.z) = (float(z_limits[0]),float(z_limits[1]),float(z_limits[2]))

#                rotAxis_match = re.match('Rotation Axis:\s*\\[(\S*)\\]', line)
#                if rotAxis_match:
#                    rotAxis = rotAxis_match.group(1).split(',')
#                    self.rotAxis = [float(tk) for tk in rotAxis]

                sizeOfBlock_match = re.match('blocksize:\s*(\S*)', line)
                if sizeOfBlock_match:
                    self.sizeOfBlock = int(sizeOfBlock_match.group(1))

                bottomPlane_match = re.match('plane_coeffs1:\s*([\S+\s*]*)', line)
                if bottomPlane_match:
                    plane = bottomPlane_match.group(1).split(' ')
                    (self.bottomPlane.d,self.bottomPlane.a,self.bottomPlane.b) = (float(plane[0]),float(plane[1]),float(plane[2]))

                topPlane_match = re.match('plane_coeffs2:\s*([\S+\s*]*)', line)
                if topPlane_match:
                    plane = topPlane_match.group(1).split(' ')
                    (self.topPlane.d,self.topPlane.a,self.topPlane.b) = (float(plane[0]),float(plane[1]),float(plane[2]))

            f.close()

            self.update()

        except IOError:

            print str(IOError)

            #raise


    def toString(self):

        toString = ''
        toString += 'x->%f:%f:%f\n' %(self.origin.x,self.increment.x,self.end.x)
        toString += 'y->%f:%f:%f\n' %(self.origin.y,self.increment.y,self.end.y)
        toString += 'z->%f:%f:%f\n' %(self.origin.z,self.increment.z,self.end.z)
        toString += '\n'
#        toString += 'Rotation Axis:[%f,%f,%f]\n' %(self.rotAxis[0],self.rotAxis[1],self.rotAxis[2])
#        toString += '\n'
        toString += 'blocksize: %i\n' %(self.sizeOfBlock)
        toString += '\n'
        toString += 'plane_coeffs1: %f %f %f\n' %(self.bottomPlane.d,self.bottomPlane.a,self.bottomPlane.b)
        toString += 'plane_coeffs2: %f %f %f\n' %(self.topPlane.d,self.topPlane.a,self.topPlane.b)
        toString += '\n'

        return toString


class ProjectionMap:


    def __init__(self,approximationOrder=None):
        self.order = None
        self.approximationOrder(approximationOrder)


    def approximationOrder(self,approximationOrder=None):

        if approximationOrder!=None:
            self.order = approximationOrder
            try:
                numberOfTerms0 = self.numberOfTerms
            except AttributeError:
                self.numberOfTerms = numberOfTerms(approximationOrder)
                self.x_coefficients = numpy.zeros((0,self.numberOfTerms),dtype=float)
                self.y_coefficients = numpy.zeros((0,self.numberOfTerms),dtype=float)
                self.scaling_coefficients = numpy.zeros((0,self.numberOfTerms),dtype=float)
            else:
                self.numberOfTerms = numberOfTerms(approximationOrder)
                n = self.numberOfExposures()
                ntail = self.numberOfTerms-numberOfTerms0
                if self.numberOfTerms>numberOfTerms0:
                    self.x_coefficients.resize((n,self.numberOfTerms))
                    self.y_coefficients.resize((n,self.numberOfTerms))
                    self.scaling_coefficients.resize((n,self.numberOfTerms))
                else:
                    self.x_coefficients = self.x_coefficients[:,:self.numberOfTerms]
                    self.y_coefficients = self.y_coefficients[:,:self.numberOfTerms]
                    self.scaling_coefficients = self.scaling_coefficients[:,:self.numberOfTerms]
            powers_ = powerOrder(approximationOrder)
            self.order_X = powers_[0]
            self.order_Y = powers_[1]
            self.order_Z = powers_[2]
            if verbose:
                log.debug('Projection Map')
                log.debug(self.order_X)
                log.debug(self.order_Y)
                log.debug(self.order_Z)
                
        return self.order


    def numberOfExposures(self):
        try:
            return len(self.x_coefficients)
        except AttributeError:
            return 0


    def scaling(self,X,Y,Z,indexOfExposure):
        scaling = 0
        for i in range(self.numberOfTerms):
            scaling += self.scaling_coefficients[indexOfExposure][i]*pow(X,self.order_X[i])*pow(Y,self.order_Y[i])*pow(Z,self.order_Z[i])
        return scaling


    def x(self,X,Y,Z,indexOfExposure):
        x = 0
        for i in range(self.numberOfTerms):
            x += self.x_coefficients[indexOfExposure][i]*pow(X,self.order_X[i])*pow(Y,self.order_Y[i])*pow(Z,self.order_Z[i])
        x = x/self.scaling(X,Y,Z,indexOfExposure)
        return x


    def y(self,X,Y,Z,indexOfExposure):
        y = 0
        for i in range(self.numberOfTerms):
            y += self.y_coefficients[indexOfExposure][i]*pow(X,self.order_X[i])*pow(Y,self.order_Y[i])*pow(Z,self.order_Z[i])
        y = y/self.scaling(X,Y,Z,indexOfExposure)
        return y

    def toString(self):

        format = ''.join([' %e' for i in range(self.numberOfTerms)]) + '\n'
        toString = ''
        for i in range(self.numberOfExposures()):
            scalingformat = 'lambda-%i:' + format
            toString = toString + scalingformat %tuple([i] + self.scaling_coefficients[i,:].tolist())
            xformat = 'x-%i:' + format
            toString = toString + xformat %tuple([i] + self.x_coefficients[i,:].tolist())
            yformat = 'y-%i:' + format
            toString = toString + yformat %tuple([i] + self.y_coefficients[i,:].tolist())
        return toString


class TrajectoryMap:

    def __init__(self):
        self.order = -1
        self.X_coefficients = []
        self.Y_coefficients = []
        self.Scaling_coefficients = []

    def approximationOrder(self,approximationOrder=None):
        if approximationOrder!=None:
            self.approximationOrder = approximationOrder
            self.numberOfTerms = numberOfTerms(approximationOrder)
            powers_ = powerOrder(approximationOrder)
            self.order_x = powers_[0]
            self.order_y = powers_[1]
            self.order_Z = powers_[2]
        return self.order


    def numberOfExposures(self):
        return len(self.X_coefficients)


    def Scaling(self,x,y,Z,indexOfExposure):
        Scaling = 0
        for i in range(self.numberOfTerms):
            Scaling += self.Scaling_coefficients[indexOfExposure][i]*pow(x,self.order_x[i])*pow(y,self.order_y[i])*pow(Z,self.order_Z[i])
        return Scaling


    def X(self,x,y,Z,indexOfExposure):
        X = 0
        for i in range(self.numberOfTerms):
            X += self.X_coefficients[indexOfExposure][i]*pow(x,self.order_x[i])*pow(y,self.order_y[i])*pow(Z,self.order_Z[i])
        X = X/self.scaling(x,y,Z,indexOfExposure)
        return X


    def Y(self,x,y,Z,indexOfExposure):
        Y = 0
        for i in range(self.numberOfTerms):
            Y += self.Y_coefficients[indexOfExposure][i]*pow(x,self.order_x[i])*pow(y,self.order_y[i])*pow(Z,self.order_Z[i])
        Y = Y/self.scaling(x,y,Z,indexOfExposure)
        return Y


class TxBRSerie:
    '''A class to modelize a EM series.'''

    def __init__( self, directory, basename, work_directory=None, load=True ):

        self.directory = directory
        self.basename = basename
        
        if work_directory==None:
            self.work_directory = directory
        else:
            self.work_directory = work_directory
        
        self.enabled = True
        self.input = None    #None, 'preali' or 'st'

        self.rotPoint = [0.0,0.0,0.0]
        self.rotAxis = [0.0,1.0,0.0]
        self.sampleOrientation = [0.0,0.0,0.0]

        stPath = os.path.join(directory, basename + '.st')
        prexgPath = os.path.join(directory, basename + '.prexg')
        prealiPath = os.path.join(directory, basename + '.preali')

        if os.path.exists(stPath) and os.path.exists(prexgPath):
            self.input = 'st'
            self.file = MRCFile(stPath)
        elif os.path.exists(prealiPath):
            self.input = 'preali'
            self.file = MRCFile(prealiPath)

        trkPath = os.path.join(self.work_directory, basename + '.trk')
        if not os.path.exists(trkPath):
            utilities.makeMarkerModel( directory, basename, work_directory=self.work_directory )

        if load:
            self.loadTiltAngles()
            ntilt = len(self.tiltAngles)
            self.loadProjectionMap(ntilt=ntilt)
            self.loadTrajectoryMap()
            self.loadPrealignTransformations()
        else:
            self.tiltAngles = []
            self.disabledTiltAngles = []
            self.projection = ProjectionMap()
            self.trajectory = TrajectoryMap()
            self.prealignTranslations = numpy.zeros((0,2))

    def validate(self):
        
        if self.file!=None and self.file.nz!=len(self.tiltAngles):
            raise SystemError, "Number of tilts in the input MRC stack and the raw tilf file is different"
        

    def numberOfExposures(self):

        numberOfAngles = len(self.tiltAngles)
        numberOfExposures = self.projection.numberOfExposures()

        return max(numberOfAngles,numberOfExposures)


    def loadPrealignTransformations(self):

        file = os.path.join(self.directory, self.basename + '.prexg')

        if os.path.exists(file):
            f = open(file, 'r')
            preali = numpy.array([line.split() for line in f],dtype='float')
            self.prealignTranslations = preali[:,4:]
        else:
            self.prealignTranslations = numpy.zeros((self.numberOfExposures(),2))


    def getTransferCoordinatesElements(self):
        '''Returns the transformations for changing coordinates from the
        laboratory frame (or microscope/camera frame, given by (ex,ey,ez))
        to a reference frame where the "rotation axis" is along the second
        direction (u2), and the first direction is perpendicular to ez.
        Returns a tuple (T,M), containing the translation and linear
        transformation that should be used for the coordinates change.
        New coordinates of a point are given by T + M x, where x represent
        its coordinates in the laboratory frame.
        '''

        ex = numpy.array([1.0,0.0,0.0])
        ey = numpy.array([0.0,1.0,0.0])
        ez = numpy.array([0.0,0.0,1.0])

        u2 = numpy.asarray(self.rotAxis)   # The image of ey
        u2 = u2/numpy.linalg.norm(u2)

        u1 = numpy.cross(ez,u2)
        u1 = u1/numpy.linalg.norm(u1)

        u3 = numpy.cross(u1,u2)

        M = numpy.column_stack((u1,u2,u3))
        M = numpy.linalg.inv(M)

        nx,ny = self.dimensions()
        fixedPoint = (nx/2.0,ny/2.0,0.0)
#        fixedPoint = numpy.asarray(self.rotPoint)

        T = fixedPoint - numpy.dot(M,fixedPoint)

        return (T,M)


    def getTransferedCoordinatesFrame(self):

        T,M = self.getTransferCoordinatesElements()

        O = numpy.array([self.origin.x,self.origin.y,self.origin.z])
        E = numpy.array([self.end.x,self.end.y,self.end.z])

        O_tf = T + numpy.dot(M,O)
        E_tf = T + numpy.dot(M,E)

        return (O_tf.tolist(),E_tf.tolist())


    def getFilteringAngle(self):

        axis = numpy.asarray(self.rotAxis)
        axis = axis/numpy.sqrt(numpy.dot(axis,axis))

        angle = - numpy.arctan(axis[0]/axis[1])

        return angle


    def setResidualTraceAngle(self,angle):

        self.residualTraceAngle = angle


    def setSampleOrientation(self,phi):

        self.sampleOrientation = phi


    def getSampleOrientation(self):

        return self.sampleOrientation


    def getSampleTransferCoordinatesElements(self):
        '''Returns the transformations for changing coordinates from the
        sample frame to the reference frame where the "rotation axis" is along the second
        direction (u2), and the first direction is perpendicular to ez.
        Returns a tuple (T,M), containing the translation and linear
        transformation that should be used for the coordinates change.
        New coordinates of a point are given by T + M x, where x represent
        its coordinates in the sample frame.
        '''

        c = numpy.cos(self.sampleOrientation)
        # To check
        #s = - numpy.sin(self.sampleOrientation)
        s = numpy.sin(self.sampleOrientation)

        ST = []

        ST.append([ c[1]*c[2], c[1]*s[2], s[1] ])
        ST.append([ - s[0]*s[1]*c[2] - c[0]*s[2], -s[0]*s[1]*s[2] + c[0]*c[2], s[0]*c[1] ])
        ST.append([ - c[0]*s[1]*c[2] + s[0]*s[2], -c[0]*s[1]*s[2] - s[0]*c[2], c[0]*c[1] ])

        nx,ny = self.dimensions()
        fixedPoint = (nx/2.0,ny/2.0,0.0)
        fixedPoint = numpy.asarray(fixedPoint)

        T = fixedPoint - numpy.dot(ST,fixedPoint)

        return (T,ST)


    def dimensions(self):

        stackPath = os.path.join(self.directory, self.basename + '.preali')
        fidPath = os.path.join(self.directory, self.basename + '.fid')
        trkPath = os.path.join(self.directory, self.basename + '.trk')

        if os.path.exists(stackPath):
            return (self.file.nx,self.file.ny)
        elif os.path.exists(fidPath):
            (xmax,ymax,zmax) = modl.XYZMax(fidPath)
            return (xmax,ymax)
        elif os.path.exists(trkPath):
            (xmax,ymax,zmax) = modl.XYZMax(trkPath)
            return (xmax,ymax)


    def indexOfReferenceExposure(self):
        indexOfReference = -1;
        referenceAngle = None
        for index in range(len(self.tiltAngles)):
            angle = self.tiltAngles[index]
            if referenceAngle==None or abs(angle)<abs(referenceAngle):
                indexOfReference = index
                referenceAngle = angle;
        return indexOfReference


    def nameOfFile(self,type):
        
        extension_map = { 'fiducial':'.fid', 'marker':'.mrk', 'track':'.trk' }
        directory_map = { 'fiducial':self.directory, 'marker':self.work_directory, 'track':self.work_directory }
        
        return os.path.join( directory_map[type], self.basename + extension_map[type] )


    def loadTiltAngles(self):

        self.tiltAngles = []
        self.disabledTiltAngles = []

        try:
            filename = os.path.join(self.directory,self.basename + '.rawtlt')
            f = open(filename, 'r')
            for line in f:
                self.tiltAngles.append(float(line))
            f.close()
            log.info('Tilt angles loaded for %s...' %self.basename)
        except IOError:
            log.info('No rawtlt file for %s!' %self.basename)


    def loadProjectionMap(self,order=1,ntilt=0):

        self.projection = ProjectionMap()

        try:

            filename = os.path.join(self.work_directory,self.basename + '.txbr')

            f = open(filename, 'r')

            for line in f:

                rotAxis_match = re.match('Rotation Axis:\s*\\[(\S*)\\]', line)
                if rotAxis_match:
                    rotAxis = rotAxis_match.group(1).split(',')
                    self.rotAxis = [float(tk) for tk in rotAxis]
                order_match = re.match('[\S,\W]*order:\W*(\S*)', line)
                if order_match:
                    order = int(order_match.group(1))
                    self.projection.approximationOrder(approximationOrder=order)
                x_match = re.match('x-(\d+):\s*([\S+\s*]*)', line)
                if x_match:
                    index = int(x_match.group(1))
                    x_list = x_match.group(2).split()
                    self.projection.x_coefficients = numpy.row_stack([self.projection.x_coefficients,numpy.array([float(s) for s in x_list])])
                y_match = re.match('y-(\d+):\s*([\S+\s*]*)', line)
                if y_match:
                    index = int(y_match.group(1))
                    y_list = y_match.group(2).split()
                    self.projection.y_coefficients = numpy.row_stack([self.projection.y_coefficients,numpy.array([float(s) for s in y_list])])
                scaling_match = re.match('lambda-(\d+):\s*([\S+\s*]*)', line)
                if scaling_match:
                    index = int(scaling_match.group(1))
                    scaling_list = scaling_match.group(2).split()
                    self.projection.scaling_coefficients = numpy.row_stack([self.projection.scaling_coefficients,numpy.array([float(s) for s in scaling_list])])

            f.close()

            log.info('Projection Maps loaded for series %s...' %self.basename)

        except IOError:

            self.projection.approximationOrder(approximationOrder=order)

            self.projection.x_coefficients = numpy.zeros((ntilt,self.projection.numberOfTerms),dtype=float)
            self.projection.y_coefficients = numpy.zeros((ntilt,self.projection.numberOfTerms),dtype=float)
            self.projection.scaling_coefficients = numpy.zeros((ntilt,self.projection.numberOfTerms),dtype=float)

            self.projection.scaling_coefficients[:,0] = 1.0

            log.info('Error loading projection map for series %s!' %self.basename)


    def loadTrajectoryMap(self):

        self.trajectory = TrajectoryMap()

        filename = os.path.join(self.directory,self.basename + '.traj')

        try:

            f = open(filename, 'r')

            for line in f:

                order_match = re.match('[\S,\W]*order:\W*(\S*)', line)
                if order_match:
                    order = int(order_match.group(1))
                    self.trajectory.approximationOrder(approximationOrder=order)

                x_match = re.match('x-(\d+):\s*([\S+\s*]*)', line)
                if x_match:
                    index = int(x_match.group(1))
                    x_list = x_match.group(2).split()
                    self.trajectory.X_coefficients.append([float(s) for s in x_list])

                y_match = re.match('y-(\d+):\s*([\S*\s*]*)', line)
                if y_match:
                    index = int(y_match.group(1))
                    y_list = y_match.group(2).split()
                    self.trajectory.Y_coefficients.append([float(s) for s in y_list])

                scaling_match = re.match('lambda-(\d+):\W+([\S+\s*]*)', line)
                if scaling_match:
                    index = int(scaling_match.group(1))
                    scaling_list = scaling_match.group(2).split()
                    self.trajectory.Scaling_coefficients.append([float(s) for s in scaling_list])

            f.close()

            log.info('Trajectory Maps loaded for %s...' %self.basename)

        except IOError:

            log.info('Error loading Trajectory Maps for %s!' %self.basename)


    def toString(self):

        toString = 'Rotation Axis:[%f,%f,%f]\n' %(self.rotAxis[0],self.rotAxis[1],self.rotAxis[2])
        toString += '\n'
        toString += 'number of tilts: %i\n\n' %self.numberOfExposures()
        toString += 'projection approximation order: %i\n\n' %self.projection.approximationOrder()
        toString += self.projection.toString()

        return toString



