import os.path,math,time
import logging,logging.config
import numpy,numpy.random,numpy.linalg
import scipy.optimize,pylab,matplotlib
import modl,util,txbr,txbr.align,txbr.align.gauge,residual,txbr.setup.txbound
import txbr.utilities

from residualMB import ResidualMB
from residualMBOrtho import ResidualMBOrthogonal
from residualCB import ResidualCB
from residualCBOrtho import ResidualCBOrthogonal

MAXITER = txbr.maximum_number_iteration
Z_PADDING = txbr.z_padding

import modl.structure
modl.structure.USE_MAYAVI = txbr.use_mayavi

T1_FLAG = 1
T2_FLAG = 2
T3_FLAG = 4
PHI1_FLAG = 8
PHI2_FLAG = 16
PHI3_FLAG = 32
MULTIPLE_BEAM_FLAG = 64
ORTHOGONAL_FLAG = 128

numpy.set_printoptions(precision=4)
numpy.set_printoptions(linewidth=numpy.Infinity)

from txbr import LOG_CONF
logging.config.fileConfig(LOG_CONF)

log = logging.getLogger('align')
#log.setLevel(logging.DEBUG)

align_dir = 'txbr-align'


def encodeModel( orthogonal, multiple, constant_phi, constant_t ):

    model = 0

    if orthogonal: model += ORTHOGONAL_FLAG
    if multiple: model += MULTIPLE_BEAM_FLAG
    if constant_phi[0]: model += PHI1_FLAG
    if constant_phi[1]: model += PHI2_FLAG
    if constant_phi[2]: model += PHI3_FLAG
    if constant_t[0]: model += T1_FLAG
    if constant_t[1]: model += T2_FLAG
    if constant_t[2]: model += T3_FLAG

    return model


def decodeModel( model ):

    orthogonal = (model & ORTHOGONAL_FLAG) == ORTHOGONAL_FLAG
    multiple = (model & MULTIPLE_BEAM_FLAG) == MULTIPLE_BEAM_FLAG
    phi_constant = [ (model & PHI1_FLAG) == PHI1_FLAG, (model & PHI2_FLAG) == PHI2_FLAG, (model & PHI3_FLAG) == PHI3_FLAG ]
    t_constant = [ (model & T1_FLAG) == T1_FLAG, (model & T2_FLAG) == T2_FLAG, (model & T3_FLAG) == T3_FLAG ]

    phi_constant = numpy.asarray(phi_constant)
    t_constant = numpy.asarray(t_constant)

    rep = ''

    if orthogonal: rep += 'Beam Model: Orthogonal'
    else:  rep += 'Beam Model: General'

    if multiple: rep += ', Multiple'
    else:  rep += ', Constant'

    if orthogonal: rep += ', phi fixed [%s,%s,%s]' %( phi_constant[0], phi_constant[1], phi_constant[2] )

    rep += ', t fixed [%s,%s,%s]' %( t_constant[0], t_constant[1], t_constant[2] )

    log.info(rep)

    return ( orthogonal, multiple, phi_constant, t_constant )


class TxBRContourAlign:
    '''A class to handle bundle adjustment'''


    def __init__( self, project, model, n1=0, n2=1, n3=0, n4=0, axis=None, flatten_order=None, \
                  shortcut=True, doPlot=False, prepare=True, iter=MAXITER, blocksize=None, \
                  init=False, evaluateFromScratch=True, with_contour=True ):

        self.project = project
        self.processing = False
        self.doPlot = doPlot
        
        self.project.validate()

        self.orthogonal, self.multiple, self.phi_constant, self.t_constant = decodeModel( model )

        self.n1 = n1
        self.n2 = n2
        self.n3 = n3
        self.n4 = n4
        
        if not with_contour:
            self.n1 = 1
            self.n3 = 1
            self.n4 = 0
            
        log.info('Order (%i,%i,%i,%i)' %(n1,n2,n3,n4))

        self.flatten_order = flatten_order
        self.shortcut = shortcut
        self.iter = iter
        self.init = init
        self.evaluateFromScratch = evaluateFromScratch
        self.with_contour = with_contour
        self.enforceTangencyConstraint = txbr.enforce_tangency_constraint
        
        if blocksize!=None:
            self.project.reconstruction.sizeOfBlock = blocksize

        log.info('Full Minimization: %s' %(not self.shortcut))

        self.parameter_file = os.path.join(project.work_directory,project.basename +'.ctl')

        if axis!=None:
            for serie in project.series: serie.rotAxis = axis

        self.u_t = [ numpy.asarray(serie.rotAxis) for serie in project.series ]

        for u in self.u_t:
            log.info('Reference Axis: [%f,%f,%f]' %(u[0],u[1],u[2]))

        self.initialize()

        self.initializeResidual(self.n1,1,self.n3,self.n4,prepare)  # Treat first the residual with a linear projection map

        self.doInitialEstimates()


    def initialize(self):
        """Load data (number of series, tilt and objects) from the project model file.
        """

        nseries = self.project.numberOfSeries()

        self.seriesRange = []    # Index range of a series
        self.referenceExposures = []    # Reference Exposure index vs series index
        self.tlts = []    # Number of exposures vs series index
        self.seriesBasenames = []    # Number of exposures vs series index
        self.numberOfTilts = 0    # Total number of exposures
        self.numberOfPatches = 0    # Total number of objects
        self.models = []
        self.points = []
        self.lines = []
        self.surfaces = []
        
        if nseries==0: return;

        for iserie in range(nseries):
            serie = self.project.series[iserie]
            if not serie.enabled: continue
            offset = self.numberOfTilts
            trackModel = modl.Model(serie.nameOfFile('track'))
            trackModel.loadFromFile(keepOnlyPointStructures=not self.with_contour)
            trackModel.tiltOffset = offset
            self.seriesRange.append(range(offset,offset+serie.numberOfExposures()))
            self.referenceExposures.append(offset+serie.indexOfReferenceExposure())
            self.tlts.append(serie.numberOfExposures())
            self.seriesBasenames.append(serie.basename)
            self.numberOfTilts += serie.numberOfExposures()
            self.models.append(trackModel)

        self.numberOfPatches = self.models[0].numberOfObjects()

        log.info('Micrographs Dimensions: (nx,ny)=(%i,%i)' %(self.project.nx,self.project.ny))
        log.info('Total Number of Tilts: %i (%s)' %(self.numberOfTilts,self.tlts))
        log.info('Number of Patches: %i' %self.numberOfPatches)

        # Eventually make sure that the models contain the same object list

        model = self.models[0]

        for object in model.objects:
            indexOfObject = object.indexOfObject
            if object.isAPoint():
                self.points.append(indexOfObject)
            elif object.isALine():
                self.lines.append(indexOfObject)
            else:
                self.surfaces.append(indexOfObject)
                    
        self.pure_bead_markers = len(self.lines)==0 and len(self.surfaces)==0

        log.info('Number of Point Object Structures: %i' %len(self.points))
        log.debug('  %s' %self.points)
        log.info('Number of Line Object Structures: %i' %len(self.lines))
        log.debug('  %s' %self.lines)
        log.info('Number of Surface Object Structures: %i' %len(self.surfaces))
        log.debug('  %s' %self.surfaces)


    def initializeResidual(self,n1,n2,n3,n4,prep):
        """Initialize the residual object (that handles cost function expressions,
        its derivatives and hessians for the bundle adjustment).
        """

        ntilt = self.numberOfTilts
        npatch = self.numberOfPatches

        if not self.orthogonal and not self.multiple:

            self.resid = ResidualCB( ntilt, npatch, n1, n2, n3, n4, fix_b=True, \
                                    prepare=prep, enforceTangencyConstraint= self.enforceTangencyConstraint )

        elif not self.orthogonal and self.multiple:

            self.resid = ResidualMB( ntilt, npatch, n1, n2, n3, n4, fix_b=True, \
                                     prepare=prep, enforceTangencyConstraint= self.enforceTangencyConstraint )

        elif self.orthogonal and not self.multiple:

            self.resid = ResidualCBOrthogonal( ntilt, npatch, n1, n2, n3, n4, fix_b=True, \
                                               prepare=prep, enforceTangencyConstraint= self.enforceTangencyConstraint )

        elif self.orthogonal and self.multiple:

            self.resid = ResidualMBOrthogonal( ntilt, npatch, n1, n2, n3, n4, fix_b=True, \
                                               prepare=prep, enforceTangencyConstraint= self.enforceTangencyConstraint )

        self.resid.t_constant = self.t_constant
        self.resid.phi_constant = self.phi_constant


    def doInitialEstimates(self):
        """Initialize estimates for the residual coefficients.
        """
        
        if self.project.numberOfSeries()==0: return

        self.tracks, self.mask, self.glomap = self.initializeTracks()

        self.initializeTraces()

        if self.init:
            mode = 'project'
        else:
            mode = 'ideal'

        self.angles, self.P = self.initializeProjectionMap(mode=mode)    # Ideal Projection

        self.resid.P = self.P
        self.resid.angles = self.angles
        self.resid.tracks = self.tracks
        self.resid.Emask = self.mask
        self.resid.points = self.points
        self.resid.lines = self.lines
        self.resid.surfaces = self.surfaces
        self.resid.fixed_origin = numpy.array([ self.project.nx/2.0, self.project.ny/2.0, 0.0 ])

        self.resid.tlts = self.tlts

        if self.doPlot:
            self.plot_individual_contour_mappings()
            for ipatch in self.surfaces:
                self.plot_individual_contour_mappings()

        if self.evaluateFromScratch or not os.path.exists(self.parameter_file):

            log.info("Evaluate new parameters from scratch!")

            self.resid.a = self.resid.initializeACoefficients()
            self.resid.b = self.resid.initializeBCoefficients()
            self.resid.b_scaling = self.resid.initializeBScalingCoefficients()
            self.resid.c = self.resid.initializeCCoefficients()
            self.resid.d = self.resid.initializeDCoefficients()

        else:    # Read them from a file

            log.info("Load parameters from %s!", self.parameter_file)

            [ self.resid.a, self.resid.b,  self.resid.b_scaling, self.resid.c, self.resid.d ] = \
                        self.loadParameters(self.parameter_file)

        # Locally the projection map is stored in its general form

        self.a = self.resid.unfold_var1(self.resid.a)
        self.b, self.b_scaling = \
            self.resid.unfold_var2_with_scaling(self.resid.b,self.resid.b_scaling)
        self.c = self.resid.unfold_var3(self.resid.c)
        self.d = self.resid.unfold_var4(self.resid.d)


    def initializeProjectionMap(self,mode='ideal'):
        """ Initialize the projection map. If the mode is set to 'ideal',
        the projection map is calculated from the experimental angles. If
        the mode is set to 'project', the the projection map is the current
        one of the project.
        """

        n1 = self.numberOfTilts
        n2 = self.resid.nn2

        nserie = self.project.numberOfSeries()

        # Buid the angles first

        angles = []

        for iserie in range(nserie):

            serie = self.project.series[iserie]
            if not serie.enabled: continue

            angles.append(numpy.asarray(serie.tiltAngles))

        angles = -numpy.concatenate(angles)

        # Tilt angle are defined arount ey (usually)
        # TO FIX

        angles = angles[numpy.newaxis,:]
        angles = numpy.insert(angles,[0,1],0,axis=0)

        # Build the projection map

        P = numpy.zeros((2*n1,n2))

        if mode=='ideal':

            nx,ny = self.project.nx,self.project.ny

            for iserie in range(nserie):

                serie = self.project.series[iserie]
                if not serie.enabled: continue

                Origin = numpy.array([nx/2.0,ny/2.0,0.0])    # Origin / Center of rotation
                u = self.u_t[iserie]    # Rotation axis

                x_range = 2*numpy.array(self.seriesRange[iserie])
                y_range = 2*numpy.array(self.seriesRange[iserie]) + 1

#                angles = numpy.asarray(serie.tiltAngles)
#                angles = -angles
#
#                cos_phi = numpy.cos(angles*math.pi/180.0)
#                sin_phi = numpy.sin(angles*math.pi/180.0)

                cos_phi = numpy.cos(angles[1,self.seriesRange[iserie]]*math.pi/180.0)
                sin_phi = numpy.sin(angles[1,self.seriesRange[iserie]]*math.pi/180.0)

                P[x_range,1] = u[0]*u[0]*(1-cos_phi) + cos_phi
                P[x_range,2] = u[0]*u[1]*(1-cos_phi) - u[2]*sin_phi
                P[x_range,3] = u[0]*u[2]*(1-cos_phi) + u[1]*sin_phi

                P[y_range,1] = u[1]*u[0]*(1-cos_phi) + u[2]*sin_phi
                P[y_range,2] = u[1]*u[1]*(1-cos_phi) + cos_phi
                P[y_range,3] = u[1]*u[2]*(1-cos_phi) - u[0]*sin_phi

                P[x_range,0] = Origin[0] - numpy.dot(P[x_range,1:4],Origin)
                P[y_range,0] = Origin[1] - numpy.dot(P[y_range,1:4],Origin)

                # Handle an eventual transfer rotation

                (sample_tf_t0,sample_tf_m) = serie.getSampleTransferCoordinatesElements()

                sample_tf_m = numpy.asarray(sample_tf_m).T.tolist()

                P[x_range,0] += numpy.dot(P[x_range,1:4],Origin) - numpy.dot(P[x_range,1:4],numpy.dot(sample_tf_m,Origin))
                P[y_range,0] += numpy.dot(P[y_range,1:4],Origin) - numpy.dot(P[y_range,1:4],numpy.dot(sample_tf_m,Origin))

                P[x_range,1:4] = numpy.dot(P[x_range,1:4],sample_tf_m)
                P[y_range,1:4] = numpy.dot(P[y_range,1:4],sample_tf_m)

        elif mode=='project':

            offset = 0

            for iserie in range(nserie):

                serie = self.project.series[iserie]
                if not serie.enabled: continue
                nproj = serie.projection.numberOfTerms
                nexposure = serie.projection.numberOfExposures()

                for iexp in range(nexposure):
                    for iproj in range(nproj):

                        P[offset+2*iexp,iproj] = serie.projection.x_coefficients[iexp][iproj]
                        P[offset+2*iexp+1,iproj] = serie.projection.y_coefficients[iexp][iproj]

                offset +=2*nexposure

        return angles, P


    def initializeTracks(self):
        """This routine initializes the tracking objects.
        The track object contains the individual polynomial approximation for the contour traces.
        """

        # Establish first for which tilt index a tracking object is defined.
        # This is the mask

        log.debug('Calculate the mask. ')

        mask = numpy.zeros((self.numberOfTilts,self.numberOfPatches))

        for model in self.models:
            for object in model.objects:
                iobj = object.indexOfObject
                indicesOfViews = [model.tiltOffset+index for index in object.indicesOfViews()]
                mask[indicesOfViews,iobj] = 1

        # Generate polynomial approximations on the objects
        # This will be used as an initial estiates for building the structure
        # surfaces

        log.debug('Calculate the globlal polynomial approximation for the contours. ')

        nseries = self.project.numberOfEnabledSeries()

        n3 = self.resid.n3
        nn3 = self.resid.nn3

        glomap = []

        for iserie,model in enumerate(self.models):
            objectMapping = model.polynomialMapping(n3,u_t=self.u_t[iserie],doPlot=self.doPlot)
            for iobj in range(len(objectMapping)):
                mapping = objectMapping[iobj]
                (px,py,indicesOfViews) = mapping
                skipViews = numpy.array([True for i in range(self.numberOfTilts)])
                skipViews[indicesOfViews] = False
                glomap.append((px,py,skipViews,self.u_t,'2D'))
                #glomap.append((px,py,skipViews,self.u_t,'3D'))

        # Generates individual mapping for each contours

        log.debug('Generate individual contour mappings and create the tracks object.')

        tracks = numpy.zeros((self.numberOfTilts,self.numberOfPatches,2,nn3))

        for iserie,mod in enumerate(self.models):
            index0 = mod.tiltOffset
            for object in mod.objects:
                iobject = object.indexOfObject
                for contour in object.contours:
                    (pc_x,pc_y) = contour.polynomialMapping(n3,u_t=self.u_t[iserie],doPlot=self.doPlot)
                    z = int(round(contour.zExtensionSet().pop(),0))
                    itilt = index0 + z
                    tracks[itilt,iobject,0,:nn3] = pc_x.coeff[:]
                    tracks[itilt,iobject,1,:nn3] = pc_y.coeff[:]

        return (tracks,mask,glomap)


    def initializeTraces(self):
        """Calculate trace angles and orientation of reference axes.
        """

        nseries = self.project.numberOfEnabledSeries()

        log.info('Calculate Reference Rotation Axis from Trace Angles...')

        pointTracks = self.tracks[:,self.points,:,:1]
        pointMask = self.mask[:,self.points]

        pointTracks = pointTracks.reshape(pointTracks.shape[:3])

        for iseries in range(nseries):

            rg = self.seriesRange[iseries]
            (ref_angle,angle) = txbr.align.trace_angle(pointTracks[rg],pointMask[rg],self.u_t[iseries])
            self.project.getSerie(self.seriesBasenames[iseries]).setResidualTraceAngle(angle)
            log.info('Reference Angle: %f rad / %f deg (Series #%i)' %(ref_angle,numpy.degrees(ref_angle),iseries))
            log.info('Residual Track Angle: %f rad / %f deg (Series #%i)' %(angle,numpy.degrees(angle),iseries))

            log.info('Update the rotation axis...')

            log.info('Old rotation axis: %s' %str(self.u_t[iseries]))

            c = numpy.cos(-angle)
            s = numpy.sin(-angle)
#            c = numpy.cos(angle)
#            s = numpy.sin(angle)
            R = numpy.array([[c,s,0.0],[-s,c,0.0],[0.0,0.0,1.0]])


            self.u_t[iseries] = numpy.dot(R,self.u_t[iseries])
            #self.u_t = numpy.dot(R,[0.0,1.0,0.0])

            self.project.series[iseries].rotAxis = self.u_t[iseries]
            self.u_t[iseries] = self.project.series[iseries].rotAxis

            # TEST
            self.project.reconstruction.rotAxis = self.u_t[iseries]
            # TEST

            #print self.project.series[iseries].rotAxis

            filtering_angle = self.project.series[iseries].getFilteringAngle()

            log.info('New rotation axis:  %s' %str(self.u_t[iseries]))
            log.info('Filtering Angle:    %f rad    %f deg' %(filtering_angle,numpy.degrees(filtering_angle)))

        # ############## 'TO UPDATE'  #####################


        log.info('Calculate relative rotation angle between series...')

        if pointTracks.size!=0:

            try:

                index_ref = 0

                trf,theta = txbr.align.relative_rot_transform(pointTracks[self.referenceExposures],pointMask[self.referenceExposures],index_ref=index_ref)

#                theta[1] = 85.0/180*numpy.pi

                for iseries in range(nseries):

                    series = self.project.getSerie(self.seriesBasenames[iseries])
                    series.setSampleOrientation(numpy.array([0.0,0.0,theta[iseries]]))

                    log.info('Relative Angle: %f rad / %f deg (Serie #%i/Series #%i)' %(theta[iseries],numpy.degrees(theta[iseries]),iseries,index_ref))

            except Exception:

                log.info('Skipped calculation of relative rotation angle between series...')
                pass



    def initializeSkipping(self, _fix_a, _fix_b, _fix_c, _fix_d, projection=None):
        '''Determine which variables should be kept constant'''

        self.resid.skip_a = self.resid.initializeASkipping()
        self.resid.skip_b = self.resid.initializeBSkipping(projection)
        self.resid.skip_c = self.resid.initializeCSkipping()
        self.resid.skip_d = self.resid.initializeDSkipping()

        skip = []

        if not _fix_a: skip += self.resid.skip_a
        if not _fix_b: skip += self.resid.skip_b
        if not _fix_c: skip += self.resid.skip_c
        if not _fix_d: skip += self.resid.skip_d

        return numpy.asarray(skip)


    def process(self):
        '''Process the alignment.'''
        
        if self.project.numberOfSeries()==0: 
            log.warning('No Series to process!')
            return

        self.initializeStructureSet()

        if self.doPlot and False:
            self.plot_contour_reprojection(limits=[0,self.project.nx,0,self.project.ny])
            
        self.plot_DSA_points_reprojection()

        log.info('Start the optimization!')

        _fix_a = False
        _fix_b = False
        _fix_c = True
        _fix_d = False

        if len(self.lines)==0 and len(self.surfaces)==0:
            _fix_d = True    # To be faster

        self.resid.fixVariables(fix_a=_fix_a,fix_b=_fix_b,fix_c=_fix_c,fix_d=_fix_d)

        skip = self.initializeSkipping(_fix_a,_fix_b,_fix_c,_fix_d,projection='linear')

        var = self.resid.joinParameters(_fix_a,_fix_b,_fix_c,_fix_d) # We keep a copy of the initial variables

        self.processing = True

        log.info('Bundle Adjustment with Contour Alignment Processing...')

        xopt = []    # Variables used for the minimization

        if not _fix_a:
            self.resid.a = self.reCenterTracks()
            xopt += self.resid.a
        if not _fix_b:
            # Relax the projection map if the beam model is not orthogonal
            if not isinstance(self.resid,ResidualMBOrthogonal) and not isinstance(self.resid,ResidualCBOrthogonal):
                self.resid.b = self.resid.relaxProjection(order=(0,1))
            xopt += self.resid.b
        if not _fix_c: xopt += self.resid.c
        if not _fix_d: xopt += self.resid.d
        
        xopt = numpy.array(xopt)

        xopt = scipy.optimize.fmin_ncg( self.resid.error_struct, xopt, self.resid.der_error, args=(skip,),
                                        fhess=self.resid.hess_error, avextol=1.e-16, maxiter=self.iter )

        log.info('xopt=' + str(xopt)[:60] + ' ...')

        xopt = numpy.where(skip,var,xopt)

        self.resid.storeParameters(xopt,_fix_a,_fix_b,_fix_c,_fix_d)

        # Take care of non linear coefficients

        if self.n2>self.resid.n2 and not self.shortcut:

            log.info('Processing high order coefficients...')

            self.resid.extendProjectionMapOrder(self.n2)

            var = self.resid.joinParameters(_fix_a,_fix_b,_fix_c,_fix_d)

            skip = self.initializeSkipping(_fix_a,_fix_b,_fix_c,_fix_d,projection='non-linear')

            xopt = var.copy()

            xopt = scipy.optimize.fmin_ncg( self.resid.error_struct, xopt, self.resid.der_error, args=(skip,),
                                        fhess=self.resid.hess_error, avextol=1.e-16, maxiter=self.iter )

            log.info('xopt=' + str(xopt)[:60] + ' ...')

            xopt = numpy.where(skip,var,xopt)

            self.resid.storeParameters( xopt, _fix_a, _fix_b, _fix_c, _fix_d )

           # self.resid.b = self.resid.relaxProjection()


        if self.n2>self.resid.n2 and self.shortcut:
            
            if self.multiple:
                full_reset = True
            else:
                full_reset = False

            self.resid.extendProjectionMapOrder(self.n2, full_reset=full_reset)

            skip = self.initializeSkipping(_fix_a,_fix_b,_fix_c,_fix_d,projection='non-linear')

            self.resid.b = self.resid.relaxProjection()
            
            (self.resid.b,self.resid.b_scaling) = self.resid.evaluateScalingParameters()

        # Unfold the data into the general reference frame

        self.a = self.resid.unfold_var1(self.resid.a)
        self.b = self.resid.unfold_var2(self.resid.b)
        self.b, self.b_scaling = \
                self.resid.unfold_var2_with_scaling(self.resid.b,self.resid.b_scaling)
        self.c = self.resid.unfold_var3(self.resid.c)
        self.d = self.resid.unfold_var4(self.resid.d)

        log.info('len(a)=%i  len(b)=%i  len(c)=%i  len(d)=%i' %(len(self.a),len(self.b),len(self.c),len(self.d)))
        log.info('a=' + str(self.a)[:60] + ' ...')
        log.info('b=' + str(self.b)[:60] + ' ...')
        log.info('c=' + str(self.c)[:60] + ' ...')
        log.info('d=' + str(self.d)[:60] + ' ...')

        if self.flatten_order!=None:
            
            self.flatten()    # Effective order of the projection maps can be increased
            
        else:
        
            self.reorient()
            
            self.solveGaugeAmbiguity()
            
        self.info()
        
        self.generateAlignLogFile()
        
        self.evaluateAlignmentTransform()

        self.saveStructureSet()

        self.saveProjectionMapToProject()
        
        self.saveParameters(self.parameter_file)

        if self.doPlot:
            
            self.plot_projections()

            self.plot_contour_reprojection(limits=[0,self.project.nx,0,self.project.ny])
            
            for ipatch in self.surfaces:
                self.plot_contour_reprojection(ipatch=ipatch)

        self.processing = False


    def reCenterTracks(self):
        '''This routine recenter the calculated 3D track positions in the camera plane
        relatively to their original projected values.'''

        nn1 = self.resid.nn1
        nobj = self.numberOfPatches

        tilt_ref = self.referenceExposures[0]
        mask_ref = self.mask[tilt_ref,:]

        Xmarks = self.tracks[tilt_ref,:,0,0]*mask_ref
        Ymarks = self.tracks[tilt_ref,:,1,0]*mask_ref

        Cix = numpy.mean(Xmarks)
        Ciy = numpy.mean(Ymarks)

        A = numpy.resize(self.a,(3,nn1,nobj))
        X = A[0,0,:]
        Y = A[1,0,:]

        Cfx = numpy.mean(X*mask_ref)
        Cfy = numpy.mean(Y*mask_ref)

        A[0,0,:] = A[0,0,:] - Cfx + Cix
        A[1,0,:] = A[1,0,:] - Cfy + Ciy

        return A.ravel().tolist()


    def solveGaugeAmbiguity(self):
        '''Gauge Ambiguity Routine. The projection maps should be corrected to become
        the best orthogonal solution. This should be done using geometrical consideration.'''

        log.info('Solve Gauge ambiguity')

        nterm = self.resid.nn2
        ntilt = self.numberOfTilts

        frame = self.project.reconstruction.getFrame()

        B = numpy.resize(self.b,(2,nterm,ntilt))

        for index,basename in enumerate(self.seriesBasenames):

            log.debug('Serie %i: %s' %(index,basename))

            serie = self.project.getSerie(basename)
            range = self.seriesRange[index]
            
            log.debug('   Sample Orientation: %s' %numpy.degrees(serie.getSampleOrientation()))
            log.debug('      Filtering Angle: %s' %numpy.degrees(serie.getFilteringAngle()))
            
            ref_t_elements = serie.getTransferCoordinatesElements()
            smpl_t_elements = serie.getSampleTransferCoordinatesElements()

            P,N = txbr.align.gauge.rotation_axis(B[:,:4,range],frame,ref_t_elements,smpl_t_elements,doPlot=self.doPlot)

            self.project.reconstruction.rotAxis = N
            self.u_t = N


    def reorient(self):
        '''Use the point track markers to modify the projection map to
        be the best orthogonal ones.'''
        
        if len(self.points)==0: return

        nobj = self.numberOfPatches
        nn1 = self.resid.nn1
        ntilt = self.numberOfTilts

        # First thing, rotate everything for the fiducials to be in the XY plane

        A = numpy.resize(self.a,(3,nn1,nobj))
        A = A.swapaxes(0,2)

        X = A[:,0,:]

        pt_markers = X[self.points,:]

        log.info('Reorient specimen with %i point markers.' %pt_markers.shape[0])

        bp,tp = txbr.setup.txbound.eval_bounds_2(pt_markers,XY_range=(self.project.nx,self.project.ny))

        bp = numpy.asarray(bp)
        tp = numpy.asarray(tp)

        v1 = numpy.asarray(bp[1:])
        v2 = numpy.asarray(tp[1:])

        v1 = v1/numpy.sqrt(numpy.dot(v1,v1))
        v2 = v2/numpy.sqrt(numpy.dot(v2,v2))

        v = numpy.average(numpy.row_stack((v1,v2)),axis=0)    # Normal vector to the specimen surface
        v = v/numpy.sqrt(numpy.dot(v,v))
        ez = numpy.array([0.0,0.0,1.0])

        nx,ny = self.project.nx,self.project.ny

        medium_plane = numpy.average(numpy.row_stack((bp,tp)),axis=0)

        log.info('Bottom plane: %.2f + %.2f x + %.2f y + z = 0' %(bp[0],bp[1],bp[2]))
        log.info('   Top plane: %.2f + %.2f x + %.2f y + z = 0' %(tp[0],tp[1],tp[2]))
        log.info('Medium plane: %.2f + %.2f x + %.2f y + z = 0' %(medium_plane[0],medium_plane[1],medium_plane[2]))

        M = numpy.array([nx/2.0,ny/2.0,0.0])
        M[2] = -(medium_plane[0]+numpy.dot(medium_plane[1:3],M[:2]))/medium_plane[3]
        #M[2] = 0.0

        M_img = numpy.array([nx/2.0,ny/2.0,0.0])

        log.info('M (%s) -> (%s)' %(str(M),str(M_img)))

        center = numpy.array([0.0,0.0,0.0])

        axis = numpy.cross(ez,v)
        axis = axis/numpy.sqrt(numpy.dot(axis,axis))

        theta = numpy.arccos(numpy.dot(ez,v))

        rotation = util.Rotation3D(center,axis,-theta)

        rotation.T = M_img - numpy.dot(rotation.M,M)
        rotation.center = numpy.dot(numpy.linalg.pinv(numpy.eye(3)-rotation.M),rotation.T)
        center = rotation.center

        #rotation = util.Rotation3D(center,axis,-theta)

        log.info('Center = %s' %str(center))
        log.info('v = %s' %str(v))
        log.info('axis = %s' %str(axis))
        log.info('theta = %f rad    %f deg' %(theta,numpy.degrees(theta)))

        # Rotate the tracks

        A_r = rotation.forward(A)

        log.info('Minimum values of a: %s' %numpy.squeeze(numpy.min(A_r,axis=0)))
        log.info('Maximum values of a: %s' %numpy.squeeze(numpy.max(A_r,axis=0)))
        

        A_r = A_r.swapaxes(0,2)
        a = A_r.ravel()
        
        A_ = numpy.resize(a,(3,nn1,nobj))
        Z_ = A_[2,0,:]
        
#        for iobj in range(nobj):
#            print 'pt# %i    [%9.2f,%9.2f,%9.2f]' %(iobj,A_[0,0,iobj],A_[1,0,iobj],A_[2,0,iobj])

        # Calculate the range in Z

        h = numpy.ones((4))
        h[1:] = center[:]
#        dmin = -numpy.dot(bp,h)
#        dmax = -numpy.dot(tp,h)
        
        dmin = numpy.dot(bp,h)
        dmax = numpy.dot(tp,h)
        
        log.info('Distance of center from planes: dmin=%.3f   dmax=%.3f' %(dmin,dmax))

        Zmin = rotation.forward(-center+dmin*v)
        Zmax = rotation.forward(-center+dmax*v)

        Zmin = numpy.asarray(Zmin,dtype='int')
        Zmax = numpy.asarray(Zmax,dtype='int')

        Zmin[:2] = 1
        Zmax[:2] = [nx,ny]
        
        if Zmax[2]<=Zmin[2]:
            log.error('Error in the Z boundarues: Zmin=%.3f   Zmax=%.3f' %(Zmin[2],Zmax[2]))

#        Zmin[2] = numpy.min(Zmin[2],numpy.min(Z_))
#        Zmax[2] = numpy.max(Zmax[2],numpy.max(Z_))

        # From the fiducials

        Zmin[2] = numpy.min(Z_)
        Zmax[2] = numpy.max(Z_)
        
        
        

        Zmin[2] -= Z_PADDING
        Zmax[2] += Z_PADDING
        
        # Update the reconstruction object
                
        self.project.reconstruction.setOrigin(*Zmin.tolist())
        self.project.reconstruction.setEnd(*Zmax.tolist())
        self.project.reconstruction.setBottomPlane(0.0,0.0,0.0,Zmin[2])
        self.project.reconstruction.setTopPlane(0.0,0.0,0.0,Zmax[2])

        log.info('Reconstruction boundaries: %s -> %s' %(str(Zmin),str(Zmax)))

        # Now compose the polynomial projection with the rotation

        log.info('Rotate projection map...')

        B = numpy.resize(self.b,(2,self.resid.nn2,ntilt))

        rotation_inv = rotation.inv()

        variables = ['X','Y','Z']
        powers = numpy.array(util.powerOrder(1,dim=3)).T
        pp2 = numpy.array(self.resid.pp2).T

        rinv_x = util.PolyM(variables,numpy.append(rotation_inv.T[0],rotation_inv.M[0,:]),powers)
        rinv_y = util.PolyM(variables,numpy.append(rotation_inv.T[1],rotation_inv.M[1,:]),powers)
        rinv_z = util.PolyM(variables,numpy.append(rotation_inv.T[2],rotation_inv.M[2,:]),powers)

        rotinv_poly = {'X':rinv_x,'Y':rinv_y,'Z':rinv_z}

        for itilt in range(ntilt):
            coefficients_x = numpy.squeeze(B[0,:,itilt])
            coefficients_y = numpy.squeeze(B[1,:,itilt])
            polyb_x = util.PolyM(variables,coefficients_x,pp2)
            polyb_x = polyb_x.compose(rotinv_poly)
            polyb_y = util.PolyM(variables,coefficients_y,pp2)
            polyb_y = polyb_y.compose(rotinv_poly)
#            B[0,:,itilt] = polyb_x.coefficients
#            B[1,:,itilt] = polyb_y.coefficients
            B[0,:,itilt] = polyb_x.extract_coefficients(pp2)
            B[1,:,itilt] = polyb_y.extract_coefficients(pp2)

        b = B.ravel()

        log.info('Map reorientation done...')

        self.a = a
        self.b = b


    def flatten(self):
        '''Use the point track markers to modify the projection map to
        be the best orthogonal ones.'''

        if self.flatten_order==None:
            return

        order = self.flatten_order

        nobj = self.numberOfPatches
        nn1 = self.resid.nn1
        ntilt = self.numberOfTilts

        A = numpy.resize(self.a,(3,nn1,nobj))
        A = A.swapaxes(0,2)

        X = A[self.points,0,:]

        # Evaluate Equations of the boundary surfaces

        bp,tp = txbr.setup.txbound.eval_poly_bounds(X,order)

        # Misc definitions

        variables = ['X','Y','Z']

        nn = util.powerseq.numberOfTerms(order,dim=2)

        powers = numpy.array(util.powerOrder(order,dim=2)).T
        powers = numpy.column_stack((powers,numpy.zeros(nn)))
        powers = numpy.row_stack((powers,numpy.array([0,0,1])))

        center = numpy.array([[self.project.nx/2.0,self.project.ny/2.0,0.0]])

        # Transformation from Warped State to Flattenned States

        tf = numpy.array(bp)
        tf[0] = 0

        x_tf = util.PolyM(variables, numpy.ones(1), numpy.array([[1,0,0]]))
        y_tf = util.PolyM(variables, numpy.ones(1), numpy.array([[0,1,0]]))
        z_tf = util.PolyM(variables, tf, powers)

        tf_center = z_tf.eval(center)
        tf[0] = - tf_center[0]

        z_tf = util.PolyM(variables, tf, powers)

        # Transformation from Flattened State to Warped State

        tf_inv = numpy.array(bp)
        tf_inv[0] = 0
        tf_inv[1:-1] = -tf_inv[1:-1]

        x_tf_inv = x_tf
        y_tf_inv = y_tf
        z_tf_inv = util.PolyM(variables, tf_inv, powers)

        tf_inv_center = z_tf_inv.eval(center)
        tf_inv[0] = - tf_inv_center[0]

        z_tf_inv = util.PolyM(variables, tf_inv, powers)

        # Misc
        
        x, y = numpy.mgrid[1:self.project.nx:50,1:self.project.ny:50]
        shape = x.shape
        s = (self.project.nx,self.project.nx,min(self.project.nx,self.project.ny)/3.0)
        
        # Evaluate Points of Surface Boundaries 1
        
        p1 = bp[:-1]
        p2 = tp[:-1]

        p1 = -p1
        p2 = -p2

        powers = numpy.array(util.powerOrder(order,dim=2)).T
        f1_wrp =  util.PolyM(['X','Y'], p1, powers)
        f2_wrp =  util.PolyM(['X','Y'], p2, powers)
        
        z1_wrp = f1_wrp.eval(numpy.column_stack((x.ravel(),y.ravel())))
        z2_wrp = f2_wrp.eval(numpy.column_stack((x.ravel(),y.ravel())))
        
        z1_wrp.resize(shape)
        z2_wrp.resize(shape)
        
        surf1 = [ (x,y,z1_wrp), (x,y,z2_wrp) ]
        
        # Surfaces corresponding to the flatenned specimen

        p1[:] = 0.0
        p2[:] = 0.0

        p1[0] = f1_wrp.eval(center)
        p2[0] = f2_wrp.eval(center)

        powers = numpy.array(util.powerOrder(order,dim=2)).T
        f1_flat =  util.PolyM(['X','Y'], p1, powers)
        f2_flat =  util.PolyM(['X','Y'], p2, powers)

        z1_flat = f1_flat.eval(numpy.column_stack((x.ravel(),y.ravel())))
        z2_flat = f2_flat.eval(numpy.column_stack((x.ravel(),y.ravel())))
        
        z1_flat.resize(shape)
        z2_flat.resize(shape)
        
        surf2 = [ (x,y,z1_flat), (x,y,z2_flat) ]
        
        # The points
        
        X1 = X
        
        X2 = X.copy()
        X2[:,2] = z_tf.eval(X)
        
        # Do the plot
        
        txbr.utilities.plot3DMarkers(X1[:,0],X1[:,1],X1[:,2],scale=s,surfaces=surf1)
        txbr.utilities.plot3DMarkers(X2[:,0],X2[:,1],X2[:,2],scale=s,surfaces=surf2)
        
        # Evaluate the boundaries from the fiducials
        
        XYZ_min = numpy.min(X2,axis=0)
        XYZ_max = numpy.max(X2,axis=0)

        XYZ_min[0] = 1
        XYZ_max[0] = self.project.nx
        
        XYZ_min[1] = 1
        XYZ_max[1] = self.project.ny
        
        XYZ_min[2] -= Z_PADDING
        XYZ_max[2] += Z_PADDING
        
        XYZ_min = numpy.rint(XYZ_min)
        XYZ_max = numpy.rint(XYZ_max)
        
        # Update the reconstruction object
                
        self.project.reconstruction.setOrigin(*XYZ_min.tolist())
        self.project.reconstruction.setEnd(*XYZ_max.tolist())
        self.project.reconstruction.setBottomPlane(0.0,0.0,0.0,XYZ_min[2])
        self.project.reconstruction.setTopPlane(0.0,0.0,0.0,XYZ_max[2])
        
        # Correct the modified Projection Map

        n2 = self.resid.n2
        nn2 = self.resid.nn2
        pp2 = numpy.array(self.resid.pp2).T

        n2_new = order*self.resid.n2
        nn2_new = util.numberOfTerms(n2_new,dim=3)
        pp2_new = numpy.array(util.powerOrder(n2_new,dim=3)).T

        B = numpy.resize(self.b,(2,self.resid.nn2,ntilt))
        B_new = numpy.zeros((2,nn2_new,ntilt))

        inv_poly = {'X':x_tf_inv,'Y':y_tf_inv,'Z':z_tf_inv}

        for itilt in range(ntilt):

            coefficients_x = numpy.squeeze(B[0,:,itilt])
            coefficients_y = numpy.squeeze(B[1,:,itilt])

            polyb_x = util.PolyM(variables,coefficients_x,pp2)
            polyb_y = util.PolyM(variables,coefficients_y,pp2)

            polyb_x = polyb_x.compose(inv_poly)
            polyb_y = polyb_y.compose(inv_poly)

            B_new[0,:,itilt] = polyb_x.extract_coefficients(pp2_new)
            B_new[1,:,itilt] = polyb_y.extract_coefficients(pp2_new)

        
        self.resid.extendProjectionMapOrder(n2_new, full_reset=False)
        
        self.resid.n2 = n2_new
        self.resid.nn2 = nn2_new
        
        self.b = B_new.ravel().tolist()
        
        
#        from enthought.mayavi import mlab
#        mlab.show()
#        
#        self.saveProjectionMapToProject(n2=n2_new, nterm=nn2_new, b2proj=B_new.ravel())
#        
#        import sys
#        sys.exit()




    def evaluateAlignmentTransform(self):
        '''In this routine, a 2D alignment transform is calculated'''
        
        log.info('Calculate alignment transform...')
        
        nn2 = self.resid.nn2
        ntilt = self.numberOfTilts

        b_ortho = numpy.zeros((2,nn2,ntilt))
        b_ortho[0,:4,:] = self.P[::2,:].T
        b_ortho[1,:4,:] = self.P[1::2,:].T
        
        b = numpy.resize(self.b,(2,nn2,ntilt))
        
        R = numpy.zeros((2,3,ntilt))
        
        for itilt in range(ntilt):
            
            M = numpy.zeros((4,3))
            
            M[0,0] = 1.0
            M[0,1:3] = b[:,0,itilt]
            M[1,1:3] = b[:,1,itilt]
            M[2,1:3] = b[:,2,itilt]
            M[3,1:3] = b[:,3,itilt]
            
            Minv = numpy.linalg.pinv(M)    
            
            b_ortho_x =  b_ortho[0,:4,itilt]
            b_ortho_y =  b_ortho[1,:4,itilt]
            
            R[0,:,itilt] = numpy.dot(Minv,b_ortho_x)
            R[1,:,itilt] = numpy.dot(Minv,b_ortho_y)
            
            
        log.info('Save the alignment tranforms to create an align stack...')

        nseries = self.project.numberOfEnabledSeries()

        for iseries in range(nseries):

            rg = self.seriesRange[iseries]
            
            filename = os.path.join(self.project.work_directory,self.seriesBasenames[iseries]) + 'tf2ali'
            #filename = '%s.tf2ali' %(self.seriesBasenames[iseries])
            
            f = open(filename,'w')
            
            for itilt in rg:
                f.write('%10.7f %10.7f %10.7f %10.7f %10.7f %10.7f\n' %(R[0,1,itilt],R[0,2,itilt],R[1,1,itilt],R[1,2,itilt],R[0,0,itilt],R[1,0,itilt]))
            
            f.close()


    def initializeStructureSet(self,objects=None):
        '''Initialize the Structure Set object'''
        
        npatch = self.numberOfPatches
        ntilt = self.numberOfTilts

        nn1 = self.resid.nn1
        nn4 = self.resid.nn4

        B = (self.resid.n2,numpy.array(self.b))

        xmax = self.project.nx
        ymax = self.project.ny

        self.structureSet = modl.StructureSet( B, xmax, ymax, directory=self.project.work_directory, \
                                               basename=self.project.basename )

        for ipatch in range(self.numberOfPatches):

            if objects!=None and objects.count(ipatch)==0:
                continue

            A = (self.resid.n1,numpy.array(self.a[ipatch:len(self.a):npatch]))
            C = (self.resid.n3,numpy.array(self.c[ipatch:len(self.c):npatch]))
            D = (self.resid.n4,numpy.array(self.d[ipatch:len(self.d):npatch]))

            pt = ipatch in self.points
            ln = ipatch in self.lines

            structure = modl.Structure( A, C, D, isAPoint=pt, isALine=ln)
            self.structureSet.addNewStructure(structure)

            if not ipatch in self.points:    # Use projective duality to initialize the structure
                log.info('Initialize structure %i/%i' %(ipatch+1,self.numberOfPatches))
                structure.initializeSurfaceMapping(*(self.glomap[ipatch]))
                self.a[ipatch:len(self.a):npatch] = structure.a[:]

        #if self.doPlot and False:
        if self.doPlot:
            self.structureSet.plot_structures(direct=True)
            self.structureSet.plot_structures()

        file = os.path.join( self.project.work_directory, self.project.basename + '.init.mod')
        self.structureSet.saveModel( self.project.nx, self.project.ny, \
                                     int(min(self.project.nx,self.project.ny)/2), \
                                     show=False, filename=file, direct=True)


    def saveStructureSet(self):

        nn1 = self.resid.nn1
        nn4 = self.resid.nn4

        B = (self.resid.n2,numpy.array(self.b))

        self.structureSet.nb,self.structureSet.b = B

        npatch = self.numberOfPatches
        ntilt = self.numberOfTilts

        for ipatch in range(self.numberOfPatches):

            A = (self.resid.n1,numpy.array(self.a[ipatch:len(self.a):npatch]))
            C = (self.resid.n3,numpy.array(self.c[ipatch:len(self.c):npatch]))
            D = (self.resid.n4,numpy.array(self.d[ipatch:len(self.d):npatch]))

            structure = self.structureSet.structures[ipatch]

            structure.update(A,C,D)

        nx = self.project.nx
        ny = self.project.ny
        nz = int(min(nx,ny)/2)

        self.structureSet.saveModel(nx,ny,nz)

        log.info(self.structureSet.info())


    def saveProjectionMapToProject(self, n2=None, nterm=None, b2proj=None):
        """Save the projection map into the project. It is stored under its
        general expression.
        """

        log.info("Save the new projection maps!")

        nserie = self.project.numberOfSeries()

        ntilt = self.numberOfTilts

        if n2==None or nterm==None or b2proj==None:
            n2 = self.resid.n2
            nterm = self.resid.nn2
            b2proj = self.b

        for index,basename in enumerate(self.seriesBasenames):

            serie = self.project.getSerie(basename)
            serie.projection.approximationOrder(approximationOrder=n2)

            rg = self.seriesRange[index]

            for iproj in range(nterm):
                for itilt in rg:
                    iexp = itilt - rg[0]
                    serie.projection.x_coefficients[iexp][iproj] = b2proj[iproj*ntilt+itilt]
                    serie.projection.y_coefficients[iexp][iproj] = b2proj[nterm*ntilt+iproj*ntilt+itilt]

            for itilt in rg:
                iexp = itilt - rg[0]
#                serie.projection.scaling_coefficients[iexp][0] = 1.0
#                serie.projection.scaling_coefficients[iexp][1:] = 0.0
                serie.projection.scaling_coefficients[iexp][1:] = 0.0
                for i in range(4):
                    serie.projection.scaling_coefficients[iexp][i] = self.b_scaling[ntilt*i+iexp]

            if serie.input=='st':
                log.info('Take prealignment into account!')
                for itilt in rg:
                    iexp = itilt - rg[0]
                    serie.projection.x_coefficients[iexp][0] -= serie.prealignTranslations[iexp,0]
                    serie.projection.y_coefficients[iexp][0] -= serie.prealignTranslations[iexp,1]

        self.project.saveAll()


    def loadParameters(self,file):
        """Load the a,b,c,d parameters from a file.
        """

        try:
            f = open(file)
            try:
                a = f.readline()
                b = f.readline()
                b_scaling = f.readline()
                c = f.readline()
                d = f.readline()
            finally:
                f.close()
        except IOError:
            pass

        a = [float(item) for item in a.split('\t')]
        b = [float(item) for item in b.split('\t')]
        b_scaling = [float(item) for item in b_scaling.split('\t')]
        c = [float(item) for item in c.split('\t')]
        d = [float(item) for item in d.split('\t')]

        return [a,b,b_scaling,c,d]


    def saveParameters(self,file):
        """Write the a,b,c,d parameters into a file.
        """

        f = open(file,'w')
        try:
            f.write('\t'.join(str(i) for i in self.resid.a) + '\n')
            f.write('\t'.join(str(i) for i in self.resid.b) + '\n')
            f.write('\t'.join(str(i) for i in self.resid.b_scaling) + '\n')
            f.write('\t'.join(str(i) for i in self.resid.c) + '\n')
            f.write('\t'.join(str(i) for i in self.resid.d) + '\n')
        finally:
            f.close()


    def info(self):
        """This function calculates and displays the different error terms (reprojection
        error, tangency error) in the cost function. It can be easily evaluated with respect
        to the tilt, patch and so on...
        """
        
        log.info('Residual Information')

        t_start = time.time()

        ntilt = self.numberOfTilts
        npatch = self.numberOfPatches

        e = self.resid.value()

        if e==None:  # Cannot do the adequate plots
            log.info('Skip info routine!')
            return

        e1,e2 = e
        res1,res2 = numpy.sqrt(e1),numpy.sqrt(e2)
        res = res1 + res2
        
        E1 = e1.sum()
        E2 = e2.sum()
        
        d = res1.sum()/self.mask.sum()

        for itilt in range(ntilt):
            for ipatch in range(npatch):
                e1_ = e1[itilt,ipatch]
                e2_ = e2[itilt,ipatch]
                log.debug('itilt=%-3i ipatch=%-3i  E=%6.2e  E1=%6.2e  E2=%6.2e' %(itilt,ipatch,e1_+e2_,e1_,e2_))
                #print 'itilt=%-3i ipatch=%-3i  E=%6.2e  E1=%6.2e  E2=%6.2e' %(itilt,ipatch,e1_+e2_,e1_,e2_)

        log.info('                     Total Error:  %6.2e = %6.2e + %6.2e' %(E1+E2,E1,E2))
        log.info('           Error by tilt & patch:  %6.2e = %6.2e + %6.2e' %((E1+E2)/ntilt/npatch,E1/ntilt/npatch,E2/ntilt/npatch))
        log.info('    Error by tilt & patch & axis:  %6.2e = %6.2e + %6.2e' %((E1+E2)/ntilt/npatch/2.0,E1/ntilt/npatch/2.0,E2/ntilt/npatch/2.0))
        log.info('Mean Reprojection Distance Error:  %6.2e' %d)

        for itilt in range(ntilt):
            E1byTilt = e1.sum(axis=1)
            E2byTilt = e2.sum(axis=1)
            EbyTilt = E1byTilt + E2byTilt
            log.info('  Tilt: %3i/%-3i    E1=%-10.2f  E2=%-10.2f  All Patches: %s' \
                     %(itilt,ntilt,E1byTilt[itilt],E2byTilt[itilt],numpy.all(self.mask[itilt,:])))

        for ipatch in range(npatch):
            E1byPatch = e1.sum(axis=0)
            E2byPatch = e2.sum(axis=0)
            EbyPatch = E1byPatch + E2byPatch
            log.info(' Track: %3i/%-3i    E1=%-10.2f  E2=%-10.2f  All Tilts: %s' \
                     %(ipatch,npatch,E1byPatch[ipatch],E2byPatch[ipatch],numpy.all(self.mask[:,ipatch])))

        t_end = time.time()

        log.debug('Time to calculate direct Error: %f' %(t_end-t_start))
        
        # Do some plottings

        errorByTilt = True and self.doPlot
        errorByPatch = True and self.doPlot
        errorByTiltAndPatch = True and self.doPlot
        
        align_directory = os.path.join(self.project.work_directory,align_dir)
           
        if errorByTilt: 
            txbr.utilities.plotErrorByTilt( E1byTilt, E2byTilt, EbyTilt, \
                                            directory=align_directory, basename=self.project.basename )
        
        if errorByPatch: 
            txbr.utilities.plotErrorByPatch( E1byPatch, E2byPatch, EbyPatch, \
                                             directory=align_directory, basename=self.project.basename )
 
        if errorByTiltAndPatch: 
            txbr.utilities.plotErrorByTiltAndPatch( res1, res2, res, \
                                             directory=align_directory, basename=self.project.basename )
       

    def generateAlignLogFile(self,threshold_error=3.0):
        '''Geneate an align log file for the point-like markers of each series'''
        
        if len(self.lines)!=0 or len(self.surfaces)!=0: return
        
        log.info('Generate the alignment log file!')
                
        data = numpy.zeros((self.numberOfTilts,len(self.points),7))

        for itilt in range(self.numberOfTilts):
            for ipatch in self.points:
                x,y = self.tracks[itilt,ipatch,:2,0]
                x_p,y_p = self.resid.project(itilt,ipatch)
                data[itilt,ipatch,0] = itilt
                data[itilt,ipatch,1] = ipatch
                data[itilt,ipatch,2] = x*self.mask[itilt,ipatch]
                data[itilt,ipatch,3] = y*self.mask[itilt,ipatch]
                data[itilt,ipatch,4] = (x_p-x)*self.mask[itilt,ipatch]
                data[itilt,ipatch,5] = (y_p-y)*self.mask[itilt,ipatch]
                data[itilt,ipatch,6] = math.sqrt(data[itilt,ipatch,4]**2 + data[itilt,ipatch,5]**2)
        
        for iseries,basename in enumerate(self.seriesBasenames):

            error_file = "align." + basename + ".log"
            error_file = os.path.join(self.project.work_directory,align_dir,error_file)
            
            f = open(error_file,'w')
            
            f.write('         Projection points with large residuals\n')
            f.write(' obj  cont  view   index coordinates    residuals    # of\n')
            f.write('   #     #     #      X         Y        X      Y    S.D.\n')
            
            tilt_range = self.seriesRange[iseries]
            ntilt = self.tlts[iseries]
            
            data_series = numpy.resize(data[tilt_range],(ntilt*len(self.points),7))
            
            indices = numpy.argsort(data_series[:,6])
            data_series = data_series[indices[::-1]]
            
            std_dev = numpy.std(data_series[:,6])
            
            for s in data_series:
                if s[6]<threshold_error*std_dev: 
                    continue
                itilt,ipatch,X,Y,resX,resY = s[:6]
                values = {'object':1}
                values['contour'] = ipatch + 1
                values['view'] = itilt + 1 - tilt_range[0]
                values['X'] = X
                values['Y'] = Y
                values['resX'] = resX
                values['resY'] = resY
                values['SD'] = s[6]/std_dev
                f.write('%(object)4.0f %(contour)5.0f %(view)5.0f %(X)9.2f %(Y)9.2f %(resX)6.2f %(resY)6.2f %(SD)6.2f\n' %values)
            
            f.close()
 

    def plot_individual_contour_mappings(self):

        log.info('Plot individual contour mapping')

        # First build the array containing the experimental points

        xy_exp = []

        for mod in self.models:
            for object in mod.objects:
                for contour in object.contours:
                    xy_exp.append(contour.points[:,:2])

        xy_exp = numpy.row_stack(xy_exp)
        (x_exp,y_exp) =  numpy.array_split(xy_exp,2,axis=1)

        x_exp = x_exp.ravel()
        y_exp = y_exp.ravel()

        # Second build the array containing the experimental points

        xy_ct_pts,xy_ct = [],[]

        n3 = self.resid.n3
        nn3 = self.resid.nn3
        orders = [n3]

        t_pt = numpy.zeros((1,1))

        t_surf = numpy.linspace(0.0,1.0,num=20)
        t_surf.resize((t_surf.size,1))

        for mod in self.models:
            index0 = mod.tiltOffset
            for object in mod.objects:
                iobject = object.indexOfObject
                if object.isAPoint():
                    t = t_pt
                else:
                    t = t_surf
                for contour in object.contours:
                    #itilt = index0 + contour.indexOfContour
                    z = int(round(contour.zExtensionSet().pop(),0))
                    itilt = index0 + z
                    coeff_x = self.tracks[itilt,iobject,0,:nn3]
                    coeff_y = self.tracks[itilt,iobject,1,:nn3]
                    pc_x = util.Poly(coeff_x,orders)
                    pc_y = util.Poly(coeff_y,orders)
                    if object.isAPoint():
                        xy_ct_pts.append(pc_x.eval(t))
                        xy_ct_pts.append(pc_y.eval(t))
                    else:
                        xy_ct.append(pc_x.eval(t))
                        xy_ct.append(pc_y.eval(t))

        if len(xy_ct)!=0:
            xc = numpy.column_stack(xy_ct[::2])
            yc = numpy.column_stack(xy_ct[1::2])
            xy_ct = numpy.row_stack((xc,yc))
            (x_ct,y_ct) = numpy.array_split(xy_ct,2,axis=0)
        else:
            x_ct,y_ct = numpy.zeros((0)),numpy.zeros((0))

        if len(xy_ct_pts)!=0:
            xc_pts = numpy.column_stack(xy_ct_pts[::2])
            yc_pts = numpy.column_stack(xy_ct_pts[1::2])
            xy_ct_pts = numpy.row_stack((xc_pts,yc_pts))
            (x_ct_pts,y_ct_pts) = numpy.array_split(xy_ct_pts,2,axis=0)
        else:
            (x_ct_pts,y_ct_pts) = numpy.zeros((0)),numpy.zeros((0))

        # do the plotting

        nx,ny = self.project.nx,self.project.ny

        f = pylab.figure()

        pylab.scatter(x_exp,y_exp,c='green')
        pylab.plot(x_ct_pts,y_ct_pts,'g:')    # contours
        pylab.plot(x_ct,y_ct,'g:')    # Point-like contours

        pylab.xlim(0,nx)
        pylab.ylim(0,ny)

        #pylab.title(r'Individual Contour mapping')
        pylab.xlabel(r'$x$')
        pylab.ylabel(r'$y$')
        
        pylab.title(r'Individual Contours')


    def plot_projections(self):
        '''This routine plots the projection coefficients as a function of the tilt
        index'''

        ntilt = self.numberOfTilts
        nterm = self.resid.nn2
  
        P_ = numpy.resize(self.b,(2,nterm,ntilt))
        
        P_id = numpy.resize(self.P,(ntilt,2,4))
        P_id = numpy.rollaxis(P_id,0,3)
        
        txbr.utilities.plot_projections(P_, P_id)


    def plot_contour_reprojection( self, itilt=None, ipatch=None, t0=0.0, t1=1.0, limits=None):
        """This function displays the reprojection error for a given tilt
        and a given patch. If no tilt is specified, all available tilts are
        displayed. If no patch is specified, all patches are displayed.
        """

        log.info('Plot Contour Reprojections.')

        try:
            self.resid.Pvars
            self.resid.P1
            self.resid.P2
        except AttributeError:
            return

        t_start = time.time()

        # Define the set of tilts and patches
        
        if itilt==None:
            tilts = range(self.numberOfTilts)
        else:
            tilts = [itilt]
            
        if ipatch==None:
            patches = range(self.numberOfPatches)
        else:
            patches = [ipatch]

        # Calculate the projection error from the residual object

        xdata, ydata = [],[]

        for ipatch_ in patches:
            x_, y_ = [], []
            for itilt_ in tilts:
                if self.resid.Emask[itilt_,ipatch_]==0: continue
                _xy_ = self.resid.project(itilt_,ipatch_)
                if _xy_==None: return
                x_.append(_xy_[0])
                y_.append(_xy_[1])
            xdata.append(numpy.column_stack(x_))
            ydata.append(numpy.column_stack(y_))

        # Get the tracks (from c) for the set of tilt and patches

        pts = []

        for iobj in patches:
            for model in self.models:
                pts.append(model.objects[iobj].points())

        pts = numpy.row_stack(pts)
        
        pts = [pt for pt in pts if pt[2] in tilts]
        pts  = numpy.row_stack(pts)
        
#        args = numpy.argwhere((pts[:,2]<itilt0+ntilt)*(pts[:,2]>=itilt0))
#        pts = pts[args.ravel(),:2]


#        print pts.shape
#        
#        (x,y) = numpy.array_split(pts,2,axis=1)
        
        x = pts[:,0]
        y = pts[:,1]

        try:
            for idata in range(ndata):
                print 'idata=%i exp=(%f,%f)  rep=(%f,%f)' %(idata,x[idata],y[idata],xdata[idata,0],ydata[idata,0])
        except:
            pass
        
        # Do the plotting

        pylab.figure()

        pylab.scatter(x.ravel(),y.ravel(),c = 'green',label='Tracks')

        nseries = self.project.numberOfEnabledSeries()

#        for iseries in range(nseries):
#            for ipatch_ in patches:
#                rg = self.seriesRange[iseries]
#                pylab.plot(xdata[ipatch_][rg], ydata[ipatch_][rg],'r:1',label='Reprojected Data')

        for i in range(len(patches)):
            pylab.plot(xdata[i], ydata[i],'r:1',label='Reprojected Data')


        pylab.legend(('Reprojected Data',))

        #pylab.title(r'Contour Reprojection')
        pylab.xlabel(r'x')
        pylab.ylabel(r'y')

        if limits!=None:
            pylab.axis(limits)

        if itilt!=None and ipatch!=None:
            pylab.figtext(0.15,0.85,'Patch \#%i/%i  Tilt \#%i/%i' %(ipatch+1,npatch,itilt+1,ntilt),fontsize=14)
        elif itilt!=None:
            pylab.figtext(0.15,0.85,'Tilt \#%i/%i' %(itilt+1,self.numberOfTilts-1),fontsize=14)
        elif ipatch!=None:
            pylab.figtext(0.15,0.85,'Patch \#%i/%i' %(ipatch+1,self.numberOfPatches-1),fontsize=14)

        file = self.project.basename + '_reproj.png'
        file = os.path.join(self.project.work_directory,align_dir,file)

        pylab.savefig(file,format='png')

        t_end = time.time()
    

        log.debug('Time to do the reprojection plot: %f' %(t_end-t_start))



    def plot_DSA_points_reprojection(self):
        """Reproject the tangent points of the surface with the electron beam
        obtained with the Dual Space Approach.
        """

        xy = []

        for mod in self.models:
            index0 = mod.tiltOffset
            for object in mod.objects:
                iobject = object.indexOfObject
                for contour in object.contours:
                    for point in contour.points:
                        indexOfTilt = index0 + int(round(point[2],0))
                        xy.append(point[:2])

        (xdata,ydata) = numpy.array_split(numpy.array(xy),2,axis=1)

        xdata = numpy.resize(xdata,(xdata.size))
        ydata = numpy.resize(ydata,(ydata.size))

        x,y = [],[]

        for structure in self.structureSet.structures:
            try:
                indicesOfTilts = structure.indicesOfTilts
                XYZ = structure.points_OC
            except AttributeError:
                continue
            (ntilt,ndata,dim) = XYZ.shape
            for itilt in range(ntilt):
                indexOfTilt = indicesOfTilts[itilt]
                x.append(self.P[2*indexOfTilt,0] + numpy.tensordot(XYZ[itilt,:,:],self.P[2*indexOfTilt,1:4],axes=([1],[0])))
                y.append(self.P[2*indexOfTilt+1,0] + numpy.tensordot(XYZ[itilt,:,:],self.P[2*indexOfTilt+1,1:4],axes=([1],[0])))

        # Do the plot

        pylab.figure()

        pylab.scatter(xdata, ydata)
        for itilt in range(len(x)):
            pylab.plot(x[itilt],y[itilt],'r:')

        pylab.title(r'Reprojection of Tangent Points obtained from Dual Space Approach',fontsize=16,color='r')
        pylab.xlabel(r'x',fontsize=18)
        pylab.ylabel(r'y',fontsize=18)

        nx,ny = self.project.nx,self.project.ny

        pylab.xlim(0,nx)
        pylab.ylim(0,ny)

        file = self.project.basename + '_reproject_DSA.png'
        file = os.path.join(self.project.work_directory,align_dir,file)
        pylab.savefig(file,format='png')