import numpy,numpy.linalg
import pylab,scipy.optimize
import logging,logging.config
import txbr

from txbr import LOG_CONF
logging.config.fileConfig(LOG_CONF)

log = logging.getLogger('align')

def rotation_axis(B,frame,ref_t_elements,smpl_t_elements,number_of_sections=5,doPlot=False):
    '''This routine is used to calculate the rotation axis of a series.
    Variable B is a numpy array (of shape (2,4,ntilt)) describing the projection map.
    T is a numpy array for the transfer matrix
    '''

    log.info('Calculate envelope')
    log.info('Number of Sections used: %i' %number_of_sections)

    frame = numpy.asarray(frame)    # Frame of the reconstruction (sample reference)

    tc_r,mc_r = ref_t_elements
    tc_s,mc_s = smpl_t_elements

    ntilt = B.shape[2]

    mc_r_inv = numpy.linalg.pinv(mc_r)
    tc_r_inv = - numpy.dot(mc_r_inv,tc_r)

    mc_s_inv = numpy.linalg.pinv(mc_s)
    tc_s_inv = - numpy.dot(mc_s_inv,tc_s)

    # Reference Contribution

    P_r = numpy.tensordot(B[:,1:,:],mc_r_inv,axes=([1],[0]))
    P_r = numpy.tensordot(mc_r[:2,:2],P_r,axes=([1],[0]))

    T_r = tc_r[:2] + numpy.tensordot(B[:,0,:],mc_r[:2,:2],axes=([0],[1]))
    T_r += numpy.squeeze(numpy.tensordot(numpy.tensordot(B[:,1:,:],mc_r[:2,:2],axes=([0],[1])),tc_r_inv,axes=([0],[0])))
    T_r = T_r.swapaxes(0,1)

    # Sample Contribution

    T_r += numpy.squeeze(numpy.tensordot(P_r,tc_s_inv,axes=([2],[0])))
    P_r = numpy.tensordot(P_r,mc_s_inv,axes=([2],[0]))





#    # Sample Contribution
#
#    T_r += numpy.squeeze(numpy.tensordot(P_r,tc_s_inv,axes=([2],[0])))
#    P_r = numpy.tensordot(P_r,mc_s_inv,axes=([2],[0]))







#    sampleTransfer = numpy.linalg.pinv(mc_s)
#    fra_= numpy.dot(sampleTransfer,numpy.array([[xmin,xmax],[ymin,ymax],[zmin,zmax]]))
#    nx = 490
#    ny = 640
#    P0 = numpy.array([nx/2.0,ny/2.0,0.0])
#    P0 = P0 - numpy.dot(sampleTransfer,P0)
#
#    fra_[:,0] = fra_[:,0] + P0
#    fra_[:,1] = fra_[:,1] + P0

    xmin,ymin,zmin = numpy.min(frame,axis=1)
    xmax,ymax,zmax = numpy.max(frame,axis=1)
    zmin = -max(xmax,ymax)/2.0
    zmax = -zmin
    log.info('(xmin,xmax)=(%.2f,%.2f)' %(xmin,xmax))
    log.info('(ymin,ymax)=(%.2f,%.2f)' %(ymin,ymax))
    log.info('(zmin,zmax)=(%.2f,%.2f)' %(zmin,zmax))


#    xmin,ymin,zmin = numpy.min(ref_t_frame,axis=0)
#    xmax,ymax,zmax = numpy.max(ref_t_frame,axis=0)
#
#    zmin = -max(xmax,ymax)/2.0
#    zmax = -zmin
#
#    log.info('(xmin,xmax)=(%.2f,%.2f)' %(xmin,xmax))
#    log.info('(ymin,ymax)=(%.2f,%.2f)' %(ymin,ymax))
#    log.info('(zmin,zmax)=(%.2f,%.2f)' %(zmin,zmax))



    # backproject the limiting points in the rotation reference frame

    half_width = (xmax-xmin)/2.0

    sections = numpy.linspace(ymin,ymax,num=number_of_sections)
#    print 'Sections at: %s' %(str(sections))

    px = numpy.zeros((ntilt,number_of_sections,3))

    for isect in range(number_of_sections):
        px[:,isect,0] = T_r[0,:] + P_r[0,:,1]*sections[isect]
        px[:,isect,1] = P_r[0,:,0]
        px[:,isect,2] = P_r[0,:,2]

    tgts_x_min = px[:,:,:].copy()
    tgts_x_max = px[:,:,:].copy()

    tgts_x_min[:,:,0] = tgts_x_min[:,:,0] - xmin
    tgts_x_max[:,:,0] = tgts_x_max[:,:,0] - xmax

    tgts_x = numpy.row_stack((tgts_x_min,tgts_x_max))

    a,b = half_width,half_width
    center_x,center_y = half_width,0.0
    angle,eps = 0.0,1.0

    xopt = numpy.array([a,b,center_x,center_y,angle,eps])
    xopt = numpy.tile(xopt,number_of_sections)

    xopt = scipy.optimize.fmin_ncg(ellipse_function,xopt,ellipse_der,fhess=ellipse_hess,args=(tgts_x,),avextol=1.e-8,maxiter=50)

    xopt = numpy.resize(xopt,(number_of_sections,6))

    xopt[:,4] = numpy.where(numpy.abs(xopt[:,4])>numpy.pi/2.0,numpy.arctan(numpy.tan(xopt[:,4])),xopt[:,4])

    swapaxes = numpy.abs(xopt[:,0])<numpy.abs(xopt[:,1])
    xopt[:,4] = numpy.where(swapaxes,xopt[:,4]-numpy.sign(xopt[:,4])*numpy.pi/2.0,xopt[:,4])
    tmp = xopt[:,0].copy()
    xopt[:,0] = numpy.where(swapaxes,xopt[:,1],xopt[:,0])
    xopt[:,1] = numpy.where(swapaxes,tmp[:],xopt[:,1])

    log.info('  a         b         X0         Y0       angle      eps       Z0')
    for index,row in enumerate(xopt):
        data = [u for u in row]
        data.append(sections[index])
        log.info('%6.2f    %6.2f    %6.2f    %6.2f    %6.2f    %6.2f    %6.2f' %tuple(data))

    # Do the plotting
    
    if doPlot:

        pylab.figure()
    
        plot_tangents(tgts_x,[zmin,zmax])
    
        for row in xopt:
            a,b,center_x,center_y,angle,eps = row
            plot_ellipse(a,b,center_x,center_y,angle,'left')
            plot_ellipse(a/eps,b/eps,center_x,center_y,angle,'right')
    
        pylab.xlim(xmin,xmax)
        pylab.ylim(zmin,zmax)


    x = xopt[:,2]
    y = xopt[:,3]
    z = numpy.asarray(sections,dtype='float')

    def residual(parameter, x, y, z):
        x0,y0,z0,u,v = parameter
        res = []
        res.append((y-y0)-(z-z0)*v)
        res.append((z-z0)*u-(x-x0))
        res.append((x-x0)*v-(y-y0)*u)
        return numpy.concatenate(res)

    params0 = [0.,0.,0.,0.,0.]
    result = scipy.optimize.leastsq(residual, params0, (x,y,z))
    x0,y0,z0,u,v = result[0]

    # Rotation axis in the

    O = numpy.array([x0,z0,y0])
    N = numpy.array([u,1,v])
    N = N/numpy.sqrt(numpy.sum(N**2))

#    print 'Relative Frame'
#    print 'Axis Point: %s' %O
#    print 'Axis Vector: %s' %N

    OO = tc_r_inv + numpy.dot(mc_r_inv,O)
    NN = numpy.dot(mc_r_inv,N)

#    print 'Absolute'
#    print 'Axis Point: %s' %OO
#    print 'Axis Vector: %s' %NN

    return (OO,NN)





def ellipse_function(X,tgts_x):

    number_of_tilts = tgts_x.shape[0]/2
    number_of_sections = tgts_x.shape[1]

    phi = X[4::6]
    R = numpy.array([[numpy.cos(phi),-numpy.sin(phi)],[numpy.sin(phi),numpy.cos(phi)]])

    eps = numpy.ones((2*number_of_tilts,number_of_sections))
    eps[number_of_tilts:,:] *= X[5::6]
    eps = eps[:,:,numpy.newaxis]

    T1 = tgts_x*eps
    Y1 = numpy.row_stack((numpy.ones(number_of_sections),X[2::6],X[3::6]))
    q1 = numpy.tensordot(Y1,T1,axes=([0],[2]))
    q1 = numpy.diagonal(q1,axis1=0,axis2=2)

    T2 = numpy.tensordot(tgts_x[:,:,1:3],R,axes=([2],[0]))**2
    T2 = numpy.diagonal(T2,axis1=1,axis2=3)
    Y2 = numpy.row_stack((X[0::6]**2,X[1::6]**2))
    q2 = numpy.tensordot(Y2,T2,axes=([0],[1]))
    q2 = numpy.diagonal(q2,axis1=0,axis2=2)

    err = q1**2/q2-1

    Err= numpy.sum(err**2)

    return Err


def ellipse_der(X,tgts_x):

    der = numpy.zeros_like(X)

    number_of_tilts = tgts_x.shape[0]/2
    number_of_sections = tgts_x.shape[1]

    phi = X[4::6]

    R = numpy.array([[numpy.cos(phi),-numpy.sin(phi)],[numpy.sin(phi),numpy.cos(phi)]])
    dR = numpy.array([[-numpy.sin(phi),-numpy.cos(phi)],[numpy.cos(phi),-numpy.sin(phi)]])

    eps = numpy.ones((2*number_of_tilts,number_of_sections))
    eps[number_of_tilts:,:] *= X[5::6]
    eps = eps[:,:,numpy.newaxis]

    T1 = tgts_x*eps
    dT1 = tgts_x.copy()
    dT1[:number_of_tilts,:,:] = 0
    Y1 = numpy.row_stack((numpy.ones(number_of_sections),X[2::6],X[3::6]))
    q1 = numpy.tensordot(Y1,T1,axes=([0],[2]))
    q1 = numpy.diagonal(q1,axis1=0,axis2=2)
    dq1 = numpy.tensordot(Y1,dT1,axes=([0],[2]))
    dq1 = numpy.diagonal(dq1,axis1=0,axis2=2)

    T2 = numpy.tensordot(tgts_x[:,:,1:3],R,axes=([2],[0]))**2
    T2 = numpy.diagonal(T2,axis1=1,axis2=3)
    dT2 = 2.0*numpy.tensordot(tgts_x[:,:,1:3],dR,axes=([2],[0]))*numpy.tensordot(tgts_x[:,:,1:3],R,axes=([2],[0]))
    dT2 = numpy.diagonal(dT2,axis1=1,axis2=3)
    Y2 = numpy.row_stack((X[0::6]**2,X[1::6]**2))
    q2 = numpy.tensordot(Y2,T2,axes=([0],[1]))
    q2 = numpy.diagonal(q2,axis1=0,axis2=2)
    dq2 = numpy.tensordot(Y2,dT2,axes=([0],[1]))
    dq2 = numpy.diagonal(dq2,axis1=0,axis2=2)

    err = q1**2/q2-1;

    der_err_0 = -2.0*X[0::6]*T2[:,0,:]*q1**2/q2**2
    der_err_1 = -2.0*X[1::6]*T2[:,1,:]*q1**2/q2**2
    der_err_2 = 2.0*T1[:,:,1]*q1/q2
    der_err_3 = 2.0*T1[:,:,2]*q1/q2
    der_err_4 = -dq2*q1**2/q2**2
    der_err_5 = 2.0*dq1*q1/q2

    der[0::6] = numpy.sum(2*err*der_err_0,axis=0)
    der[1::6] = numpy.sum(2*err*der_err_1,axis=0)
    der[2::6] = numpy.sum(2*err*der_err_2,axis=0)
    der[3::6] = numpy.sum(2*err*der_err_3,axis=0)
    der[4::6] = numpy.sum(2*err*der_err_4,axis=0)
    der[5::6] = numpy.sum(2*err*der_err_5,axis=0)

    return der


def ellipse_hess(X,tgts_x):

    n = X.size
    hess = numpy.zeros((n,n))

    number_of_tilts = tgts_x.shape[0]/2
    number_of_sections = tgts_x.shape[1]

    phi = X[4::6]

    R = numpy.array([[numpy.cos(phi),-numpy.sin(phi)],[numpy.sin(phi),numpy.cos(phi)]])
    dR = numpy.array([[-numpy.sin(phi),-numpy.cos(phi)],[numpy.cos(phi),-numpy.sin(phi)]])

    eps = numpy.ones((2*number_of_tilts,number_of_sections))
    eps[number_of_tilts:,:] *= X[5::6]
    eps = eps[:,:,numpy.newaxis]

    T1 = tgts_x*eps
    dT1 = tgts_x.copy()
    dT1[:number_of_tilts,:,:] = 0
    Y1 = numpy.row_stack((numpy.ones(number_of_sections),X[2::6],X[3::6]))
    q1 = numpy.tensordot(Y1,T1,axes=([0],[2]))
    q1 = numpy.diagonal(q1,axis1=0,axis2=2)
    dq1 = numpy.tensordot(Y1,dT1,axes=([0],[2]))
    dq1 = numpy.diagonal(dq1,axis1=0,axis2=2)

    T2 = numpy.tensordot(tgts_x[:,:,1:3],R,axes=([2],[0]))**2
    T2 = numpy.diagonal(T2,axis1=1,axis2=3)
    dT2 = 2.0*numpy.tensordot(tgts_x[:,:,1:3],dR,axes=([2],[0]))*numpy.tensordot(tgts_x[:,:,1:3],R,axes=([2],[0]))
    dT2 = numpy.diagonal(dT2,axis1=1,axis2=3)
    dT2d2 = -2.0*numpy.tensordot(tgts_x[:,:,1:3],R,axes=([2],[0]))**2 + 2.0*numpy.tensordot(tgts_x[:,:,1:3],dR,axes=([2],[0]))**2
    dT2d2 = numpy.diagonal(dT2d2,axis1=1,axis2=3)
    Y2 = numpy.row_stack((X[0::6]**2,X[1::6]**2))
    q2 = numpy.tensordot(Y2,T2,axes=([0],[1]))
    q2 = numpy.diagonal(q2,axis1=0,axis2=2)
    dq2 = numpy.tensordot(Y2,dT2,axes=([0],[1]))
    dq2 = numpy.diagonal(dq2,axis1=0,axis2=2)
    dq2d2 = numpy.tensordot(Y2,dT2d2,axes=([0],[1]))
    dq2d2 = numpy.diagonal(dq2d2,axis1=0,axis2=2)

    err = q1**2/q2-1;

    der_err_0 = -2.0*X[0::6]*T2[:,0,:]*q1**2/q2**2
    der_err_1 = -2.0*X[1::6]*T2[:,1,:]*q1**2/q2**2
    der_err_2 = 2.0*T1[:,:,1]*q1/q2
    der_err_3 = 2.0*T1[:,:,2]*q1/q2
    der_err_4 = -dq2*q1**2/q2**2
    der_err_5 = 2.0*dq1*q1/q2

    hess_err_00 = der_err_0/X[0::6] + 8.0*X[0::6]**2*T2[:,0,:]**2*q1**2/q2**3
    hess_err_01 = 8.0*X[0::6]*T2[:,0,:]*X[1::6]*T2[:,1,:]*q1**2/q2**3
    hess_err_02 = -4.0*X[0::6]*T2[:,0,:]*T1[:,:,1]*q1/q2**2
    hess_err_03 = -4.0*X[0::6]*T2[:,0,:]*T1[:,:,2]*q1/q2**2
    hess_err_04 = -2.0*X[0::6]*dT2[:,0,:]*q1**2/q2**2 + 4.0*X[0::6]*T2[:,0,:]*dq2*q1**2/q2**3
    hess_err_05 = -4.0*X[0::6]*T2[:,0,:]*dq1*q1/q2**2

    hess_err_11 = der_err_1/X[1::6] + 8.0*X[1::6]**2*T2[:,1,:]**2*q1**2/q2**3
    hess_err_12 = -4.0*X[1::6]*T2[:,1,:]*T1[:,:,1]*q1/q2**2
    hess_err_13 = -4.0*X[1::6]*T2[:,1,:]*T1[:,:,2]*q1/q2**2
    hess_err_14 = -2.0*X[1::6]*dT2[:,1,:]*q1**2/q2**2 + 4.0*X[1::6]*T2[:,1,:]*dq2*q1**2/q2**3
    hess_err_15 = -4.0*X[1::6]*T2[:,1,:]*dq1*q1/q2**2

    hess_err_22 = 2.0*T1[:,:,1]**2/q2
    hess_err_23 = 2.0*T1[:,:,1]*T1[:,:,2]/q2
    hess_err_24 = -2.0*T1[:,:,1]*dq2*q1/q2**2
    hess_err_25 = 2.0*dT1[:,:,1]*q1/q2 + 2.0*T1[:,:,1]*dq1/q2

    hess_err_33 = 2.0*T1[:,:,2]*T1[:,:,2]/q2
    hess_err_34 = -2.0*T1[:,:,2]*dq2*q1/q2**2
    hess_err_35 = 2.0*dT1[:,:,2]*q1/q2 + 2.0*T1[:,:,2]*dq1/q2

    hess_err_44 = -dq2d2*q1**2/q2**2 + 2.0*dq2**2*q1**2/q2**3
    hess_err_45 = -2.0*dq2*dq1*q1/q2**2

    hess_err_55 = 2.0*dq1**2/q2

    hess[0::6,0::6] = 2*numpy.tensordot(der_err_0,der_err_0,axes=([0],[0])) + 2*numpy.sum(err*hess_err_00,axis=0)
    hess[0::6,1::6] = 2*numpy.tensordot(der_err_0,der_err_1,axes=([0],[0])) + 2*numpy.sum(err*hess_err_01,axis=0)
    hess[0::6,2::6] = 2*numpy.tensordot(der_err_0,der_err_2,axes=([0],[0])) + 2*numpy.sum(err*hess_err_02,axis=0)
    hess[0::6,3::6] = 2*numpy.tensordot(der_err_0,der_err_3,axes=([0],[0])) + 2*numpy.sum(err*hess_err_03,axis=0)
    hess[0::6,4::6] = 2*numpy.tensordot(der_err_0,der_err_4,axes=([0],[0])) + 2*numpy.sum(err*hess_err_04,axis=0)
    hess[0::6,5::6] = 2*numpy.tensordot(der_err_0,der_err_5,axes=([0],[0])) + 2*numpy.sum(err*hess_err_05,axis=0)

    hess[1::6,1::6] = 2*numpy.tensordot(der_err_1,der_err_1,axes=([0],[0])) + 2*numpy.sum(err*hess_err_11,axis=0)
    hess[1::6,2::6] = 2*numpy.tensordot(der_err_1,der_err_2,axes=([0],[0])) + 2*numpy.sum(err*hess_err_12,axis=0)
    hess[1::6,3::6] = 2*numpy.tensordot(der_err_1,der_err_3,axes=([0],[0])) + 2*numpy.sum(err*hess_err_13,axis=0)
    hess[1::6,4::6] = 2*numpy.tensordot(der_err_1,der_err_4,axes=([0],[0])) + 2*numpy.sum(err*hess_err_14,axis=0)
    hess[1::6,5::6] = 2*numpy.tensordot(der_err_1,der_err_5,axes=([0],[0])) + 2*numpy.sum(err*hess_err_15,axis=0)

    hess[2::6,2::6] = 2*numpy.tensordot(der_err_2,der_err_2,axes=([0],[0])) + 2*numpy.sum(err*hess_err_22,axis=0)
    hess[2::6,3::6] = 2*numpy.tensordot(der_err_2,der_err_3,axes=([0],[0])) + 2*numpy.sum(err*hess_err_23,axis=0)
    hess[2::6,4::6] = 2*numpy.tensordot(der_err_2,der_err_4,axes=([0],[0])) + 2*numpy.sum(err*hess_err_24,axis=0)
    hess[2::6,5::6] = 2*numpy.tensordot(der_err_2,der_err_5,axes=([0],[0])) + 2*numpy.sum(err*hess_err_25,axis=0)

    hess[3::6,3::6] = 2*numpy.tensordot(der_err_3,der_err_3,axes=([0],[0])) + 2*numpy.sum(err*hess_err_33,axis=0)
    hess[3::6,4::6] = 2*numpy.tensordot(der_err_3,der_err_4,axes=([0],[0])) + 2*numpy.sum(err*hess_err_34,axis=0)
    hess[3::6,5::6] = 2*numpy.tensordot(der_err_3,der_err_5,axes=([0],[0])) + 2*numpy.sum(err*hess_err_35,axis=0)

    hess[4::6,4::6] = 2*numpy.tensordot(der_err_4,der_err_4,axes=([0],[0])) + 2*numpy.sum(err*hess_err_44,axis=0)
    hess[4::6,5::6] = 2*numpy.tensordot(der_err_4,der_err_5,axes=([0],[0])) + 2*numpy.sum(err*hess_err_45,axis=0)

    hess[5::6,5::6] = 2*numpy.tensordot(der_err_5,der_err_5,axes=([0],[0])) + 2*numpy.sum(err*hess_err_55,axis=0)

    for i in range(number_of_sections):
        for j in range(i+1,number_of_sections):
            hess[6*i:6*i+6,6*j:6*j+6] = 0
            hess[6*j:6*j+6,6*i:6*i+6] = 0

    # Symmetryze the Hessian

    indiag = [range(n),range(n)]
    diag = numpy.diag(hess)

    hess = hess + hess.T
    hess[indiag] = diag[:]


    return hess



def plot_tangents(tangents,zlim):
    ''' Print the envelope.'''

    zlim = numpy.asarray(zlim)

    one = numpy.ones((2))
    t = numpy.row_stack((one,zlim))

    s = tangents.shape

    xpts = - numpy.tensordot(tangents[:,:,[0,2]],t,([2],[0]))

    alpha = tangents[:,:,1].repeat(2)
    alpha = numpy.resize(alpha,(s[0],s[1],2))
    xpts = xpts/alpha

    size = s[0]*s[1]

    xpts = numpy.resize(xpts,(size,2))
    zpts = numpy.tile(zlim,(size,1))

    pylab.plot(xpts.T,zpts.T,'r:')


def plot_ellipse(a,b,x0,y0,theta,option=None):


    if abs(a)<abs(b):
        tmp = a
        a = b
        b = tmp
        theta = theta - numpy.sign(theta)*numpy.pi/2

    theta0 = 5*numpy.pi/12;

    theta_1 = 0;
    theta_2 = 2*numpy.pi;

    epsilon = numpy.sqrt(1-b**2/a**2)

    if option=='left':
        r0 = a*(1-epsilon**2)/(1 + epsilon*numpy.cos(theta0))
        theta_1 = numpy.pi - numpy.arctan(r0*numpy.sin(theta0)/(r0*numpy.cos(theta0)+2*epsilon*a)) - theta
        theta_2 = numpy.pi + numpy.arctan(r0*numpy.sin(theta0)/(r0*numpy.cos(theta0)+2*epsilon*a)) - theta

    if option=='right':
        theta_1 = - theta0 - theta
        theta_2 = theta0 - theta

    focal_x = x0 + epsilon*a*numpy.cos(theta);
    focal_y = y0 + epsilon*a*numpy.sin(theta);

    phi = numpy.linspace(theta_1,theta_2,num=50)

    r = a*(1-epsilon**2)/(1+epsilon*numpy.cos(phi))

    X = focal_x + r*numpy.cos(phi+theta)
    Y = focal_y + r*numpy.sin(phi+theta)

    pylab.xlabel('X')
    pylab.ylabel('Z')
    pylab.plot(X,Y,'b-')


def test_derivatives():

    nx = 1000
    ntilt = 60
    number_of_sections = 2

    theta = numpy.linspace(-numpy.pi/3.0,numpy.pi/3.0,num=ntilt)

    tgts = numpy.zeros((ntilt,number_of_sections,3))

    for isect in range(number_of_sections):
        tgts[:,isect,0] = nx/2.0*(1-numpy.cos(theta))
        tgts[:,isect,1] = numpy.cos(theta)
        tgts[:,isect,2] = numpy.sin(theta)

    X = numpy.random.random_sample((6*number_of_sections))
    h = 0.0000001

    print 'Check First Derivatives...'

    der_app = numpy.zeros((6*number_of_sections))
    der = ellipse_der(X,tgts)

    for i in range(X.shape[0]):
        Y = X.copy()
        Y[i] += h
        der_app[i] = (ellipse_function(Y,tgts)-ellipse_function(X,tgts))/h
        print 'i=%-6i  app. der=% 10.5e  der=% 10.5e    rel. diff.=% 10.5e' %(i,der_app[i],der[i],numpy.abs((der_app[i]-der[i])/der[i]))

    print 'Check Hessians...'

    hess = ellipse_hess(X,tgts)

    for i in range(X.shape[0]):
        for j in range(i,X.shape[0]):
            Y = X.copy()
            Y[j] += h
            hess_app = (ellipse_der(Y,tgts)-ellipse_der(X,tgts))/h
            diff = numpy.where(hess_app[i]==hess[i,j],0.0,numpy.abs((hess_app[i]-hess[i,j])/hess[i,j]))
            print 'i=%-4i  j=%-4i  app. hess=% 10.5e  hess=% 10.5e    rel. diff.=% 10.5e' %(i,j,hess_app[i],hess[i,j],diff)


if __name__ == '__main__':

    test_derivatives()

