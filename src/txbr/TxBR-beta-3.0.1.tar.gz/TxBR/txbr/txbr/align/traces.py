import logging,logging.config
import scipy,numpy,numpy.linalg
import util

log = logging.getLogger()

def trace_angle(tracks,mask,axis):
    '''This routine evaluates trace angles.
    Variable tracks is a numpy array (of shape (numtlts,numtracks,2)) that
    contain track informations of point like markers in a micrograph series.
    Variable mask (a numpy array of shape (numtlts,numtracks)) allows to
    eventually remove points during the calculation.'''

    (numtlts,numtracks) = tracks.shape[:2];

    ref_angle = numpy.arctan2(axis[1],axis[0]) - numpy.pi/2.0

    a,b = numpy.zeros(numtracks),numpy.zeros(numtracks)

    for itrack in range(numtracks):

        imask = numpy.argwhere(mask[:,itrack]==1)

        x = numpy.squeeze(tracks[imask,itrack,0])
        y = numpy.squeeze(tracks[imask,itrack,1])

        a[itrack],b[itrack] = scipy.polyfit(x,y,1)

    log.debug('a = %s ...' %str(a)[:70])
    log.debug('b = %s ...' %str(b)[:70])

    slope = numpy.row_stack((numpy.arctan(a),numpy.arctan(1/a)))

    theta = slope.mean(axis=1)
    std = slope.var(axis=1)

    log.debug('theta = %s    std = %s' %(theta,std))

    if std[0]<=std[1]:
        angle = theta[0] - ref_angle
    else:
        angle = - theta[1] - ref_angle
        angle = - numpy.pi/2 + angle%numpy.pi

    if numtracks==0: angle = 0

    angle = - numpy.pi/2.0 + (numpy.pi/2.0+angle)%numpy.pi   # Set the trace angle in [-90,90]

    log.debug('ref_angle = %f    angle = %f' %(ref_angle,angle))

    return (ref_angle,angle)


def relative_rot_transform(tracks,mask,index_ref=0):
    '''This routine evaluates the best orthogonal transformation between
    sets of tracks.
    Variable tracks is a numpy array. Number of rows in variable tracks
    represent the number of considered sets.
    Variable mask allows to remove points in the calculation.
    Variable index_ref is the index of the reference set from which transformations
    are evaluated.'''

    (nseries,numtracks) = tracks.shape[:2]

    trf,theta = [],[]

    x_ref = tracks[index_ref,:]

    for index in range(nseries):
        imask = numpy.argwhere(mask[index,:]==1)
        x_ref_ = numpy.squeeze(x_ref[imask])
        x_ = numpy.squeeze(tracks[index,imask])
        ortreg = util.orthogonal_regression_2d(x_ref_,x_)
        trf.append(ortreg[0])
        theta.append(ortreg[1])

    return (trf,theta)

