"""setup-- TxBR Setup package.

The TxBR setup package allows to calulate the pitch of tomographic reconstruction
"""

from txbound import *
