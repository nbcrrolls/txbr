#include <Python.h>

#include "txbrutil.h"
#include "filter_1D.h"

static PyObject *filter(PyObject *self, PyObject *args) {

	char *filepath_in, *filepath_out, *work_directory;
	float angle;

	if (!PyArg_ParseTuple(args, "ssf", &filepath_in, &filepath_out, &angle)) return NULL;

    filesystem_params_handle filesystem_params = NULL;
    symmetrize_2D_params_handle symmetrize_2D_params = NULL;
    remap_2D_params_handle remap_2D_params = NULL;
    rotate_2D_params_handle rotate_2D_params = NULL;
    filter_1D_params_handle filter_1D_params = NULL;
    edgetaper_2D_params_handle edgetaper_2D_params = NULL;

    filesystem_params = create_filesystem_params_from_data_copy(filepath_in, NULL, filepath_out);

    symmetrize_2D_params = create_symmetrize_2D_params_from_data_copy(1);

    rotate_2D_params = create_rotate_2D_params_from_angle(angle);

    filter_1D_params = create_filter_1D_params_from_strings(
    	"SheppLogan",
        "251",
        NULL,
        NULL);

    edgetaper_2D_params = create_edgetaper_2D_params_from_data_copy(0);


	/* Run the filtering routine */

    projection_series_filter_1D(
        filesystem_params,
        symmetrize_2D_params,
        remap_2D_params,
        rotate_2D_params,
        filter_1D_params,
        edgetaper_2D_params
    );

	return Py_BuildValue( "i", 1 );

}


static PyMethodDef BackprojectionMethods[] = {
	{ "filter", filter, METH_VARARGS, "Filter Images prior to the backprojection." },
	{NULL, NULL, 0, NULL} /* Sentinel */
};


PyMODINIT_FUNC initprefil(void) {

	(void)Py_InitModule("prefil", BackprojectionMethods);

}

int main(int argc, char *argv[]) {

	Py_SetProgramName(argv[0]);	/* Pass argv[0] to the Python interpreter */

	Py_Initialize(); /* Initialize the Python interpreter.	*/

	initprefil();	/* Add a static module */

	return 1;

}
