#include <string.h>

#include "txbrutil.h"

#include "filter_1D.h"

int main(int argc, char *argv[])
{
    char *function_name = "main()";

    char *filepath_in = NULL;
    char *filepath_out = NULL;

    transform_params_type *transform_params = NULL;
    filter_1D_params_type *filter_1D_params = NULL;

    for (int i = 1; i < argc; i++) 
    { // NOTE: The following should be rewritten with strcmp() to process flags longer than a single character.
        if (argv[i][0] == '-')
        {
            if (strlen(argv[i]) != 2)
            {
                Abort("ERROR: %s -- Bad command line flag.\n", function_name);
                exit(0);
            }

            switch (argv[i][1]) 
            { 
                case 'a' : 

                    // WARNING: Potentially unsafe!  Need to write proper tests.
                    transform_params = create_transform_params_from_angle(atof(argv[++i]));

                    break;

                case 'f' : 

                    // WARNING: Potentially unsafe!  Need to write proper tests.
                    if (i <= argc - 5)
                    {
                        filter_1D_params = create_filter_1D_params_from_strings(
                            argv[i + 1],
                            argv[i + 2],
                            argv[i + 3],
                            argv[i + 4]);
                    }
                    else if (i <= argc - 3)
                    {
                        filter_1D_params = create_filter_1D_params_from_strings(
                            argv[i + 1],
                            argv[i + 2],
                            NULL,
                            NULL);
                    }
                    else
                    {
                        Abort("ERROR: %s -- Bad number of command line arguments to \"-f\" flag.\n", function_name);
                        exit(0);
                    }

                    i += 2; // filter type, filter length 
                    if (filter_1D_params->type == CUSTOMRWEIGHTED)
                        i += 2; // cut-off, roll-off

                    break;

                case 'i' : 

                    filepath_in = argv[++i];
                    break;

                case 'o' : 

                    filepath_out = argv[++i];
                    break;

                default :

                    Abort("ERROR: %s -- Bad command line argument: \"%s\".\n", function_name, argv[i]);
                    exit(0);
            }
        }
        else
        {
            Abort("ERROR: %s -- Bad command line argument: \"%s\".\n", function_name, argv[i]);
            exit(0);
        }
    }

    projection_series_filter_1D(filepath_in, filepath_out, transform_params, filter_1D_params);
}
