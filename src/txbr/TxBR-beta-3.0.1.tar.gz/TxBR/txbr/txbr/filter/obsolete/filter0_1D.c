#include <stdarg.h>
#include <string.h>
#include <time.h>
#include <math.h>
#include <complex.h>

// BEGIN: FFTW includes

#include <fftw3.h>

#define USE_FFTW 0 // WARNING: Not fully implemented!

typedef fftwf_complex fftw_complex_type; // WARNING: float vs. double

//typedef float complex complex_type; // WARNING: float vs. double
typedef double complex complex_type; // WARNING: float vs. double

// END: FFTW includes

// BEGIN: OpenCV includes

#define CV_NO_BACKWARD_COMPATIBILITY
#include "cv.h"

//#define CVMAT_TYPE_REAL CV_32FC1 // WARNING: float vs. double
//#define CVMAT_TYPE_COMPLEX CV_32FC2 // WARNING: float vs. double
//#define IPL_DEPTH_REAL IPL_DEPTH_32F // WARNING: float vs. double

#define CVMAT_TYPE_REAL CV_64FC1 // WARNING: float vs. double
#define CVMAT_TYPE_COMPLEX CV_64FC2 // WARNING: float vs. double
#define IPL_DEPTH_REAL IPL_DEPTH_64F // WARNING: float vs. double

// END: OpenCV includes

// BEGIN: MEX includes

#ifdef MEX
#include "mex.h"
#endif

// END: MEX includes

#include "mrcslice.h"

#include "txbrutil.h"

#include "filter_1D.h"

#define EPSILON 1e-5

#define PROTOTYPE_COMPLIANT_INDEXING 0
#define PROTOTYPE_COMPLIANT_TRANSFORM 1

////////////////////////////////////////////////////////////////////////////////
// BEGIN: Output utilities.
////////////////////////////////////////////////////////////////////////////////

int Print(char* format, ...)
{
  va_list vargs;
  int retval; 

  va_start(vargs, format);
  retval = vprintf(format, vargs); 
  va_end(vargs);

#ifdef MEX
  const int mexPrintf_buffer_max_length = 1024;
  char mexPrintf_buffer[mexPrintf_buffer_max_length];

  va_start(vargs, format);
  retval = vsnprintf(mexPrintf_buffer, mexPrintf_buffer_max_length, format, vargs); 
  va_end(vargs);

  mexPrintf(mexPrintf_buffer);
#endif

  return retval; 
}

void Abort(char* format, ...)
{
  va_list vargs;
  int retval; 

  va_start(vargs, format);
  retval = vprintf(format, vargs); 
  va_end(vargs);

#ifndef MEX
  //memset((void *) 1, 13, 666); // Seg. fault (useful when debugging).
  exit(0);
#else
  const int mexErrMsgTxt_buffer_max_length = 1024;
  char mexErrMsgTxt_buffer[mexErrMsgTxt_buffer_max_length];

  va_start(vargs, format);
  retval = vsnprintf(mexErrMsgTxt_buffer, mexErrMsgTxt_buffer_max_length, format, vargs); 
  va_end(vargs);

  mexErrMsgTxt(mexErrMsgTxt_buffer);
#endif
}

////////////////////////////////////////////////////////////////////////////////
// END: Output utilities.
////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////
// BEGIN: Matrix/Matrix-like data structure access macros.
////////////////////////////////////////////////////////////////////////////////

#define PUTVAL2D(array2D, n_x_, x_, y_, v_) \
    (array2D)[(x_) + ((y_) * (n_x_))] = (v_)

/*
void ADDVAL2D(real_type array2D[], int n_x_, int x_, int y_, real_type v_)
{
    (array2D)[(x_) + ((y_) * (n_x_))] += v_;
}
*/

#define ADDVAL2D(array2D, n_x_, x_, y_, v_) \
    (((array2D)[(x_) + ((y_) * (n_x_))]) += (v_))

/*
real_type INDEX2D(real_type array2D[], int n_x_, int x_, int y_)
{
    return (array2D)[(x_) + ((y_) * (n_x_))];
}
*/

#define INDEX2D(array2D, n_x_, x_, y_) \
    ((array2D)[(x_) + ((y_) * (n_x_))])

// No interpolation.
#define INTERPOLATE_1(array2D, n_x_, x_, y_, x_alpha_, y_alpha_) \
    (INDEX2D((array2D), (n_x_), (x_), (y_)))

// Interpolation with origin in lower left-hand corner.
#define INTERPOLATE_2(array2D, n_x_, x_, y_, x_alpha_, y_alpha_) \
    (INDEX2D((array2D), (n_x_), (x_), (y_)) * (1.0 - (x_alpha_)) * (1.0 - (y_alpha_)) + \
    INDEX2D((array2D), (n_x_), (x_) + 1, (y_)) * (x_alpha_) * (1.0 - (y_alpha_)) + \
    INDEX2D((array2D), (n_x_), (x_), (y_) + 1) * (1.0 - (x_alpha_)) * (y_alpha_) + \
    INDEX2D((array2D), (n_x_), (x_) + 1, (y_) + 1) * (x_alpha_) * (y_alpha_))

// Interpolation with origin in upper right-hand corner.
#define INTERPOLATE_3(array2D, n_x_, n_y_, x_, y_, x_alpha_, y_alpha_) \
    (INDEX2D((array2D), (n_x_), (n_x_) - 1 - (x_), (n_y_) - 1 - (y_)) * (1.0 - (x_alpha_)) * (1.0 - (y_alpha_)) + \
    INDEX2D((array2D), (n_x_), (n_x_) - (x_), (n_y_) - 1 - (y_)) * (x_alpha_) * (1.0 - (y_alpha_)) + \
    INDEX2D((array2D), (n_x_), (n_x_) - (x_) - 1, (n_y_) - (y_)) * (1.0 - (x_alpha_)) * (y_alpha_) + \
    INDEX2D((array2D), (n_x_), (n_x_) - (x_), (n_y_) - (y_)) * (x_alpha_) * (y_alpha_))

////////////////////////////////////////////////////////////////////////////////
// END: Matrix/Matrix-like data structure access macros.
////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////
// BEGIN: IMOD utilities.
////////////////////////////////////////////////////////////////////////////////

void calc_mmm_of_MRC(MrcHeader *header)
{
    static const char *function_name = "calc_mmm_of_MRC()";

    real_type min = 0.0, max = 0.0, mean = 0.0, m2 = 0.0;

    int n_z = header->nz;
    int length = header->nx * header->ny;

    for (int i_z = 0; i_z < n_z; ++i_z) 
    {
        Islice *slice = NULL;
        slice = sliceReadMRC(header, i_z, 'z');
        if (slice == NULL)
            Abort("ERROR: %s -- Cannot read file.\n", function_name);

        if (slice->mode != SLICE_MODE_FLOAT)
            sliceNewMode(slice, SLICE_MODE_FLOAT);

        float *array = slice->data.f;

        for (int i = 0; i < length; ++i)
        {
            min = TXBR_MIN(min, array[i]);
            max = TXBR_MAX(max, array[i]);
            mean += array[i];
            m2 += array[i] * array[i];
        }

        sliceFree(slice);
    }
    
    int n_pixels = header->nx * header->ny * header->nz;

    mean = mean / (real_type) n_pixels;
    m2 = (m2 / (real_type) n_pixels) - (mean * mean);

//    header->amin = mean - (4.0 * sqrt(m2));
//    header->amax = mean + (4.0 * sqrt(m2));
    header->amin = min;
    header->amax = max;
    header->amean = mean;

    mrc_head_write(header->fp, header);

    Print("header->amin = %f, header->amax = %f, header->amean = %f, m2 = %f\n", header->amin, header->amax, header->amean, m2);
}

void sliceWriteMRC(struct MRCheader *header, Islice *slice, int index, char axis)
{
    static const char *function_name = "sliceWriteMRC()";

    if (header->mode != slice->mode)
    {
        sliceNewMode(slice, header->mode);
    }

    void *data = NULL;
    switch (slice->mode)
    {
        case (SLICE_MODE_FLOAT):

            data = (void *) slice->data.f;
            break;

        case (SLICE_MODE_BYTE):

            data = (void *) slice->data.b;
            break;

        case (SLICE_MODE_SHORT):

            data = (void *) slice->data.s;
            break;

        case (SLICE_MODE_USHORT):

            data = (void *) slice->data.us;
            break;

        default:

            Abort("ERROR: %s - Unrecognized MRC data mode: %i.\n", function_name, slice->mode);
    }

    Print("slice->xsize = %i\n", slice->xsize);
    Print("slice->ysize = %i\n", slice->ysize);
    Print("slice->mode = %i\n", slice->mode);

    Print("header->nx = %i\n", header->nx);
    Print("header->ny = %i\n", header->nx);
    Print("header->nz = %i\n", header->nz);
    Print("header->mode = %i\n", header->mode);

    if (mrc_write_slice(data, header->fp, header, index, axis) != 0)
        Abort("ERROR: %s -- Cannot write file.\n", function_name);
}

Islice *sliceCreateSet(int x_size, int y_size, int mode, float val)
{
    static const char *function_name = "sliceCreateSet";

    Islice *slice = sliceCreate(x_size, y_size, mode);
    if (slice == NULL)
        Abort("ERROR: %s -- Cannot acquire memory for Islice *slice.\n", function_name);
    Ival buffer;
    memset(&buffer, 0, sizeof(Ival));
    memcpy(&buffer, &val, sizeof(real_type));
    sliceClear(slice, buffer);
    return slice;
}

Islice *sliceCreateZeros(int x_size, int y_size, int mode)
{
    return sliceCreateSet(x_size, y_size, mode, 0.0);
}

Islice *sliceNewMode_copy(Islice *slice, int mode)
{
    static const char *function_name = "sliceNewMode_copy()";

    Islice *slice_copy = sliceCreate(slice->xsize, slice->ysize, slice->mode);
    if (slice_copy == NULL)
        Abort("ERROR: %s -- Cannot acquire memory for Islice *slice_copy.\n", function_name);
    memcpy(slice_copy->data.b, slice->data.b, slice->xsize * slice->ysize * slice->dsize * slice->csize);
    sliceNewMode(slice_copy, mode);

    // WARNING: slice_copy->dsize does not seem to be correct!

/*
    Islice *slice_copy = sliceCreate(slice->xsize, slice->ysize, mode);
    if (slice_copy == NULL)
        Abort("ERROR: %s -- Cannot acquire memory for Islice *slice_copy.\n", function_name);
    Ival val;
    for (int i = 0; i < slice_copy->xsize; ++i)
        for (int j = 0; j < slice_copy->ysize; ++j)
        {
            sliceGetVal(slice, i, j, val);
            slicePutVal(slice_copy, i, j, val);
        }
*/

    return slice_copy;
}

void createNewMRCFile
(
    const char *filepath,
    int n_x, int n_y, int n_z,
    int mode
)
{
    static const char *function_name = "createNewMRCFile()";

    Print("Creating new MRC file: \"%s\".\n", filepath);

    FILE* file;

    if ((file = fopen(filepath, "wb")) == NULL)
        Abort("ERROR: %s -- Cannot open file: \"%s\".\n", function_name, filepath);

    struct MRCheader header;
    mrc_head_new(&header, n_x, n_y, n_z, mode);
    mrc_head_write(file, &header);

    if(fclose(file))
        Abort("ERROR: %s -- Cannot close file: \"%s\".\n", function_name, filepath);
}

/*
 * Open an existing MRC file and file header.
 */
void openMRCFile_general
(
    const char *filepath,
    MrcHeader *header,
    FILE **file
)
{
    static const char *function_name = "openMRCFile_general()";

    Print("openMRCFile_general(\"%s\")\n", filepath);

    if ((*file = fopen(filepath, "r+b")) == NULL)
        Abort("ERROR: %s -- Cannot open file \"%s\".\n", function_name, filepath);

    mrc_head_read(*file, header);
}

void write_MRC_image_from_Islice(Islice *slice, const char *filepath)
{
    //static const char *function_name = "write_MRC_image_from_Islice()";

    // BEGIN: Create and open output MRC file.
    // BEGIN: Create output MRC file.
    MrcHeader file_header;

    FILE *file = NULL;

    createNewMRCFile(filepath, slice->xsize, slice->ysize, 1, SLICE_MODE_FLOAT);
    // END: Create output MRC file.

    // BEGIN: Open output MRC file.
    openMRCFile_general(filepath, &file_header, &file);
    sliceWriteMRC(&file_header, slice, 0, 'z');
    calc_mmm_of_MRC(&file_header);
    // END: Open output MRC file.
    // END: Create and open output MRC file.

    fclose(file);
//    exit(0);
}

////////////////////////////////////////////////////////////////////////////////
// END: IMOD utilities.
////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////
// BEGIN: OpenCV utilities.
////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////
// BEGIN: OpenCV utilities: IplImage.
////////////////////////////////////////////////////////////////////////////////

void check_IplImage_widthStep_align(IplImage *image, int n_bytes_row)
{
    static const char *function_name = "check_IplImage_widthStep_align()";

    if (image->widthStep != n_bytes_row)
        Abort("ERROR: %s -- Expected image->widthStep = %i, but image->widthStep = %i.\n",
            function_name, n_bytes_row, image->widthStep);

    /* 
     * We assume data is not aligned.  Hopefully the number of the beast will
     * cause OpenCV's head to spin off if the align value is ever used.  I
     * found the following at both
     * 
     * http://opencv.willowgarage.com/wiki/CxCore
     *
     * and
     *
     * http://www.cognotics.com/opencv/docs/1.0/ref/opencvref_cxcore.htm
     *
     * :
     * 
     * =====
     * int  align;         /\* Alignment of image rows (4 or 8).
     *                         OpenCV ignores it and uses widthStep instead *\/
     *
     * "align is ignored by OpenCV, while widthStep is used to access to subsequent image rows."
     * =====
     *
     * , but the 2008 O'Reilly book neither confirms nor denies this.
     */

    image->align = 666;
}

IplImage *create_IplImage_32F_from_float_data(int n_x, int n_y, float *data)
{
    //static const char *function_name = "create_IplImage_32F_from_float_data()";

    IplImage *image = cvCreateImageHeader(cvSize(n_x, n_y), IPL_DEPTH_32F, 1);
    image->origin = IPL_ORIGIN_BL;

    int n_bytes_row = n_x * sizeof(float);
    cvSetData(image, data, n_bytes_row);
    
    check_IplImage_widthStep_align(image, n_bytes_row);

    return image;
}

IplImage *create_IplImage_64F_from_double_data(int n_x, int n_y, double *data)
{
    //static const char *function_name = "create_IplImage_64F_from_double_data()";

    IplImage *image = cvCreateImageHeader(cvSize(n_x, n_y), IPL_DEPTH_64F, 1);
    image->origin = IPL_ORIGIN_BL;

    int n_bytes_row = n_x * sizeof(double);
    cvSetData(image, data, n_bytes_row);
    
    check_IplImage_widthStep_align(image, n_bytes_row);

    return image;
}

void free_imageData_cvReleaseImageHeader(IplImage *image)
{
   if (image != NULL)
   {
      free(image->imageData);
      cvReleaseImageHeader(&image);
   }
}

IplImage *create_IplImage_from_float_data_copy(int n_x, int n_y, float *data, int ipl_depth)
{
    static const char *function_name = "create_IplImage_from_float_data_copy()";

    IplImage *image = NULL;

    switch (ipl_depth)
    {
        case IPL_DEPTH_32F:
        {
            int n_bytes = n_x * n_y * sizeof(float);
            float *data_copy = (float *) malloc(n_bytes); 
            if (data_copy == NULL)
                Abort("ERROR: %s -- Cannot acquire memory for float *data_copy.\n", function_name);

            memcpy(data_copy, data, n_bytes);

            image = create_IplImage_32F_from_float_data(n_x, n_y, data_copy);

            break;
        }
        case IPL_DEPTH_64F:
        {
            int n_elems = n_x * n_y;
            int n_bytes = n_elems * sizeof(double);
            double *data_copy = (double *) malloc(n_bytes); 
            if (data_copy == NULL)
                Abort("ERROR: %s -- Cannot acquire memory for double *data_copy.\n", function_name);

            for (int i = 0; i < n_elems; ++i)
                data_copy[i] = (double) data[i];

            image = create_IplImage_64F_from_double_data(n_x, n_y, data_copy);

            break;
        }

        default:
            Abort("ERROR: %s -- Unrecognized IPL depth, ipl_depth = %i.\n", function_name, ipl_depth);
    }

    return image;
}

IplImage *create_IplImage_from_Islice_copy(Islice *slice, int ipl_depth)
{
//    static const char *function_name = "create_IplImage_from_Islice_copy()";

    Islice *slice_float = NULL;

    if (slice->mode != SLICE_MODE_FLOAT)
        slice_float = sliceNewMode_copy(slice, SLICE_MODE_FLOAT);
    else
        slice_float = slice;

    IplImage *image = create_IplImage_from_float_data_copy(slice_float->xsize, slice_float->ysize, slice_float->data.f, ipl_depth);

    if (slice->mode != SLICE_MODE_FLOAT)
        sliceFree(slice_float);

    return image;
}

IplImage *create_IplImage_from_sliceReadMRC(MrcHeader *file_header, int i_tilt, char axis, int ipl_depth)
{
    static const char *function_name = "create_IplImage_from_sliceReadMRC()";

    Islice *slice = NULL;
    slice = sliceReadMRC(file_header, i_tilt, axis);
    if (slice == NULL)
        Abort("ERROR: %s -- Cannot read MRC file.\n", function_name);

    IplImage *image = create_IplImage_from_Islice_copy(slice, ipl_depth);

    sliceFree(slice);

    return image;
}

IplImage *create_IplImage_SetZero(int n_x, int n_y, int ipl_depth)
{
    IplImage *image = cvCreateImage(cvSize(n_x, n_y), ipl_depth, 1);
    image->origin = IPL_ORIGIN_BL;
    cvSetZero(image);
    return image;
}

// WARNING: IPL_DEPTH_32F and IPL_DEPTH_64F only!
// WARNING: SLICE_MODE_FLOAT only!
// If image extent < slice extent, excess slice (i.e., right and/or top) is filled with zeros.
// If image extent > slice extent, slice is a crop (i.e., right and/or top) of image.
void copy_IplImage_to_Islice(IplImage *image, Islice *slice)
{
    static const char *function_name = "copy_IplImage_to_Islice()";

    if (slice->mode != SLICE_MODE_FLOAT)
        Abort("ERROR: %s -- Expected slice->mode = %i (SLICE_MODE_FLOAT), but slice->mode = %i.\n",
            function_name, SLICE_MODE_FLOAT, slice->mode);

    int height = TXBR_MIN(image->height, slice->ysize);
    int width = TXBR_MIN(image->width, slice->xsize);

    // WARNING: slice_copy->dsize does not seem to be correct!
    //int step_slice = slice->xsize * slice->dsize * slice->csize;
    int step_slice = slice->xsize * sizeof(float);

    switch (image->depth)
    {
        case IPL_DEPTH_32F:

            for (int i_row = 0; i_row < height; ++i_row)
            {
                float *p_image = (float *) (image->imageData + i_row * image->widthStep);
                float *p_slice = (float *) (slice->data.b + i_row * step_slice);
                for (int i_col = 0; i_col < width; ++i_col)
                {
                    *p_slice++ = *p_image++;
                }
            }

            // WARNING: The code below will not work with subrectangles.
            //int n_bytes = height * width * sizeof(float);
            //memcpy(p_slice, p_image, n_bytes);

            break;

        case IPL_DEPTH_64F:

            for (int i_row = 0; i_row < height; ++i_row)
            {
                double *p_image = (double *) (image->imageData + i_row * image->widthStep);
                float *p_slice = (float *) (slice->data.b + i_row * step_slice);
                for (int i_col = 0; i_col < width; ++i_col)
                {
                    *p_slice++ = (float) *p_image++;
                }
            }

            break;

        default:

            Abort("ERROR: %s -- Expected image->depth = %i (IPL_DEPTH_32F) or %i (IPL_DEPTH_64F), but image->depth = %i.\n",
                function_name, IPL_DEPTH_32F, IPL_DEPTH_64F, image->depth);
    }
}

// NOTE: Used for returning multiple values.
typedef struct
{
    int center0_x;
    int center0_y;
    int center_x;
    int center_y;
    int i0_x_start;
    int i0_y_start;
    int i0_x_stop;
    int i0_y_stop;
    int n_i0_x;
    int n_i0_y;
    int i_x_start;
    int i_y_start;
}
center_copy_params_type;

center_copy_params_type calc_center_copy_params(int n0_x, int n0_y, int n_x, int n_y)
{
    Print("n0_xy = (%i, %i)\n", n0_x, n0_y);
    Print("n_xy = (%i, %i)\n", n_x, n_y);

    // NOTE: Assume n0_xy = (1, 5) and consider n_xy = (1, 2) and n_xy = (1, 3);
    int n_x_parity = n_x % 2;
    int n_y_parity = n_y % 2;

    center_copy_params_type params;

    params.center0_x = n0_x / 2;
    params.center0_y = n0_y / 2;

    params.center_x = n_x / 2;
    params.center_y = n_y / 2;

    if (n0_x <= n_x)
    {
        params.i0_x_start = 0;
        params.i0_x_stop = n0_x; // NOTE: Iterate to element params.i0_x_stop - 1.

        params.i_x_start = params.center_x - params.center0_x;
    }
    else
    {
        params.i0_x_start = params.center0_x - params.center_x;
        params.i0_x_stop = params.center0_x + params.center_x + n_x_parity; // NOTE: Iterate to element params.i0_x_stop - 1.

        params.i_x_start = 0;
    }

    if (n0_y <= n_y)
    {
        params.i0_y_start = 0;
        params.i0_y_stop = n0_y; // NOTE: Iterate to element i0_y_stop - 1.

        params.i_y_start = params.center_y - params.center0_y;
    }
    else
    {
        params.i0_y_start = params.center0_y - params.center_y;
        params.i0_y_stop = params.center0_y + params.center_y + n_y_parity; // NOTE: Iterate to element i0_y_stop - 1.

        params.i_y_start = 0;
    }

    params.n_i0_x = params.i0_x_stop - params.i0_x_start;
    params.n_i0_y = params.i0_y_stop - params.i0_y_start;

    Print("params.i0_x_start = %i\n", params.i0_x_start);
    Print("params.i0_x_stop = %i\n", params.i0_x_stop);
    Print("params.i_x_start = %i\n", params.i_x_start);
    Print("params.n_i0_x = %i\n", params.n_i0_x);
    Print("params.i0_y_start = %i\n", params.i0_y_start);
    Print("params.i0_y_stop = %i\n", params.i0_y_stop);
    Print("params.i_y_start = %i\n", params.i_y_start);
    Print("params.n_i0_y = %i\n", params.n_i0_y);

    return params;
}

// WARNING: SLICE_MODE_FLOAT only!
// If slice extent < image extent, excess image about center is filled with zeros.
// If slice extent > image extent, image is a crop about center of slice.
void copy_IplImage_to_Islice_center(IplImage *image, Islice *slice)
{
    static const char *function_name = "copy_IplImage_to_Islice_center()";

    if (image->depth != IPL_DEPTH_REAL)
        Abort("ERROR: %s -- Expected image->depth = %i (IPL_DEPTH_REAL), but image->depth = %i.\n",
            function_name, IPL_DEPTH_REAL, image->depth);

    if (slice->mode != SLICE_MODE_FLOAT)
        Abort("ERROR: %s -- Expected slice->mode = %i (SLICE_MODE_FLOAT), but slice->mode = %i.\n",
            function_name, SLICE_MODE_FLOAT, slice->mode);

    cvResetImageROI(image);

    int n0_x = image->width;
    int n0_y = image->height;

    int n_x = slice->xsize;
    int n_y = slice->ysize;

    if ((n0_x < n_x) || (n0_y < n_y))
    {
        float v_clear = 0.0;
        sliceClear(slice, &v_clear);
    }

    center_copy_params_type params = calc_center_copy_params(n0_x, n0_y, n_x, n_y);

    int elem_size_image = sizeof(real_type);
    int x0_start_offset = params.i0_x_start * elem_size_image;

    int elem_size_slice = sizeof(float);
    //int step_slice = slice->xsize * slice->dsize * slice->csize; // WARNING: slice_copy->dsize does not seem to be correct!
    int step_slice = slice->xsize * elem_size_slice;
    int x_start_offset = params.i_x_start * elem_size_slice;

    int i_row = params.i_y_start;
    for (int i0_row = params.i0_y_start; i0_row < params.i0_y_stop; ++i0_row)
    {
        real_type *p_image = (real_type *) (image->imageData + i0_row * image->widthStep + x0_start_offset);
        float *p_slice = (float *) (slice->data.b + i_row * step_slice + x_start_offset);
        for (int i0_col = params.i0_x_start; i0_col < params.i0_x_stop; ++i0_col)
        {
            *p_slice++ = (real_type) *p_image++;
        }
        ++i_row;
    }
}

// If slice extent < image extent, excess image about center is filled with zeros.
// If slice extent > image extent, image is a crop about center of slice.
void copy_Islice_to_IplImage_center(Islice *slice, IplImage *image)
{
    //static const char *function_name = "copy_Islice_to_IplImage_center()";

    cvResetImageROI(image);

    IplImage *image0 = create_IplImage_from_Islice_copy(slice, image->depth);
    int n0_x = image0->width;
    int n0_y = image0->height;

    int n_x = image->width;
    int n_y = image->height;

    if ((n0_x < n_x) || (n0_y < n_y))
        cvSetZero(image);

    center_copy_params_type params = calc_center_copy_params(n0_x, n0_y, n_x, n_y);

    cvSetImageROI(image0, cvRect(params.i0_x_start, params.i0_y_start, params.n_i0_x, params.n_i0_y));
    cvSetImageROI(image, cvRect(params.i_x_start, params.i_y_start, params.n_i0_x, params.n_i0_y)); // NOTE: The extents are the same as image0.
    cvCopy(image0, image, NULL);
    cvResetImageROI(image0);
    cvResetImageROI(image);

    free_imageData_cvReleaseImageHeader(image0);
}

// If slice extent < image extent, excess image (i.e., right and/or top) is filled with zeros.
// If slice extent > image extent, image is a crop (i.e., right and/or top) of slice.
void copy_Islice_to_IplImage(Islice *slice, IplImage *image)
{
    IplImage *image0 = create_IplImage_from_Islice_copy(slice, image->depth);

    cvResetImageROI(image);
    cvSetZero(image);

    int height = TXBR_MIN(image0->height, image->height);
    int width = TXBR_MIN(image0->width, image->width);
    cvSetImageROI(image0, cvRect(0, 0, width, height));
    cvSetImageROI(image, cvRect(0, 0, width, height));
    cvCopy(image0, image, NULL);
    cvResetImageROI(image0);
    cvResetImageROI(image);

    free_imageData_cvReleaseImageHeader(image0);
}

void write_MRC_image_from_IplImage(IplImage *image, const char *filepath)
{
    static const char *function_name = "write_MRC_image_from_IplImage()";

    Islice *slice = sliceCreate(image->width, image->height, SLICE_MODE_FLOAT);
    if (slice == NULL)
        Abort("ERROR: %s -- Cannot acquire memory for Islice *slice.\n", function_name);
    copy_IplImage_to_Islice(image, slice);
    write_MRC_image_from_Islice(slice, filepath);
    sliceFree(slice);
}

////////////////////////////////////////////////////////////////////////////////
// END: OpenCV utilities: IplImage.
////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////
// BEGIN: OpenCV utilities: CvMat.
////////////////////////////////////////////////////////////////////////////////

CvMat *create_CvMat_32F_from_float_data(int rows, int cols, float *data)
{
    //static const char *function_name = "create_CvMat_32F_from_double_data()";

    CvMat *matrix = cvCreateMatHeader(rows, cols, CV_32FC1);

    int n_bytes_row = cols * sizeof(float);
    cvSetData(matrix, data, n_bytes_row);
    
    return matrix;
}

CvMat *create_CvMat_64F_from_double_data(int rows, int cols, double *data)
{
    //static const char *function_name = "create_CvMat_64F_from_double_data()";

    CvMat *matrix = cvCreateMatHeader(rows, cols, CV_64FC1);

    int n_bytes_row = cols * sizeof(double);
    cvSetData(matrix, data, n_bytes_row);
    
    return matrix;
}

/*
CvMat *create_CvMat_64F_from_double_data_copy(int rows, int cols, double *data)
{
    static const char *function_name = "create_CvMat_64F_from_double_data_copy()";

    int n_bytes = rows * cols * sizeof(double);
    double *data_copy = (double *) malloc(n_bytes); 
    if (data_copy == NULL)
        Abort("ERROR: %s -- Cannot acquire memory for double *data_copy.\n", function_name);

    memcpy(data_copy, data, n_bytes);

    return create_CvMat_64F_from_double_data(rows, cols, data_copy);
}

CvMat *create_CvMat_from_Islice_copy(Islice *slice, int type)
{
    //static const char *function_name = "create_CvMat_from_Islice_copy()";

    Islice *slice_float = NULL;

    if (slice->mode != SLICE_MODE_FLOAT)
        slice_float = sliceNewMode_copy(slice, SLICE_MODE_FLOAT);
    else
        slice_float = slice;

    CvMat *matrix = create_CvMat_64F_from_float_data_copy(slice->xsize, slice->ysize, slice->data.f, type);

    if (slice->mode != SLICE_MODE_FLOAT)
        sliceFree(slice_float);

    return matrix;
}
*/

int convert_CvMat_type_to_Ipl_depth(int type)
{
    static const char *function_name = "convert_CvMat_type_to_Ipl_depth(int type)";

    int ipl_depth = 0;

    switch (type)
    {
        case CV_32FC1:
            ipl_depth = IPL_DEPTH_32F;
            break;
        case CV_64FC1:
            ipl_depth = IPL_DEPTH_64F;
            break;
        default:
            Abort("ERROR: %s: Unrecognized CvMat type, type = %i.\n", function_name, type);
    }

    return ipl_depth;
}

void copy_CvMat_to_Islice(CvMat *matrix, Islice *slice)
{
    static const char *function_name = "copy_CvMat_to_Islice";

    if (slice->mode != SLICE_MODE_FLOAT)
        Abort("ERROR: %s -- Expected slice->mode = %i (SLICE_MODE_FLOAT), but slice->mode = %i.\n",
            function_name, SLICE_MODE_FLOAT, slice->mode);

    IplImage *image = cvCreateImageHeader(cvSize(matrix->cols, matrix->rows), convert_CvMat_type_to_Ipl_depth(cvGetElemType(matrix)), 1);
    cvGetImage(matrix, image);
    copy_IplImage_to_Islice(image, slice);
    cvReleaseImageHeader(&image);
}

CvMat *create_CvMat_from_Islice_copy(Islice *slice, int type)
{
    //static const char *function_name = "create_CvMat_from_Islice_copy()";

    IplImage *image = create_IplImage_from_Islice_copy(slice, convert_CvMat_type_to_Ipl_depth(type));
    CvMat *matrix = cvCreateMatHeader(image->width, image->height, type);
    cvGetMat(image, matrix, NULL, 0);
    cvReleaseImageHeader(&image);

    return matrix;
}

void free_data_cvReleaseMat(CvMat *matrix)
{
   if (matrix != NULL)
   {
      free(matrix->data.ptr);
      cvReleaseMat(&matrix);
   }
}

//    if ((cvGetElemType(matrix) != CV_32FC1) && (cvGetElemType(matrix) != CV_64FC1))
//        Abort("ERROR: %s -- Expected cvGetElemType(matrix) = (%i, %i) (CV_32FC1, CV_64FC1), but cvGetElemType(matrix) = %i.\n",
//            function_name, CV_32FC1, CV_64FC1, cvGetElemType(matrix));

void print_CvMat_packed_complex(const char *name, const CvMat *matrix)
{
    static const char *function_name = "print_CvMat_packed_complex()";

    if (cvGetElemType(matrix) != CVMAT_TYPE_REAL)
        Abort("ERROR: %s -- Expected cvGetElemType(matrix) = %i (CVMAT_TYPE_REAL), but cvGetElemType(matrix) = %i.\n",
            function_name, CVMAT_TYPE_REAL, cvGetElemType(matrix));

    Print("%s(%i, %i) = [ ...\n", name, matrix->rows, matrix->cols);
    for (int i_row = 0; i_row < matrix->rows; ++i_row) 
    {
        const real_type *ptr = (const real_type *) (matrix->data.ptr + i_row * matrix->step);
        Print("%.15e + 0.0i%s", *ptr++, (matrix->cols > 1) ? " " : "");
        for (int i_col = 1; i_col < matrix->cols - 2; i_col += 2) 
        {
            Print("%.15e + %.15ei ", *ptr, *(ptr + 1));
            ptr += 2;
        }
        if ((matrix->cols > 1) && (matrix->cols % 2 == 1))
            Print("%.15e + %.15ei", *ptr, *(ptr + 1));
        else
            Print("%.15e + 0.0i", *ptr);
        Print("\n");
    }
    Print("];\n");

/*  // NOTE: Always keep this in mind, you fool!
    for (int i_row = 0; i_row < matrix->rows; ++i_row) 
    {
        for (int i_col = 0; i_col < matrix->cols; ++i_col) 
        {
            Print("%.15e ", CV_MAT_ELEM(*matrix, real_type, i_row, i_col));
        }
        Print("\n");
    }
    exit(0);
*/
}

void print_CvMat(const char *name, const CvMat *matrix)
{
    static const char *function_name = "print_CvMat()";

    if (cvGetElemType(matrix) != CVMAT_TYPE_REAL)
        Abort("ERROR: %s -- Expected cvGetElemType(matrix) = %i (CVMAT_TYPE_REAL), but cvGetElemType(matrix) = %i.\n",
            function_name, CVMAT_TYPE_REAL, cvGetElemType(matrix));

    Print("%s(%i, %i) = [ ...\n", name, matrix->rows, matrix->cols);
    for (int i_row = 0; i_row < matrix->rows; ++i_row) 
    {
        const real_type *ptr = (const real_type *) (matrix->data.ptr + i_row * matrix->step);
        for (int i_col = 0; i_col < matrix->cols - 1; ++i_col) 
            Print("%.15e ", *ptr++);
        Print("%.15e\n", *ptr);
    }
    Print("];\n", name);
}

////////////////////////////////////////////////////////////////////////////////
// END: OpenCV utilities: CvMat.
////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////
// END: OpenCV utilities.
////////////////////////////////////////////////////////////////////////////////

// QUESTION: Why does declaring matrix const cause this warning?
// filter_1D.c:calc_rot_matrix2x2(), line 1 and 8: warning: passing argument 2 of ‘print_matrix2x2’ from incompatible pointer type
void print_matrix2x2(const char *name, real_type matrix[2][2])
{
    Print("%s[0][0-1] = (%.15e, %.15e)\n", name, matrix[0][0], matrix[0][1]);
    Print("%s[1][0-1] = (%.15e, %.15e)\n", name, matrix[1][0], matrix[1][1]);
}

void inv_rot_matrix2x2(real_type rot_matrix[2][2], real_type inv_rot_matrix[2][2])
{
    print_matrix2x2("rot_matrix", rot_matrix);

    inv_rot_matrix[0][0] = rot_matrix[0][0];
    inv_rot_matrix[1][0] = rot_matrix[0][1];
    inv_rot_matrix[0][1] = rot_matrix[1][0];
    inv_rot_matrix[1][1] = rot_matrix[1][1];

    print_matrix2x2("inv_rot_matrix", inv_rot_matrix);
}

void calc_rot_matrix2x2(real_type angle, real_type rot_matrix[2][2])
{
    rot_matrix[0][0] = cos(angle); rot_matrix[0][1] = sin(angle);
    rot_matrix[1][0] = -sin(angle); rot_matrix[1][1] = cos(angle);

    print_matrix2x2("rot_matrix", rot_matrix);
}

transform_params_type *create_transform_params()
{
    static const char *function_name = "create_transform_params()";

    transform_params_type *transform_params = (transform_params_type *) malloc(sizeof(transform_params_type));
    if (transform_params == NULL)
        Abort("ERROR: %s: Cannot acquire memory for transform_params_type *transform_params.\n", function_name);

    // BEGIN: Default values.
    transform_params->angle = 0.0;
    transform_params->angle_valid = 1;

    transform_params->rot_matrix[0][0] = 1.0; transform_params->rot_matrix[0][1] = 0.0;
    transform_params->rot_matrix[1][0] = 0.0; transform_params->rot_matrix[1][1] = 1.0;
    transform_params->rot_matrix_valid = 1;

    transform_params->inv_rot_matrix[0][0] = 1.0; transform_params->inv_rot_matrix[0][1] = 0.0;
    transform_params->inv_rot_matrix[1][0] = 0.0; transform_params->inv_rot_matrix[1][1] = 1.0;
    transform_params->inv_rot_matrix_valid = 1;
    // END: Default values.

    return transform_params;
}

transform_params_type *create_transform_params_from_rot_matrix2x2(real_type rot_matrix[2][2])
{
    //static const char *function_name = "create_transform_params_from_rot_matrix2x2()";

    transform_params_type *transform_params = create_transform_params();

    memcpy(transform_params->rot_matrix, rot_matrix, sizeof(real_type) * 4); 
/*
    transform_params->rot_matrix[0][0] = rot_matrix[0][0]; transform_params->rot_matrix[0][1] = rot_matrix[0][1];
    transform_params->rot_matrix[1][0] = rot_matrix[1][0]; transform_params->rot_matrix[1][1] = rot_matrix[1][1];
*/
    transform_params->rot_matrix_valid = 1;

    inv_rot_matrix2x2(transform_params->rot_matrix, transform_params->inv_rot_matrix);
    transform_params->inv_rot_matrix_valid = 1;

    // Recovery of eqv. angle.
    real_type cos_val = transform_params->rot_matrix[0][0];
    real_type sin_val = transform_params->rot_matrix[0][1];
    real_type angle = 0.0;

    real_type angle_atan2 = atan2(sin_val, cos_val);
    if (angle_atan2 < 0.0)
        angle_atan2 = (2 * M_PI) + angle_atan2;

    //Abort("angle = %f, atan2 = %f\n", angle, angle_atan2);

    angle = angle_atan2;

    transform_params->angle_valid = 1;

    return transform_params;
}

transform_params_type *create_transform_params_from_angle(real_type angle)
{
    //static const char *function_name = "create_transform_params_from_angle()";

    transform_params_type *transform_params = create_transform_params();

    // Assume degrees; convert to radians.
    angle *= (M_PI / 180.0);
    transform_params->angle = angle;
    transform_params->angle_valid = 1;

    calc_rot_matrix2x2(angle, transform_params->rot_matrix);
    transform_params->rot_matrix_valid = 1;

    calc_rot_matrix2x2(-angle, transform_params->inv_rot_matrix);
    transform_params->inv_rot_matrix_valid = 1;

    return transform_params;
}

////////////////////////////////////////////////////////////////////////////////
// BEGIN: Filtering.
////////////////////////////////////////////////////////////////////////////////

// BEGIN: Shepp-Logan filter.

pixel_type *create_shepp_logan_filter_1D_rs(int length)
{
    static const char *function_name = "create_shepp_logan_filter_1D_rs()";

    if (length % 2 != 1)
        Abort("ERROR: %s -- length \% 2 != 1\n", function_name);

    pixel_type *filter_1D = (pixel_type *) malloc(length * sizeof(pixel_type)); 
    if (filter_1D == NULL)
        Abort("ERROR: %s -- Memory request failed.\n", function_name);

    real_type n = -((real_type) length - 1.0) / 2.0;

    for (int i = 0; i < length; ++i)
    {
        //Print("n = %.15e\n", n);
        //Print("n^2 = %.15e\n", n * n);
        filter_1D[i] = -2.0 / (M_PI * ((4.0 * (n * n)) - 1.0));
//filter_1D[i] = 1.0; // DEBUG.
//filter_1D[i] = (i != ((length - 1) / 2)) ? 0.0 : 1.0; // DEBUG.
        //Print("filter_1D[%i] = %.15e\n", i, filter_1D[i]);
         n = n + 1.0;
    }

    //for (int i = 0; i < length; ++i)
    //    Print("%.15e\n", filter_1D[i]);

    return filter_1D;
}

void create_shepp_logan_filter_1D_rsfs_cv
(
    int length_rs,
    pixel_type **filter_rs, // This is computed first.
    int length_fs, // length_rs + padding
    CvMat **filter_fs
)
{
    static const char *function_name = "create_shepp_logan_filter_1D_rsfs_cv()";

    Print("length_rs = %i\n", length_rs);
    Print("length_fs = %i\n", length_fs);

    if (length_rs % 2 != 1)
        Abort("ERROR: %s -- length_rs \% 2 != 1\n", function_name);

    if (length_fs < length_rs)
        Abort("ERROR: %s -- length_fs < length_rs\n", function_name);

    (*filter_rs) = create_shepp_logan_filter_1D_rs(length_rs);
    (*filter_fs) = cvCreateMat(1, length_fs, CVMAT_TYPE_REAL);
    cvZero(*filter_fs);
    //CvMat *filter_rs_cv = create_CvMat_32F_from_float_data(1, length_rs, (*filter_rs)); // WARNING: float vs. double
    CvMat *filter_rs_cv = create_CvMat_64F_from_double_data(1, length_rs, (*filter_rs)); // WARNING: float vs. double
    CvMat tmp;
    cvGetSubRect((*filter_fs), &tmp, cvRect(0, 0, length_rs, 1));
    cvCopy(filter_rs_cv, &tmp, NULL);
    cvReleaseMat(&filter_rs_cv); // WARNING: Do NOT free filter_rs.

    cvDFT((*filter_fs), (*filter_fs), CV_DXT_FORWARD | CV_DXT_ROWS, 1);

    //print_CvMat_packed_complex("*filter_fs", *filter_fs);
}

// END: Shepp-Logan filter.

// BEGIN: Ram-Lak filter.

pixel_type *create_ram_lak_filter_1D_rs(int length)
{
    static const char *function_name = "create_ram_lak_filter_1D_rs()";

    if (length % 2 != 1)
        Abort("ERROR: %s -- length \% 2 != 1\n", function_name);

    pixel_type *filter_1D = (pixel_type *) malloc(length * sizeof(pixel_type)); 
    if (filter_1D == NULL)
        Abort("ERROR: %s -- Cannot acquire memory for pixel_type *data.\n", function_name);

    real_type n = -((real_type) length - 1.0) / 2.0;

    for (int i = 0; i < length; ++i)
    {
        if (n == 0)
            filter_1D[i] = M_PI / 4.0;
        else if (abs(n) % 2 == 1)
            filter_1D[i] = -1 / (M_PI * (n * n));
        else
            filter_1D[i] = 0;
        n = n + 1.0;
    }

    return filter_1D;
}

void create_ram_lak_filter_1D_rsfs_cv
(
    int length_rs,
    pixel_type **filter_rs, // This is computed first.
    int length_fs, // length_rs + padding
    CvMat **filter_fs
)
{
    static const char *function_name = "create_ram_lak_filter_1D_rsfs_cv()";

    Print("length_rs = %i\n", length_rs);
    Print("length_fs = %i\n", length_fs);

    if (length_rs % 2 != 1)
        Abort("ERROR: %s -- length_rs \% 2 != 1\n", function_name);

    if (length_fs < length_rs)
        Abort("ERROR: %s -- length_fs < length_rs\n", function_name);

    (*filter_rs) = create_ram_lak_filter_1D_rs(length_rs);
    (*filter_fs) = cvCreateMat(1, length_fs, CVMAT_TYPE_REAL);
    cvZero(*filter_fs);
    //CvMat *filter_rs_cv = create_CvMat_32F_from_float_data(1, length_rs, (*filter_rs)); // WARNING: float vs. double
    CvMat *filter_rs_cv = create_CvMat_64F_from_double_data(1, length_rs, (*filter_rs)); // WARNING: float vs. double
    CvMat tmp;
    cvGetSubRect((*filter_fs), &tmp, cvRect(0, 0, length_rs, 1));
    cvCopy(filter_rs_cv, &tmp, NULL);
    cvReleaseMat(&filter_rs_cv); // WARNING: Do NOT free filter_rs.

    cvDFT((*filter_fs), (*filter_fs), CV_DXT_FORWARD | CV_DXT_ROWS, 1);

    //print_CvMat_packed_complex("*filter_fs", *filter_fs);
}

// END: Ram-Lak filter.

// BEGIN: Custom R-Weighted filter.

void create_custom_r_weighted_filter_1D_fsrs_fftw
(
    int length_fs, // NOTE: This is the length used when calculating the real dom. filter.
    int length_fs_padded, // NOTE: This is the length used when calculating the freq. dom. filter from the real dom. filter.
    fftw_complex_type **filter_fs, // NOTE: This is computed first using length_fs, wiped out, and then recalculated using length_fs_padded.
    int length_rs,
    pixel_type **filter_rs,
    real_type cut_off,
    real_type roll_off
)
{
    static const char *function_name = "create_custom_r_weighted_filter_1D_fsrs_fftw()";

/*
    length_fs = (2 * 10) + 1;
    length_rs = 5;
    cut_off = 5;
    roll_off = 1;
*/

    Abort("ERROR: %s -- USE_FFTW not implemented.\n", function_name);

    if (length_rs % 2 != 1)
        Abort("ERROR: %s -- length_rs \% 2 != 1\n", function_name);

    if (length_fs % 2 != 1)
        Abort("ERROR: %s -- length_fs \% 2 != 1\n", function_name);

    if (length_fs < length_rs)
        Abort("ERROR: %s -- length_fs < length_rs, (%i < %i)\n", function_name, length_fs, length_rs);

    *filter_fs = (fftw_complex_type *) fftw_malloc(length_fs * sizeof(fftw_complex_type));
    if (*filter_fs == NULL)
        Abort("ERROR: %s -- Cannot acquire memory for filter_fs.\n", function_name);
    
    *filter_rs = (pixel_type *) malloc(length_rs * sizeof(pixel_type));
    if (*filter_rs == NULL)
        Abort("ERROR: %s -- Cannot acquire memory for filter_rs.\n", function_name);

    Print("length_fs = %i\n", length_fs);
    Print("length_rs = %i\n", length_rs);

    int n = (length_fs - 1) / 2;
    cut_off *= (real_type) n;

    Print("n = %i\n", n);
    Print("cut_off = %.15e\n", cut_off);

    fftw_complex_type *X_c = *filter_fs;

    for (int i = 0; i < n + 1; ++i)
        X_c[i] = i;
    for (int i = n + 1; i < length_fs; ++i)
        X_c[i] = 2 * n - i;

//    for (int i = 0; i < length_fs; ++i)
//        Print("%.15e + %.15ei\n", creal(X_c[i]), cimag(X_c[i]));
//    Print("\n");

    for (int i = 0; i < length_fs; ++i)
        if (fabs(creal(X_c[i])) >= cut_off)
            X_c[i] = cut_off * exp(-pow(creal(X_c[i]) - cut_off, 2) / pow(roll_off, 2));

//    for (int i = 0; i < length_fs; ++i)
//        Print("%.15e + %.15ei\n", creal(X_c[i]), cimag(X_c[i]));
//    Print("\n");

    fftwf_plan plan = fftwf_plan_dft_1d(length_fs, X_c, X_c, FFTW_BACKWARD, FFTW_ESTIMATE);
    fftwf_execute(plan);
    fftwf_destroy_plan(plan);

//    for (int i = 0; i < length_fs; ++i)
//        Print("%.15e + %.15ei\n", creal(X_c[i]) / length_fs, cimag(X_c[i]) / length_fs);
//    Print("\n");

    real_type *X_r = (real_type *) malloc(length_fs * sizeof(real_type));
    if (X_r == NULL)
        Abort("ERROR: %s -- Cannot acquire memory for real_type *X_r.\n", function_name);

    // fftshift()
    for (int i = 0; i < n; ++i)
        X_r[i] = creal(X_c[(n + 1) + i]) / length_fs;
    for (int i = n; i < length_fs; ++i)
        X_r[i] = creal(X_c[i - n]) / length_fs;

    // NOTE: We've done the ifft, so the origin (i.e., peak) is at offset n.
    // NOTE: Both length_fs and length_rs are odd.
    //int i_X_r_start = ((length_fs - 1) / 2) - ((length_rs - 1) / 2);
    //int i_X_r_stop = ((length_fs - 1) / 2) + ((length_rs - 1) / 2);
    int i_X_r_start = ((length_fs - length_rs) / 2);
    //int i_X_r_stop = (length_fs + length_rs) / 2;
    for (int i = 0; i < length_rs; ++i)
        (*filter_rs)[i] = X_r[i_X_r_start + i];

    free(X_r);

//    Print("[ ...\n");
//    for (int i = 0; i < length_rs; ++i) Print("%.15e\n", (*filter_rs)[i]);
//    Print("]\n");
    //exit(0);
}

void create_custom_r_weighted_filter_1D_fsrs_cv
(
    int length_fs, // NOTE: This is the length used when calculating the real dom. filter.
    int length_fs_padded, // NOTE: This is the length used when calculating the freq. dom. filter from the real dom. filter.
    CvMat **filter_fs, // NOTE: This is computed first using length_fs, wiped out, and then recalculated using length_fs_padded.
    int length_rs,
    pixel_type **filter_rs,
    real_type cut_off,
    real_type roll_off
)
{
    static const char *function_name = "create_custom_r_weighted_filter_1D_fsrs_cv()";

    Print("length_fs = %i\n", length_fs);
    Print("length_rs = %i\n", length_rs);

    if (length_rs % 2 != 1)
        Abort("ERROR: %s -- length_rs \% 2 != 1\n", function_name);

    if (length_fs % 2 != 1)
        Abort("ERROR: %s -- length_fs \% 2 != 1\n", function_name);

    if (length_fs < length_rs)
        Abort("ERROR: %s -- length_fs < length_rs\n", function_name);

    // BEGIN: Use 2-channel matrix.

    *filter_fs = cvCreateMatHeader(1, length_fs, CVMAT_TYPE_COMPLEX);

    int n_bytes_row = length_fs * sizeof(complex_type);
    complex_type *filter_fs_complex_data = (complex_type *) malloc(n_bytes_row);
    if (filter_fs_complex_data == NULL)
        Abort("ERROR: %s -- Cannot acquire memory for filter_fs_data.\n", function_name);
    
    cvSetData(*filter_fs, filter_fs_complex_data, n_bytes_row);

    *filter_rs = (pixel_type *) malloc(length_rs * sizeof(pixel_type));
    if (*filter_rs == NULL)
        Abort("ERROR: %s -- Cannot acquire memory for filter_rs.\n", function_name);

    int n = (length_fs - 1) / 2;
    real_type cut_off_scaled = cut_off * (real_type) n;

    Print("n = %i\n", n);
    Print("cut_off_scaled = %.15e\n", cut_off_scaled);

    complex_type *X_c = (complex_type *) (*filter_fs)->data.ptr;

    for (int i = 0; i < n + 1; ++i)
        X_c[i] = i;
    for (int i = n + 1; i < length_fs; ++i)
        X_c[i] = 2 * n - i;

//    for (int i = 0; i < length_fs; ++i)
//        Print("%.15e + %.15ei\n", creal(X_c[i]), cimag(X_c[i]));
//    Print("\n");

    for (int i = 0; i < length_fs; ++i)
        if (fabs(creal(X_c[i])) >= cut_off_scaled)
            X_c[i] = cut_off_scaled * exp(-pow(creal(X_c[i]) - cut_off_scaled, 2) / pow(roll_off, 2));

//    for (int i = 0; i < length_fs; ++i)
//        Print("%.15e + %.15ei\n", creal(X_c[i]), cimag(X_c[i]));
//    Print("\n");

    CvMat *filter_rs_cv = cvCloneMat(*filter_fs);
    complex_type *X_c_cv = (complex_type *) filter_rs_cv->data.ptr;

    //for (int i = 0; i < length_fs; ++i)
    //    Print("%.15e + %.15ei\n", creal(X_c_cv[i]), cimag(X_c_cv[i]));
    //Print("\n");

    cvDFT((*filter_fs), filter_rs_cv, CV_DXT_INV_SCALE | CV_DXT_ROWS, filter_rs_cv->rows);

//    for (int i = 0; i < length_fs; ++i)
//        Print("%.15e + %.15ei\n", creal(X_c_cv[i]), cimag(X_c_cv[i]));
//    Print("\n");

    real_type *X_r = (real_type *) malloc(length_fs * sizeof(real_type));
    if (X_r == NULL)
        Abort("ERROR: %s -- Cannot acquire memory for real_type *X_r.\n", function_name);

    // NOTE: This corresponds to MATLAB's fftshift(), not the expected ifftshift().  We have already scaled the data.
    for (int i = 0; i < n; ++i)
        X_r[i] = creal(X_c_cv[(n + 1) + i]);
    for (int i = n; i < length_fs; ++i)
        X_r[i] = creal(X_c_cv[i - n]);

    cvReleaseMat(&filter_rs_cv);

    // NOTE: We've done the ifft, so the origin (i.e., peak) is at offset n.
    // NOTE: Both length_fs and length_rs are odd.
    //int i_X_r_start = ((length_fs - 1) / 2) - ((length_rs - 1) / 2);
    //int i_X_r_stop = ((length_fs - 1) / 2) + ((length_rs - 1) / 2);
    int i_X_r_start = ((length_fs - length_rs) / 2);
    //int i_X_r_stop = (length_fs + length_rs) / 2;
    for (int i = 0; i < length_rs; ++i)
        (*filter_rs)[i] = X_r[i_X_r_start + i];

    free(X_r);

//    Print("filter_rs = [ ...\n");
//    for (int i = 0; i < length_rs; ++i) Print("%.15e\n", (*filter_rs)[i]);
//    Print("]\n");

    // BEGIN: Release 2-channel matrix, create 1-channel matrix, and take transform.
    // NOTE: I'm doing this because it produces a freq. dom. filter that matches the prototype's real dom. filter.

    free_data_cvReleaseMat(*filter_fs);
    *filter_fs = cvCreateMat(1, length_fs_padded, CVMAT_TYPE_REAL);
    cvZero(*filter_fs);

    real_type *filter_fs_real_data = (real_type *) (*filter_fs)->data.ptr;
    for (int i = 0; i < length_rs; ++i)
        filter_fs_real_data[i] = (*filter_rs)[i];

    cvDFT((*filter_fs), (*filter_fs), CV_DXT_FORWARD | CV_DXT_ROWS, (*filter_fs)->rows);

    //print_CvMat_packed_complex("*filter_fs", *filter_fs);

    // END: Release 2-channel matrix, create 1-channel matrix, and take transform.

/*
    // BEGIN: Compare against FFTW version.

    fftw_complex_type *filter_fs_fftw;
    pixel_type *filter_rs_fftw;

    create_custom_r_weighted_filter_1D_fsrs_fftw(
        length_fs,
        &filter_fs_fftw,
        length_rs,
        &filter_rs_fftw,
        cut_off,
        roll_off);

    Print("filter_rs_fftw = [ ...\n");
    for (int i = 0; i < length_rs; ++i) Print("%.15e\n", filter_rs_fftw[i]);
    Print("]\n");

    Print("(*filter_fs) - filter_rs_fftw = [ ...\n");
    for (int i = 0; i < length_rs; ++i) Print("%.15e\n", (*filter_rs)[i] - filter_rs_fftw[i]);
    Print("]\n");

    // END: Compare against FFTW version.
*/

    // END: Use 2-channel matrix.

/*
    // BEGIN: Use IPL's packed format for complex input to cvDFT(CV_DXT_INV)
    // WARNING: Produces filters that differ from prototype's.

    *filter_fs = cvCreateMat(1, length_fs, CVMAT_TYPE_REAL);
    if (*filter_fs == NULL)
        Abort("ERROR: %s -- Cannot acquire memory for filter_fs.\n", function_name);
    cvZero(*filter_fs);
    
    *filter_rs = (pixel_type *) malloc(length_rs * sizeof(pixel_type));
    if (*filter_rs == NULL)
        Abort("ERROR: %s -- Cannot acquire memory for filter_rs.\n", function_name);

    int n = (length_fs - 1) / 2;
    real_type cut_off_scaled = cut_off * ((real_type) n / 2.0);

    Print("n = %i\n", n);
    Print("cut_off_scaled = %.15e\n", cut_off_scaled);

    real_type *X_c = (real_type *) (*filter_fs)->data.ptr;

    X_c[0] = 0;
    for (int i = 1; i < n + 1; i += 2)
        X_c[i] = ceil((real_type) i / 2.0);
    for (int i = n + 1; i < length_fs_packed_complex; i += 2)
        X_c[i] = round((real_type) (2 * n - i) / 2.0);

    Print("%.15e + 0.0i\n", X_c[0]);
    for (int i = 1; i < length_fs_packed_complex; i += 2)
        Print("%.15e + %.15ei\n", X_c[i], X_c[i + 1]);
    Print("\n");

    if (fabs(X_c[0]) >= cut_off_scaled)
        X_c[0] = cut_off_scaled * exp(-pow(X_c[0] - cut_off_scaled, 2) / pow(roll_off, 2));
    for (int i = 1; i < length_fs_packed_complex; i += 2)
        if (fabs(X_c[i]) >= cut_off_scaled)
            X_c[i] = cut_off_scaled * exp(-pow(X_c[i] - cut_off_scaled, 2) / pow(roll_off, 2));

    Print("%.15e + 0.0i\n", X_c[0]);
    for (int i = 1; i < length_fs_packed_complex; i += 2)
        Print("%.15e + %.15ei\n", X_c[i], X_c[i + 1]);
    Print("\n");

    cvDFT((*filter_fs), (*filter_fs), CV_DXT_INV_SCALE | CV_DXT_ROWS, 1);

    for (int i = 0; i < length_fs_packed_complex; i += 2)
        Print("%.15e + %.15ei\n", X_c[i], X_c[i + 1]);
    //Print("%.15e + 0.0i\n", X_c[0]);
    //for (int i = 1; i < length_fs_packed_complex; i += 2)
    //    Print("%.15e + %.15ei\n", X_c[i], X_c[i + 1]);
    Print("\n");
    exit(0);

    real_type *X_r = (real_type *) malloc(length_fs * sizeof(real_type));
    if (X_r == NULL)
        Abort("ERROR: %s -- Cannot acquire memory for real_type *X_r.\n", function_name);

    // fftshift()
    for (int i = 0; i < n; ++i)
        X_r[i] = X_c[2 * ((n + 1) + i) - 1];
    X_r[n] = X_c[0];
    for (int i = n + 1; i < length_fs; ++i)
        X_r[i] = X_c[2 * (i - n) - 1];

    // NOTE: We've done the ifft, so the origin (i.e., peak) is at offset n.
    // NOTE: Both length_fs and length_rs are odd.
    //int i_X_r_start = ((length_fs - 1) / 2) - ((length_rs - 1) / 2);
    //int i_X_r_stop = ((length_fs - 1) / 2) + ((length_rs - 1) / 2);
    int i_X_r_start = ((length_fs - length_rs) / 2);
    //int i_X_r_stop = (length_fs + length_rs) / 2;
    for (int i = 0; i < length_rs; ++i)
        (*filter_rs)[i] = X_r[i_X_r_start + i];

    free(X_r);

    Print("filter_rs = [ ...\n");
    for (int i = 0; i < length_rs; ++i) Print("%.15e\n", (*filter_rs)[i]);
    Print("]\n");
    exit(0);

    // END: Use IPL's packed format for complex input to cvDFT(CV_DXT_INV)
*/
}

// END: Custom R-Weighted filter.

typedef struct 
{
    filter_1D_params_type params;

    pixel_type *filter_rs;

    fftw_complex_type *filter_fs_fftw;

    CvMat *filter_fs_cv;

    int workspace_row_length;
    pixel_type *workspace; // Workspace for convolution in real space.

    int workspace_fftw_row_length;
    int workspace_fftw_n_rows;
    pixel_type *workspace_fftw; // Workspace for convolution using FFTW.

    CvMat *workspace_cv; // Workspace for convolution using OpenCV.
}
filter_1D_data_type;

filter_1D_data_type *create_filter_1D_data_n_xy(filter_1D_params_type *params, int n_x, int n_y)
{
    static const char *function_name = "create_filter_1D_data_n_xy()";

    if (params->length_rs > n_x)
        Abort("ERROR: %s -- Filter length cannot be greater than the width of the rotated image, n_x = %i: params->length_rs = %i.\n",
            function_name, n_x, params->length_rs);

    filter_1D_data_type *filter_data = (filter_1D_data_type *) malloc(sizeof(filter_1D_data_type));
    if (filter_data == NULL)
        Abort("ERROR: %s -- Cannot acquire memory for filter_1D_data_type *filter_data.\n", function_name);
    
    filter_data->params = *params;

    filter_data->filter_rs = NULL;
    filter_data->filter_fs_fftw = NULL;
    filter_data->filter_fs_cv = NULL;
    filter_data->workspace_row_length = 0;
    filter_data->workspace = NULL;
    filter_data->workspace_fftw = NULL;
    filter_data->workspace_cv = NULL;

    int n_x_padded = filter_data->params.length_rs + n_x - 1;
    int n_x_padded_opt = cvGetOptimalDFTSize(n_x_padded);
    int n_y_opt = cvGetOptimalDFTSize(n_y);

    CvMat *filter_fs_cv;

    switch (filter_data->params.type)
    {
        case (SHEPPLOGAN) :

            filter_data->params.length_fs = n_x_padded_opt;

            create_shepp_logan_filter_1D_rsfs_cv(
                filter_data->params.length_rs,
                &(filter_data->filter_rs),
                filter_data->params.length_fs,
                &filter_fs_cv);

            break;

        case (RAMLAK) :
    
            filter_data->params.length_fs = n_x_padded_opt;

            create_ram_lak_filter_1D_rsfs_cv(
                filter_data->params.length_rs,
                &(filter_data->filter_rs),
                filter_data->params.length_fs,
                &filter_fs_cv);
    
            break;
 
        case (CUSTOMRWEIGHTED) :
        {
            filter_data->params.length_fs = (2 * n_x) + 1; // NOTE: MATLAB prototype uses this value.

#if USE_FFTW
            create_custom_r_weighted_filter_1D_fsrs_fftw(
                filter_data->params.length_fs,
                n_x_padded_opt,
                &(filter_data->filter_fs_fftw),
                filter_data->params.length_rs,
                &(filter_data->filter_rs),
                filter_data->params.cut_off,
                filter_data->params.roll_off);
#endif

            create_custom_r_weighted_filter_1D_fsrs_cv(
                filter_data->params.length_fs,
                n_x_padded_opt,
                &filter_fs_cv,
                filter_data->params.length_rs,
                &(filter_data->filter_rs),
                filter_data->params.cut_off,
                filter_data->params.roll_off);

            break;
        }
        default :

            Abort("ERROR: %s -- Unrecognized filter type.\n", function_name);
    }

    Print("[ ...\n");
    for (int i = 0; i < filter_data->params.length_rs; ++i) Print("%.15e\n", filter_data->filter_rs[i]);
    Print("]\n");

    filter_data->workspace_row_length = n_x;
    int n_bytes_row = n_x * sizeof(pixel_type);
    filter_data->workspace = (pixel_type *) malloc(n_bytes_row);
    if (filter_data->workspace == NULL)
        Abort("ERROR: %s -- Cannot acquire memory for pixel_type *workspace.\n", function_name);
    memset(filter_data->workspace, 0, n_bytes_row);

#if USE_FFTW
    // NOTE: For now, FFTW workspace contains as many filtered rows as the number of rows in the padded image.
    Abort("ERROR: %s -- USE_FFTW not implemented.\n", function_name);
#endif

    // BEGIN: OpenCV

    // NOTE: For now, OpenCV workspace contains as many filtered rows as the number of rows in the padded image.
    filter_data->workspace_cv = cvCreateMat(
        //n_y, 
        //n_x_padded,
        n_y_opt, 
        n_x_padded_opt,
        CVMAT_TYPE_REAL);
    cvZero(filter_data->workspace_cv);

    // Make filter the same size as the workspace and put copies of the filter in each row.
    CvMat tmp;

    Print("filter_fs_cv->(rows, cols) = (%i, %i)\n", filter_fs_cv->rows, filter_fs_cv->cols);
    cvGetSubRect(filter_data->workspace_cv, &tmp, cvRect(0, 0, filter_fs_cv->cols, 1));
    cvCopy(filter_fs_cv, &tmp, NULL);
    filter_data->filter_fs_cv = cvCloneMat(filter_data->workspace_cv);
    cvZero(filter_data->filter_fs_cv);
    cvGetSubRect(filter_data->workspace_cv, &tmp, cvRect(0, 0, filter_data->workspace_cv->cols, 1));
    cvRepeat(&tmp, filter_data->filter_fs_cv);

    cvReleaseMat(&filter_fs_cv);

    // END: OpenCV

    return filter_data;
}

// WARNING: This probably should not be used.
filter_1D_data_type *create_filter_1D_data(filter_1D_params_type *params, real_type support[4])
{
    static const char *function_name = "create_filter_1D_data()";

    Print("WARNING: Calling %s with support and without padding!\n", function_name);

#if PROTOTYPE_COMPLIANT_INDEXING
    int n_x = round(support[2]);
    int n_y = round(support[3]);
#else
    int n_x = round(support[2] + 1.0);
    int n_y = round(support[3] + 1.0);
#endif

    return create_filter_1D_data_n_xy(params, n_x, n_y);
}

void filter_1D_data_release(filter_1D_data_type *filter_data)
{
    static const char *function_name = "filter_1D_data_release";

    if (filter_data == NULL)
        Abort("ERROR: %s: Calling free() on NULL pointer.\n", function_name);

    if (filter_data->filter_rs != NULL)
        free(filter_data->filter_rs);

    if (filter_data->filter_fs_fftw != NULL)
        fftwf_free(filter_data->filter_fs_fftw);

    if (filter_data->filter_fs_cv != NULL)
        cvReleaseMat(&(filter_data->filter_fs_cv));

    if (filter_data->workspace != NULL)
        free(filter_data->workspace);

    //if (filter_data->workspace_fftw != NULL)
    //    free(filter_data->workspace_fftw);

    if (filter_data->workspace_cv != NULL)
        cvReleaseMat(&(filter_data->workspace_cv));

    free(filter_data);
}

enum filter_1D_type_enum get_filter_1D_type_from_string(const char *type_string)
{
    static const char *function_name = "get_filter_1D_type_from_string()";

    int type = -1;

    if (
        (strcmp(type_string, "SheppLogan") == 0) ||
        (strcmp(type_string, "Shepp-Logan") == 0)
       )
    {
        type = SHEPPLOGAN;
    }
    else if (
             (strcmp(type_string, "RamLak") == 0) ||
             (strcmp(type_string, "Ram-Lak") == 0)
            )
    {
        type = RAMLAK;
    }
    else if (
             (strcmp(type_string, "CustomRWeighted") == 0) ||
             (strcmp(type_string, "Custom R-Weighted") == 0)
            )
    {
        type = CUSTOMRWEIGHTED;
    }
    else
    {
        Abort("ERROR: %s -- Unrecognized filter type.\n", function_name);
    }

    return type;
}

filter_1D_params_type *create_filter_1D_params
(
    const char *type_string,
    int length,
    real_type cut_off,
    real_type roll_off
)
{
    static const char *function_name = "create_filter_1D_params()";

    filter_1D_params_type *filter_params = (filter_1D_params_type *) malloc(sizeof(filter_1D_params_type));
    if (filter_params == NULL)
       Abort("ERROR %s: Cannot aquire memory for filter_1D_params_type *filter_params.\n", function_name);

    // BEGIN: Default values.
    filter_1D_params_type filter_1D_params;
    filter_1D_params.type = SHEPPLOGAN;
    filter_1D_params.length_rs = 251;
    filter_1D_params.length_fs = 0;
    filter_1D_params.cut_off = 0.5;
    filter_1D_params.roll_off = 0.05;
    // END: Default values.

    filter_params->type = get_filter_1D_type_from_string(type_string);

//    if (length < 3)
//        Abort("ERROR: %s -- Filter length cannot be less than 3: length = %i.\n", function_name, length);

    // NOTE: Only odd-length filters allowed.
    if (length % 2 == 0)
        Abort("ERROR: %s -- Only odd-length filters allowed: length = %i.\n", function_name, length);

    //if (length % 2 == 0)
    //    ++length;

    filter_params->length_rs = length;
    filter_params->length_fs = 0;

    if (filter_params->type == CUSTOMRWEIGHTED)
    {
        filter_params->cut_off = cut_off;
        filter_params->roll_off = roll_off;
    }
    else
    {
        filter_params->cut_off = 0.0;
        filter_params->roll_off = 0.0;
    }

    return filter_params;
}

// WARNING: Unsafe!  Have not written proper checks!
filter_1D_params_type *create_filter_1D_params_from_strings
(
    const char *type_string,
    const char *length_string,
    const char *cut_off_string,
    const char *roll_off_string
)
{
    int length = atoi(length_string);

    real_type cut_off = 0.0;
    real_type roll_off = 0.0;

    if (cut_off_string)
        cut_off = atof(cut_off_string);

    if (roll_off_string)
        roll_off = atof(roll_off_string);

    return create_filter_1D_params(type_string, length, cut_off, roll_off);
}

void projection_filter_1D_fs(IplImage *image, filter_1D_data_type *filter_data)
{
    static const char *function_name = "projection_filter_1D_fs()";

    int dft_rows = cvGetOptimalDFTSize(image->height); // NOTE: This may not be necessary since we are using cvDFT(CV_DXT_ROWS).
    int dft_cols = cvGetOptimalDFTSize(filter_data->params.length_rs + image->width - 1);
    //int dft_rows = image->height; // DEBUG.
    //int dft_cols = filter_data->params.length_fs; // DEBUG.

    CvMat *workspace = filter_data->workspace_cv;

    if ((dft_rows != workspace->rows) || (dft_cols != workspace->cols))
        Abort("ERROR: %s -- (dft_rows, dft_cols) = (%i, %i) != (workspace->rows, workspace->cols) = (%i, %i)\n", function_name, dft_rows, dft_cols, workspace->rows, workspace->cols);

    CvMat tmp;

    cvGetSubRect(workspace, &tmp, cvRect(0, 0, image->width, image->height));
    cvCopy(image, &tmp, NULL);
    cvGetSubRect(workspace, &tmp, cvRect(image->width, 0, workspace->cols - image->width, image->height));
    cvZero(&tmp);
    //cvSet(&tmp, cvRealScalar(666.0), NULL);

    //print_CvMat("workspace", workspace);

    cvDFT(workspace, workspace, CV_DXT_FORWARD | CV_DXT_ROWS, image->height);

    //print_CvMat_packed_complex("workspace", workspace);
    //print_CvMat_packed_complex("filter_data->filter_fs_cv", filter_data->filter_fs_cv);

    cvMulSpectrums(workspace, filter_data->filter_fs_cv, workspace, CV_DXT_ROWS);

    cvDFT(workspace, workspace, CV_DXT_INV_SCALE | CV_DXT_ROWS, image->height);

    //print_CvMat("workspace", workspace);

    cvGetSubRect(workspace, &tmp, cvRect(filter_data->params.length_rs / 2, 0, image->width, image->height));
    cvCopy(&tmp, image, NULL);
}

void slice_filter_1D_fs_cv(Islice *slice, filter_1D_data_type *filter_data)
{
    static const char *function_name = "slice_filter_1D_fs_cv()";

    CvMat *slice_cv = create_CvMat_from_Islice_copy(slice, CVMAT_TYPE_REAL);

    int dft_rows = cvGetOptimalDFTSize(slice_cv->rows); // NOTE: This may not be necessary since we are using cvDFT(CV_DXT_ROWS).
    int dft_cols = cvGetOptimalDFTSize(filter_data->params.length_rs + slice_cv->cols - 1);
    //int dft_rows = slice_cv->rows; // DEBUG.
    //int dft_cols = filter_data->params.length_fs; // DEBUG.

    CvMat *workspace = filter_data->workspace_cv;

    if ((dft_rows != workspace->rows) || (dft_cols != workspace->cols))
        Abort("ERROR: %s -- (dft_rows, dft_cols) = (%i, %i) != (workspace->rows, workspace->cols) = (%i, %i)\n",
            function_name, dft_rows, dft_cols, workspace->rows, workspace->cols);

    CvMat tmp;

    cvGetSubRect(workspace, &tmp, cvRect(0, 0, slice_cv->cols, slice_cv->rows));
    cvCopy(slice_cv, &tmp, NULL);
    cvGetSubRect(workspace, &tmp, cvRect(slice_cv->cols, 0, workspace->cols - slice_cv->cols, slice_cv->rows));
    cvZero(&tmp);
    //cvSet(&tmp, cvRealScalar(666.0), NULL);

    //print_CvMat("workspace", workspace);

    cvDFT(workspace, workspace, CV_DXT_FORWARD | CV_DXT_ROWS, slice_cv->rows);

    //print_CvMat_packed_complex("workspace", workspace);
    //print_CvMat_packed_complex("filter_data->filter_fs_cv", filter_data->filter_fs_cv);

    cvMulSpectrums(workspace, filter_data->filter_fs_cv, workspace, CV_DXT_ROWS);

    cvDFT(workspace, workspace, CV_DXT_INV_SCALE | CV_DXT_ROWS, slice_cv->rows);

    //print_CvMat("workspace", workspace);

    cvGetSubRect(workspace, &tmp, cvRect(round(filter_data->params.length_rs / 2), 0, slice_cv->cols, slice_cv->rows));
    cvCopy(&tmp, slice_cv, NULL);
    copy_CvMat_to_Islice(slice_cv, slice);

    free_data_cvReleaseMat(slice_cv);
}

void slice_filter_1D_rs(Islice *slice, pixel_type *filter_1D, int filter_length, pixel_type *row_filtered)
{
//float v_clear = 1.0;
//sliceClear(slice, &v_clear);
//return 1;

    int n_x = slice->xsize;
    int n_y = slice->ysize;
    float *slice_data_f = slice->data.f;

    int filter_half_length = filter_length / 2;
    int x_full_stop = n_x - filter_half_length;
    for (int i_y = 0; i_y < n_y; ++i_y)
    {
        int i_x = 0;
        int i_filter_start = filter_half_length;
        for (; i_x < filter_half_length; ++i_x) 
        {
            pixel_type v = 0.0;
            for (int i_filter = i_filter_start; i_filter < filter_length; ++i_filter) 
            {
                v += filter_1D[i_filter] * INDEX2D(slice_data_f, n_x, i_x + (i_filter - filter_half_length), i_y);
            }
            row_filtered[i_x] = v;
            --i_filter_start;
        }
        //if (int i_x != filter_half_length) exit(0); // NOTE: This is what we expect.
        for (; i_x < x_full_stop; ++i_x) 
        {
            pixel_type v = 0.0;
            for (int i_filter = 0; i_filter < filter_length; ++i_filter) 
            {
                v += filter_1D[i_filter] * INDEX2D(slice_data_f, n_x, i_x + (i_filter - filter_half_length), i_y);
            }
            row_filtered[i_x] = v;
        }
        int i_filter_stop = filter_length - 1;
        for (; i_x < n_x; ++i_x) 
        {
            pixel_type v = 0.0;
            for (int i_filter = 0; i_filter < i_filter_stop; ++i_filter) 
            {
                v += filter_1D[i_filter] * INDEX2D(slice_data_f, n_x, i_x + (i_filter - filter_half_length), i_y);
            }
            row_filtered[i_x] = v;
            --i_filter_stop;
        }

        for (i_x = 0; i_x < n_x; ++i_x)
            PUTVAL2D(slice_data_f, n_x, i_x, i_y, row_filtered[i_x]);
    }
}

// If rotation is small or close to +/-90 or +/-180, use a smaller step.
int test_rotation_matrix_for_subsampling(real_type rot_matrix[2][2])
{
    real_type max;

    // If rotation is small.
    max = TXBR_MAX(fabs(rot_matrix[0][0] - 1.0), fabs(rot_matrix[0][1]));
    max = TXBR_MAX(max, fabs(rot_matrix[1][0])); max = TXBR_MAX(max, fabs(rot_matrix[1][1] - 1.0));
//Print("%.15e\n", max);

    if (max < EPSILON) return 0;

    // If rotation is close to +90.
    max = TXBR_MAX(fabs(rot_matrix[0][0]), fabs(rot_matrix[0][1] - 1.0));
    max = TXBR_MAX(max, fabs(rot_matrix[1][0] + 1.0)); max = TXBR_MAX(max, fabs(rot_matrix[1][1]));
//Print("%.15e\n", max);

    if (max < EPSILON) return 0;

    // If rotation is close to -90.
    max = TXBR_MAX(fabs(rot_matrix[0][0]), fabs(rot_matrix[0][1] + 1.0));
    max = TXBR_MAX(max, fabs(rot_matrix[1][0] - 1.0)); max = TXBR_MAX(max, fabs(rot_matrix[1][1]));
//Print("%.15e\n", max);

    if (max < EPSILON) return 0;

    // If rotation is close to +/-180.
    max = TXBR_MAX(fabs(rot_matrix[0][0]) + 1.0, fabs(rot_matrix[0][1]));
    max = TXBR_MAX(max, fabs(rot_matrix[1][0])); max = TXBR_MAX(max, fabs(rot_matrix[1][1] + 1.0));
//Print("%.15e\n", max);

    if (max < EPSILON) return 0;

    return 1;
}

////////////////////////////////////////////////////////////////////////////////
// END: Filtering.
////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////
// BEGIN: Transforms.
////////////////////////////////////////////////////////////////////////////////


#define TRANSFORM_PROJECTION_IPLIMAGE_PULL_2D_FINITE_DIFF
//#define TRANSFORM_PROJECTION_IPLIMAGE_PULL_1D_FINITE_DIFF
//#define TRANSFORM_PROJECTION_IPLIMAGE_PUSH

#define TRANSFORM_PROJECTION_CHECK_BOUNDS 0

#if defined TRANSFORM_PROJECTION_IPLIMAGE_PULL_2D_FINITE_DIFF

// NOTE: This pulls pixel values from the original projection to the new one.
// NOTE: Both dimensions use finite difference scheme.
void transform_projection
(
    IplImage *projection0,
    real_type support0[4],
    real_type rot_matrix[2][2],
    IplImage *projection,
    real_type support[4]
)
{
    static const char *function_name = "transform_projection()";

#if PROTOTYPE_COMPLIANT_INDEXING
    Abort("ERROR %s -- PROTOTYPE_COMPLIANT_INDEXING not implemented!\n", function_name);
#endif

//    clock_t t_0, t_1;
//    double secs_per_clock = 1.0 / CLOCKS_PER_SEC;

    if ((projection0->depth != IPL_DEPTH_32F) && (projection0->depth != IPL_DEPTH_64F))
        Abort("ERROR: %s -- Expected image->depth = %i (IPL_DEPTH_32F) or %i (IPL_DEPTH_64F), but image->depth = %i.\n",
            function_name, IPL_DEPTH_32F, IPL_DEPTH_64F, projection0->depth);

    if ((projection->depth != IPL_DEPTH_32F) && (projection->depth != IPL_DEPTH_64F))
        Abort("ERROR: %s -- Expected image->depth = %i (IPL_DEPTH_32F) or %i (IPL_DEPTH_64F), but image->depth = %i.\n",
            function_name, IPL_DEPTH_32F, IPL_DEPTH_64F, projection->depth);

    cvSetZero(projection);

    real_type *projection0_data = (real_type *) projection0->imageData;
    int n0_x = projection0->width;
    int n0_y = projection0->height;
    real_type center0_x = (real_type) (n0_x - 1.0) / 2.0;
    real_type center0_y = (real_type) (n0_y - 1.0) / 2.0;

    real_type center0_x_support = support0[0];
    real_type center0_y_support = support0[1];
    real_type n0_x_min = center0_x - center0_x_support;
    real_type n0_x_max = center0_x + center0_x_support;
    real_type n0_y_min = center0_y - center0_y_support;
    real_type n0_y_max = center0_y + center0_y_support;

    Print("n0_xy = (%i, %i), center0_xy = (%.15e, %.15e)\n", n0_x, n0_y, center0_x, center0_y);
    Print("center0_xy_support = (%.15e, %.15e)\n", center0_x_support, center0_y_support);
    Print("n0_xy_min = (%.15e, %.15e), n0_xy_max = (%.15e, %.15e)\n", n0_x_min, n0_y_min, n0_x_max, n0_y_max);

    real_type *projection_data = (real_type *) projection->imageData;
    int n_x = projection->width;
    int n_y = projection->height;
    real_type center_x = (real_type) (n_x - 1.0) / 2.0;
    real_type center_y = (real_type) (n_y - 1.0) / 2.0;

    real_type center_x_support = support[0];
    real_type center_y_support = support[1];
    real_type n_x_min = center_x - center_x_support;
    real_type n_x_max = center_x + center_x_support;
    real_type n_y_min = center_y - center_y_support;
    real_type n_y_max = center_y + center_y_support;

    Print("n_xy = (%i, %i), center_xy = (%.15e, %.15e)\n", n_x, n_y, center_x, center_y);
    Print("center_xy_support = (%.15e, %.15e)\n", center_x_support, center_y_support);
    Print("n_xy_min = (%.15e, %.15e), n_xy_max = (%.15e, %.15e)\n", n_x_min, n_y_min, n_x_max, n_y_max);

    if ((n0_x_min < 0.0) || (n0_y_min < 0.0) || 
        ((real_type) n0_x < n0_x_max) || ((real_type) n0_y < n0_y_max) || 
        (n_x_min < 0.0) || (n_y_min < 0.0) || 
        ((real_type) n_x < n_x_max) || ((real_type) n_y < n_y_max))
        Abort("ERROR %s -- Support extends beyond projection.\n", function_name); 

    real_type step;
    if (test_rotation_matrix_for_subsampling(rot_matrix))
        step = 0.25;
    else
        step = 1.0;

    //step = 0.25;  Print("DEBUG: WARNING: step is hardcoded to %.15e.\n", step);

    Print("step = %.15e\n", step);
//    exit(0);

    real_type sample_factor = step; // MATLAB prototype uses step for number of samples per pixel.
    //real_type sample_factor = step * step;
    //real_type sample_factor = 1.0; Print("DEBUG: WARNING: sample_factor is hardcoded to %.15e.\n", sample_factor);

    // NOTE: Use the inverse rotation matrix.
    real_type rot_matrix00 = rot_matrix[0][0];
    real_type rot_matrix01 = rot_matrix[1][0];
    real_type rot_matrix10 = rot_matrix[0][1];
    real_type rot_matrix11 = rot_matrix[1][1];

    real_type x0_init = 0.0;
    real_type y0_init = 0.0;

    real_type x_trans_x_init = n_x_min - center_x; // NOTE: From center of support in image coordinates, so from center of image.
    real_type x_trans_x_init_rot_x = rot_matrix00 * x_trans_x_init;
    real_type x_trans_x_init_rot_y = rot_matrix10 * x_trans_x_init;
    x0_init += x_trans_x_init_rot_x;
    y0_init += x_trans_x_init_rot_y;

    real_type y_trans_y_init = n_y_min - center_y; // NOTE: From center of support in image coordinates, so from center of image.
    real_type y_trans_y_init_rot_x = rot_matrix01 * y_trans_y_init;
    real_type y_trans_y_init_rot_y = rot_matrix11 * y_trans_y_init;
    x0_init += y_trans_y_init_rot_x;
    y0_init += y_trans_y_init_rot_y;

    x0_init += center0_x;
    y0_init += center0_y;

    real_type x0_del_x = rot_matrix00 * step;
    real_type y0_del_x = rot_matrix10 * step;

    real_type x0_del_y = rot_matrix01 * step;
    real_type y0_del_y = rot_matrix11 * step;

    real_type y0 = y0_init;

    for (real_type y = n_y_min; y <= n_y_max; y += step) // NOTE: In image coordinates.
    {
        int y_floor = (int) floor(y);
        real_type y_alpha = y - (real_type) y_floor;

        real_type x0 = x0_init;

        for (real_type x = n_x_min; x <= n_x_max; x += step) // NOTE: In image coordinates.
        {
//            t_0 = clock();

            int x_floor = (int) floor(x);
            real_type x_alpha = x - (real_type) x_floor;

//            Print("x_floor = %i\n", x_floor);
//            Print("y_floor = %i\n", y_floor);

//            Print("x_alpha = %.15e\n", x_alpha);
//            Print("y_alpha = %.15e\n", y_alpha);

            // In order to avoid yet another boundary check, we have padded projection0.
//            real_type v = INTERPOLATE_2(projection_data, n_x, x_floor, y_floor, x_alpha, y_alpha) * sample_factor;
//            real_type v = INDEX2D(projection_data, n_x, x_floor, y_floor) * sample_factor;
            real_type v = 0.0;

            //Print("v = %.15e\n", v);

//            Print("x0 = %.15e\n", x0);
//            Print("y0 = %.15e\n", y0);

            int x0_floor = (int) floor(x0);
            int y0_floor = (int) floor(y0);

            real_type x0_alpha = x0 - (real_type) x0_floor;
            real_type y0_alpha = y0 - (real_type) y0_floor;

//            t_1 = clock();
//            Print("%i %i\n", t_1, t_0);
//            Print("Pre-boundary-test delta t:%.15e\n", secs_per_clock * ((double) t_1 - (double) t_0));

//            t_0 = clock();

            // NOTE: We can get away with this because we know both IplImages are mode IPL_DEPTH_64F.
            pixel_type v0 = 0.0;

#if TRANSFORM_PROJECTION_CHECK_BOUNDS
//            if ((x0_floor >= n0_x_support_min) && (x0_floor <= n0_x_support_max) && (y0_floor >= n0_y_support_min) && (y0_floor <= n0_y_support_max))
            if ((x0_floor >= 0) && (x0_floor < n0_x) && (y0_floor >= 0) && (y0_floor < n0_y))
            {
#endif
                v0 = INDEX2D(projection0_data, n0_x, x0_floor, y0_floor) * (1.0 - x0_alpha) * (1.0 - y0_alpha);
                v += v0;
//                Print("(%i, %i) = %.15e\n", x0_floor, y0_floor, v0);
#if TRANSFORM_PROJECTION_CHECK_BOUNDS
            }
            else
            {
                Print("(%i, %i)\n", x_floor, y_floor);
                Print("(%i, %i)\n", x0_floor, y0_floor);
                Abort("ERROR %s -- Source projection bounds violated (0, 0).\n", function_name); 
            }
#endif

#if TRANSFORM_PROJECTION_CHECK_BOUNDS
//            if ((x0_floor + 1 >= n0_x_support_min) && (x0_floor + 1 <= n0_x_support_max) && (y0_floor >= n0_y_support_min) && (y0_floor <= n0_y_support_max))
            if ((x0_floor + 1 >= 0) && (x0_floor + 1 < n0_x) && (y0_floor >= 0) && (y0_floor < n0_y))
            {
#endif
                v0 = INDEX2D(projection0_data, n0_x, x0_floor + 1, y0_floor) * x0_alpha * (1.0 - y0_alpha);
                v += v0;
//                Print("(%i, %i) = %.15e\n", x0_floor + 1, y0_floor, v0);
#if TRANSFORM_PROJECTION_CHECK_BOUNDS
            }
            else
            {
                Print("(%i, %i)\n", x_floor, y_floor);
                Print("(%i, %i)\n", x0_floor + 1, y0_floor);
                Abort("ERROR %s -- Source projection bounds violated (1, 0).\n", function_name); 
            }
#endif

#if TRANSFORM_PROJECTION_CHECK_BOUNDS
//            if ((x0_floor >= n0_x_support_min) && (x0_floor <= n0_x_support_max) && (y0_floor + 1 >= n0_y_support_min) && (y0_floor + 1 <= n0_y_support_max))
            if ((x0_floor >= 0) && (x0_floor < n0_x) && (y0_floor + 1 >= 0) && (y0_floor + 1 < n0_y))
            {
#endif
                v0 = INDEX2D(projection0_data, n0_x, x0_floor, y0_floor + 1) * (1.0 - x0_alpha) * y0_alpha;
                v += v0;
#if TRANSFORM_PROJECTION_CHECK_BOUNDS
//                Print("(%i, %i) = %.15e\n", x0_floor, y0_floor + 1, v0);
            }
            else
            {
                Print("(%i, %i)\n", x_floor, y_floor);
                Print("(%i, %i)\n", x0_floor, y0_floor + 1);
                Abort("ERROR %s -- Source projection bounds violated (0, 1).\n", function_name); 
            }
#endif

#if TRANSFORM_PROJECTION_CHECK_BOUNDS
//            if ((x0_floor + 1 >= n0_x_support_min) && (x0_floor + 1 <= n0_x_support_max) && (y0_floor + 1 >= n0_y_support_min) && (y0_floor + 1 <= n0_y_support_max))
            if ((x0_floor + 1 >= 0) && (x0_floor + 1 < n0_x) && (y0_floor + 1 >= 0) && (y0_floor + 1 < n0_y))
            {
#endif
                v0 = INDEX2D(projection0_data, n0_x, x0_floor + 1, y0_floor + 1) * x0_alpha * y0_alpha;
                v += v0;
//                Print("(%i, %i) = %.15e\n", x0_floor + 1, y0_floor + 1, v0);
#if TRANSFORM_PROJECTION_CHECK_BOUNDS
            }
            else
            {
                Print("(%i, %i)\n", x_floor, y_floor);
                Print("(%i, %i)\n", x0_floor + 1, y0_floor + 1);
                Abort("ERROR %s -- Source projection bounds violated (1, 1).\n", function_name); 
            }
#endif

            v *= sample_factor;

//            t_1 = clock();
//            Print("%i %i\n", t_1, t_0);
//            Print("Boundary test delta t:%.15e\n", secs_per_clock * ((double) t_1 - (double) t_0));

//            PUTVAL2D(projection_data, n_x, x_floor, y_floor, v * (1.0 - x_alpha) * (1.0 - y_alpha) * sample_factor);
//            PUTVAL2D(projection_data, n_x, x_floor + 1, y_floor, v * x_alpha * (1.0 - y_alpha) * sample_factor);
//            PUTVAL2D(projection_data, n_x, x_floor, y_floor + 1, v * (1.0 - x_alpha) * y_alpha * sample_factor);
//            PUTVAL2D(projection_data, n_x, x_floor + 1, y_floor + 1, v * x_alpha * y_alpha * sample_factor);
            ADDVAL2D(projection_data, n_x, x_floor, y_floor, v * (1.0 - x_alpha) * (1.0 - y_alpha));
            ADDVAL2D(projection_data, n_x, x_floor + 1, y_floor, v * x_alpha * (1.0 - y_alpha));
            ADDVAL2D(projection_data, n_x, x_floor, y_floor + 1, v * (1.0 - x_alpha) * y_alpha);
            ADDVAL2D(projection_data, n_x, x_floor + 1, y_floor + 1, v * x_alpha * y_alpha);

            x0 += x0_del_x;
            y0 += y0_del_x;
        }

        x0_init += x0_del_y;
        y0_init += y0_del_y;
        y0 = y0_init;
    }
//    exit(0);
}

#elif defined TRANSFORM_PROJECTION_IPLIMAGE_PULL_1D_FINITE_DIFF

// WARNING: IPL_DEPTH_64F only!
// NOTE: This pulls pixel values from the original projection to the new one.
// NOTE: One dimension uses finite difference scheme.
void transform_projection
(
    IplImage *projection0,
    real_type support0[4],
    real_type rot_matrix[2][2],
    IplImage *projection,
    real_type support[4]
)
{
    static const char *function_name = "transform_projection()";

#if PROTOTYPE_COMPLIANT_INDEXING
    Abort("ERROR %s -- PROTOTYPE_COMPLIANT_INDEXING not implemented!\n", function_name);
#endif

//    clock_t t_0, t_1;
//    double secs_per_clock = 1.0 / CLOCKS_PER_SEC;

    if (projection0->depth != IPL_DEPTH_64F)
        Abort("ERROR: %s -- Expected projection0->depth = %i (IPL_DEPTH_64F), but projection0->depth = %i.\n",
            function_name, IPL_DEPTH_64F, projection0->depth);

    if (projection->depth != IPL_DEPTH_64F)
        Abort("ERROR: %s -- Expected projection->depth = %i (IPL_DEPTH_64F), but projection->depth = %i.\n",
            function_name, IPL_DEPTH_64F, projection->depth);

    cvSetZero(projection);

    double *projection0_data = (double *) projection0->imageData;
    int n0_x = projection0->width;
    int n0_y = projection0->height;
    real_type center0_x = (real_type) (n0_x - 1.0) / 2.0;
    real_type center0_y = (real_type) (n0_y - 1.0) / 2.0;

    real_type center0_x_support = support0[0];
    real_type center0_y_support = support0[1];
    real_type n0_x_support = round(support0[2] + 1.0);
    real_type n0_y_support = round(support0[3] + 1.0);
    real_type n0_x_min = center0_x - center0_x_support;
    real_type n0_x_max = center0_x + center0_x_support;
    real_type n0_y_min = center0_y - center0_y_support;
    real_type n0_y_max = center0_y + center0_y_support;

    Print("n0_xy = (%i, %i), center0_xy = (%.15e, %.15e)\n", n0_x, n0_y, center0_x, center0_y);
    Print("center0_xy_support = (%.15e, %.15e), n0_xy_support = (%.15e, %.15e)\n", center0_x_support, center0_y_support, n0_x_support, n0_y_support);
    Print("n0_xy_min = (%.15e, %.15e), n0_xy_max = (%.15e, %.15e)\n", n0_x_min, n0_y_min, n0_x_max, n0_y_max);

    double *projection_data = (double *) projection->imageData;
    int n_x = projection->width;
    int n_y = projection->height;
    real_type center_x = (real_type) (n_x - 1.0) / 2.0;
    real_type center_y = (real_type) (n_y - 1.0) / 2.0;

    real_type center_x_support = support[0];
    real_type center_y_support = support[1];
    real_type n_x_support = round(support[2] + 1.0);
    real_type n_y_support = round(support[3] + 1.0);
    real_type n_x_min = center_x - center_x_support;
    real_type n_x_max = center_x + center_x_support;
    real_type n_y_min = center_y - center_y_support;
    real_type n_y_max = center_y + center_y_support;

    Print("n_xy = (%i, %i), center_xy = (%.15e, %.15e)\n", n_x, n_y, center_x, center_y);
    Print("center_xy_support = (%.15e, %.15e), n_xy_support = (%.15e, %.15e)\n", center_x_support, center_y_support, n_x_support, n_y_support);
    Print("n_xy_min = (%.15e, %.15e), n_xy_max = (%.15e, %.15e)\n", n_x_min, n_y_min, n_x_max, n_y_max);

    if ((n0_x_min < 0.0) || (n0_y_min < 0.0) || 
        ((real_type) n0_x < n0_x_max) || ((real_type) n0_y < n0_y_max) || 
        (n_x_min < 0.0) || (n_y_min < 0.0) || 
        ((real_type) n_x < n_x_max) || ((real_type) n_y < n_y_max))
        Abort("ERROR %s -- Support extends beyond projection.\n", function_name); 

    real_type step;
    if (test_rotation_matrix_for_subsampling(rot_matrix))
        step = 0.25;
    else
        step = 1.0;

    //step = 0.25;  Print("DEBUG: WARNING: step is hardcoded to %.15e.\n", step);

    Print("step = %.15e\n", step);
//    exit(0);

    real_type sample_factor = step; // MATLAB prototype uses step for number of samples per pixel.
    //real_type sample_factor = step * step;
    //real_type sample_factor = 1.0; Print("DEBUG: WARNING: sample_factor is hardcoded to %.15e.\n", sample_factor);

    // NOTE: Use the inverse rotation matrix.
    real_type rot_matrix00 = rot_matrix[0][0];
    real_type rot_matrix01 = rot_matrix[1][0];
    real_type rot_matrix10 = rot_matrix[0][1];
    real_type rot_matrix11 = rot_matrix[1][1];

    // WARNING: NEED TO TURN LOOPS INSIDE OUT!
    for (real_type x = n_x_min; x <= n_x_max; x += step) // NOTE: In image coordinates.
    {
        int x_floor = (int) floor(x);
        real_type x_alpha = x - (real_type) x_floor;
        real_type x_trans_x = x - center_x; // NOTE: From center of support in image coordinates, so from center of image.
        real_type x_trans_x_rot_x = rot_matrix00 * x_trans_x;
        real_type x_trans_x_rot_y = rot_matrix10 * x_trans_x;
        real_type x_trans_x_rot_x_trans0_x = x_trans_x_rot_x + center0_x;
        real_type x_trans_x_rot_y_trans0_y = x_trans_x_rot_y + center0_y;

        real_type y_trans = n_y_min - center_y;

        real_type x0 = x_trans_x_rot_x_trans0_x + (rot_matrix01 * y_trans);
        real_type y0 = x_trans_x_rot_y_trans0_y + (rot_matrix11 * y_trans);

        real_type x0_del_y = rot_matrix01 * step;
        real_type y0_del_y = rot_matrix11 * step;

        for (real_type y = n_y_min; y <= n_y_max; y += step) // NOTE: In image coordinates.
        {
//            t_0 = clock();

            int y_floor = (int) floor(y);

            real_type y_alpha = y - (real_type) y_floor;

//            Print("x_floor = %i\n", x_floor);
//            Print("y_floor = %i\n", y_floor);

//            Print("x_alpha = %.15e\n", x_alpha);
//            Print("y_alpha = %.15e\n", y_alpha);

            // In order to avoid yet another boundary check, we have padded projection0.
//            real_type v = INTERPOLATE_2(projection_data, n_x, x_floor, y_floor, x_alpha, y_alpha) * sample_factor;
//            real_type v = INDEX2D(projection_data, n_x, x_floor, y_floor) * sample_factor;
            real_type v = 0.0;

            //Print("v = %.15e\n", v);

//            Print("x0 = %.15e\n", x0);
//            Print("y0 = %.15e\n", y0);

            int x0_floor = (int) floor(x0);
            int y0_floor = (int) floor(y0);

            real_type x0_alpha = x0 - (real_type) x0_floor;
            real_type y0_alpha = y0 - (real_type) y0_floor;

//            t_1 = clock();
//            Print("%i %i\n", t_1, t_0);
//            Print("Pre-boundary-test delta t:%.15e\n", secs_per_clock * ((double) t_1 - (double) t_0));

//            t_0 = clock();

            // NOTE: We can get away with this because we know both IplImages are mode IPL_DEPTH_64F.
            pixel_type v0 = 0.0;

#if TRANSFORM_PROJECTION_CHECK_BOUNDS
//            if ((x0_floor >= n0_x_support_min) && (x0_floor <= n0_x_support_max) && (y0_floor >= n0_y_support_min) && (y0_floor <= n0_y_support_max))
            if ((x0_floor >= 0) && (x0_floor < n0_x) && (y0_floor >= 0) && (y0_floor < n0_y))
            {
#endif
                v0 = INDEX2D(projection0_data, n0_x, x0_floor, y0_floor) * (1.0 - x0_alpha) * (1.0 - y0_alpha);
                v += v0;
//                Print("(%i, %i) = %.15e\n", x0_floor, y0_floor, v0);
#if TRANSFORM_PROJECTION_CHECK_BOUNDS
            }
            else
            {
                Print("(%i, %i)\n", x_floor, y_floor);
                Print("(%i, %i)\n", x0_floor, y0_floor);
                Abort("ERROR %s -- Source projection bounds violated (0, 0).\n", function_name); 
            }
#endif

#if TRANSFORM_PROJECTION_CHECK_BOUNDS
//            if ((x0_floor + 1 >= n0_x_support_min) && (x0_floor + 1 <= n0_x_support_max) && (y0_floor >= n0_y_support_min) && (y0_floor <= n0_y_support_max))
            if ((x0_floor + 1 >= 0) && (x0_floor + 1 < n0_x) && (y0_floor >= 0) && (y0_floor < n0_y))
            {
#endif
                v0 = INDEX2D(projection0_data, n0_x, x0_floor + 1, y0_floor) * x0_alpha * (1.0 - y0_alpha);
                v += v0;
//                Print("(%i, %i) = %.15e\n", x0_floor + 1, y0_floor, v0);
#if TRANSFORM_PROJECTION_CHECK_BOUNDS
            }
            else
            {
                Print("(%i, %i)\n", x_floor, y_floor);
                Print("(%i, %i)\n", x0_floor + 1, y0_floor);
                Abort("ERROR %s -- Source projection bounds violated (1, 0).\n", function_name); 
            }
#endif

#if TRANSFORM_PROJECTION_CHECK_BOUNDS
//            if ((x0_floor >= n0_x_support_min) && (x0_floor <= n0_x_support_max) && (y0_floor + 1 >= n0_y_support_min) && (y0_floor + 1 <= n0_y_support_max))
            if ((x0_floor >= 0) && (x0_floor < n0_x) && (y0_floor + 1 >= 0) && (y0_floor + 1 < n0_y))
            {
#endif
                v0 = INDEX2D(projection0_data, n0_x, x0_floor, y0_floor + 1) * (1.0 - x0_alpha) * y0_alpha;
                v += v0;
#if TRANSFORM_PROJECTION_CHECK_BOUNDS
//                Print("(%i, %i) = %.15e\n", x0_floor, y0_floor + 1, v0);
            }
            else
            {
                Print("(%i, %i)\n", x_floor, y_floor);
                Print("(%i, %i)\n", x0_floor, y0_floor + 1);
                Abort("ERROR %s -- Source projection bounds violated (0, 1).\n", function_name); 
            }
#endif

#if TRANSFORM_PROJECTION_CHECK_BOUNDS
//            if ((x0_floor + 1 >= n0_x_support_min) && (x0_floor + 1 <= n0_x_support_max) && (y0_floor + 1 >= n0_y_support_min) && (y0_floor + 1 <= n0_y_support_max))
            if ((x0_floor + 1 >= 0) && (x0_floor + 1 < n0_x) && (y0_floor + 1 >= 0) && (y0_floor + 1 < n0_y))
            {
#endif
                v0 = INDEX2D(projection0_data, n0_x, x0_floor + 1, y0_floor + 1) * x0_alpha * y0_alpha;
                v += v0;
//                Print("(%i, %i) = %.15e\n", x0_floor + 1, y0_floor + 1, v0);
#if TRANSFORM_PROJECTION_CHECK_BOUNDS
            }
            else
            {
                Print("(%i, %i)\n", x_floor, y_floor);
                Print("(%i, %i)\n", x0_floor + 1, y0_floor + 1);
                Abort("ERROR %s -- Source projection bounds violated (1, 1).\n", function_name); 
            }
#endif

            v *= sample_factor;

//            t_1 = clock();
//            Print("%i %i\n", t_1, t_0);
//            Print("Boundary test delta t:%.15e\n", secs_per_clock * ((double) t_1 - (double) t_0));

//            PUTVAL2D(projection_data, n_x, x_floor, y_floor, v * (1.0 - x_alpha) * (1.0 - y_alpha) * sample_factor);
//            PUTVAL2D(projection_data, n_x, x_floor + 1, y_floor, v * x_alpha * (1.0 - y_alpha) * sample_factor);
//            PUTVAL2D(projection_data, n_x, x_floor, y_floor + 1, v * (1.0 - x_alpha) * y_alpha * sample_factor);
//            PUTVAL2D(projection_data, n_x, x_floor + 1, y_floor + 1, v * x_alpha * y_alpha * sample_factor);
            ADDVAL2D(projection_data, n_x, x_floor, y_floor, v * (1.0 - x_alpha) * (1.0 - y_alpha));
            ADDVAL2D(projection_data, n_x, x_floor + 1, y_floor, v * x_alpha * (1.0 - y_alpha));
            ADDVAL2D(projection_data, n_x, x_floor, y_floor + 1, v * (1.0 - x_alpha) * y_alpha);
            ADDVAL2D(projection_data, n_x, x_floor + 1, y_floor + 1, v * x_alpha * y_alpha);

            x0 += x0_del_y;
            y0 += y0_del_y;
        }
    }
//    exit(0);
}

#elif defined TRANSFORM_PROJECTION_IPLIMAGE_PUSH

// WARNING: IPL_DEPTH_64F only!
// NOTE: This pushes pixel values from the original projection to the new one.  This is fine with rotations.
void transform_projection
(
    IplImage *projection0,
    real_type support0[4],
    real_type rot_matrix[2][2],
    IplImage *projection,
    real_type support[4]
)
{
    static const char *function_name = "transform_projection()";

//    clock_t t_0, t_1;
//    double secs_per_clock = 1.0 / CLOCKS_PER_SEC;

    if (projection0->depth != IPL_DEPTH_64F)
        Abort("ERROR: %s -- Expected projection0->depth = %i (IPL_DEPTH_64F), but projection0->depth = %i.\n",
            function_name, IPL_DEPTH_64F, projection0->depth);

    if (projection->depth != IPL_DEPTH_64F)
        Abort("ERROR: %s -- Expected projection->depth = %i (IPL_DEPTH_64F), but projection->depth = %i.\n",
            function_name, IPL_DEPTH_64F, projection->depth);

    cvSetZero(projection);

    double *projection0_data = (double *) projection0->imageData;
    int n0_x = projection0->width; // This is required because the original projection has been padded.
    int n0_y = projection0->height; // Unnecessary.

    real_type center0_x = support0[0];
    real_type center0_y = support0[1];
#if PROTOTYPE_COMPLIANT_INDEXING
    real_type n0_x_real = round(support0[2]);
    real_type n0_y_real = round(support0[3]);
#else
    real_type n0_x_real = round(support0[2]);
    real_type n0_y_real = round(support0[3]);
    //real_type n0_x_real = round(support0[2] + 1.0);
    //real_type n0_y_real = round(support0[3] + 1.0);
#endif

    Print("n0_x = %i, n0_y = %i, center0_x = %.15e, center0_y = %.15e, n0_x_real = %.15e, n0_y_real = %.15e\n", n0_x, n0_y, center0_x, center0_y, n0_x_real, n0_y_real);

    double *projection_data = (double *) projection->imageData;
    int n_x = projection->width; // This is required because the transformed projection has been padded.
    int n_y = projection->height; // Unnecessary.

    real_type center_x = support[0];
    real_type center_y = support[1];
#if PROTOTYPE_COMPLIANT_INDEXING
    real_type n_x_real = round(support[2]);
    real_type n_y_real = round(support[3]);
#else
    real_type n_x_real = round(support[2] + 1.0);
    real_type n_y_real = round(support[3] + 1.0);
#endif

#if PROTOTYPE_COMPLIANT_INDEXING
    int n_x_support = (int) n_x_real - 1;
    int n_y_support = (int) n_y_real - 1;
//    // NOTE: Conforms to MATLAB prototype by not calculating topmost row and rightmost column.
//    int n_x_support = (int) n_x_real - 1 - 1;
//    int n_y_support = (int) n_y_real - 1 - 1;
#else
    // NOTE: Calculates topmost row and rightmost column.
    int n_x_support = (int) n_x_real - 1;
    int n_y_support = (int) n_y_real - 1;
#endif

    Print("n_x = %i, n_y = %i, center_x = %.15e, center_y = %.15e, n_x_real = %.15e, n_y_real = %.15e\n", n_x, n_y, center_x, center_y, n_x_real, n_y_real);

    real_type step;
    if (test_rotation_matrix_for_subsampling(rot_matrix))
        step = 0.25;
    else
        step = 1.0;

    //step = 0.25;  Print("DEBUG: WARNING: step is hardcoded to %.15e.\n", step);

    Print("step = %.15e\n", step);
//    exit(0);

    real_type sample_factor = step; // MATLAB prototype uses step for number of samples per pixel.
//    real_type sample_factor = step * step;
    //real_type sample_factor = 1.0 / (step * step); Print("DEBUG: WARNING: sample_factor is hardcoded to %.15e.\n", sample_factor);

    real_type rot_matrix00 = rot_matrix[0][0];
    real_type rot_matrix01 = rot_matrix[0][1];
    real_type rot_matrix10 = rot_matrix[1][0];
    real_type rot_matrix11 = rot_matrix[1][1];

#if PROTOTYPE_COMPLIANT_INDEXING
    for (real_type y0 = 1.0; y0 <= n0_y_real; y0 += step)
#else
    for (real_type y0 = 0.0; y0 <= n0_y_real; y0 += step)
#endif
    {
        int y0_floor = (int) floor(y0);
        real_type y0_alpha = y0 - (real_type) y0_floor;
#if PROTOTYPE_COMPLIANT_INDEXING
        --y0_floor;
#endif
        real_type y0_trans_y = y0 - center0_y;
        real_type y0_trans_y_rot_x = rot_matrix01 * y0_trans_y;
        real_type y0_trans_y_rot_y = rot_matrix11 * y0_trans_y;
        real_type y0_trans_y_rot_x_trans_x = y0_trans_y_rot_x + center_x;
        real_type y0_trans_y_rot_y_trans_y = y0_trans_y_rot_y + center_y;

#if PROTOTYPE_COMPLIANT_INDEXING
        for (real_type x0 = 1.0; x0 <= n0_x_real; x0 += step)
#else
        for (real_type x0 = 0.0; x0 <= n0_x_real; x0 += step)
#endif
        {
//            t_0 = clock();

            int x0_floor = (int) floor(x0);

            real_type x0_alpha = x0 - (real_type) x0_floor;

#if PROTOTYPE_COMPLIANT_INDEXING
            --x0_floor;
#endif

//            Print("x0_floor = %i\n", x0_floor);
//            Print("y0_floor = %i\n", y0_floor);

//            Print("x0_alpha = %.15e\n", x0_alpha);
//            Print("y0_alpha = %.15e\n", y0_alpha);

            // In order to avoid yet another boundary check, we have padded projection0.
            real_type v0 = INTERPOLATE_2(projection0_data, n0_x, x0_floor, y0_floor, x0_alpha, y0_alpha) * sample_factor;
//            real_type v0 = INDEX2D(projection0_data, n0_x, x0_floor, y0_floor) * sample_factor;

            //Print("v0 = %.15e\n", v0);

            real_type x0_trans = x0 - center0_x;

            real_type x = y0_trans_y_rot_x_trans_x + (rot_matrix00 * x0_trans);
            real_type y = y0_trans_y_rot_y_trans_y + (rot_matrix10 * x0_trans);

//            Print("x = %.15e\n", x);
//            Print("y = %.15e\n", y);

            int x_floor = (int) floor(x);
            int y_floor = (int) floor(y);

            real_type x_alpha = x - (real_type) x_floor;
            real_type y_alpha = y - (real_type) y_floor;

#if PROTOTYPE_COMPLIANT_INDEXING
            --x_floor;
            --y_floor;
#endif

//            t_1 = clock();
//            Print("%i %i\n", t_1, t_0);
//            Print("Pre-boundary-test delta t:%.15e\n", secs_per_clock * ((double) t_1 - (double) t_0));

//            t_0 = clock();

            // NOTE: We can get away with this because we know both IplImages are mode IPL_DEPTH_64F.
            pixel_type v = 0.0;

            if ((x_floor >= 0) && (x_floor <= n_x_support) && (y_floor >= 0) && (y_floor <= n_y_support))
            {
                v = INDEX2D(projection_data, n_x, x_floor, y_floor) + v0 * (1.0 - x_alpha) * (1.0 - y_alpha);
                PUTVAL2D(projection_data, n_x, x_floor, y_floor, v);
//                Print("(%i, %i) = %.15e\n", x_floor, y_floor, v);
            }
//            else
//            {
//                Print("(%i, %i)\n", x0_floor, y0_floor);
//                Print("(%i, %i)\n", x_floor, y_floor);
//            }

            if ((x_floor + 1 >= 0) && (x_floor + 1 <= n_x_support) && (y_floor >= 0) && (y_floor <= n_y_support))
            {
                v = INDEX2D(projection_data, n_x, x_floor + 1, y_floor) + v0 * x_alpha * (1.0 - y_alpha);
                PUTVAL2D(projection_data, n_x, x_floor + 1, y_floor, v);
//                Print("(%i, %i) = %.15e\n", x_floor + 1, y_floor, v);
            }
//            else
//            {
//                Print("(%i, %i)\n", x0_floor + 1, y0_floor);
//                Print("(%i, %i)\n", x_floor + 1, y_floor);
//            }

            if ((x_floor >= 0) && (x_floor <= n_x_support) && (y_floor + 1 >= 0) && (y_floor + 1 <= n_y_support))
            {
                v = INDEX2D(projection_data, n_x, x_floor, y_floor + 1) + v0 * (1.0 - x_alpha) * y_alpha;
                PUTVAL2D(projection_data, n_x, x_floor, y_floor + 1, v);
//                Print("(%i, %i) = %.15e\n", x_floor, y_floor + 1, v);
            }
//            else
//            {
//                Print("(%i, %i)\n", x0_floor, y0_floor + 1);
//                Print("(%i, %i)\n", x_floor, y_floor + 1);
//            }

            if ((x_floor + 1 >= 0) && (x_floor + 1 <= n_x_support) && (y_floor + 1 >= 0) && (y_floor + 1 <= n_y_support))
            {
                v = INDEX2D(projection_data, n_x, x_floor + 1, y_floor + 1) + v0 * x_alpha * y_alpha;
                PUTVAL2D(projection_data, n_x, x_floor + 1, y_floor + 1, v);
//                Print("(%i, %i) = %.15e\n", x_floor + 1, y_floor + 1, v);
            }
//            else
//            {
//                Print("(%i, %i)\n", x0_floor + 1, y0_floor + 1);
//                Print("(%i, %i)\n", x_floor + 1, y_floor + 1);
//            }

//            t_1 = clock();
//            Print("%i %i\n", t_1, t_0);
//            Print("Boundary test delta t:%.15e\n", secs_per_clock * ((double) t_1 - (double) t_0));
        }
    }
//    exit(0);
}

#endif

void transform_slice_cv
(
    Islice *slice0,
    real_type support0[4],
    real_type angle,
    Islice *slice,
    real_type support[4]
)
{
    real_type center0_x = round(support[0]);
    real_type center0_y = round(support[1]);

    CvPoint2D32f center0 = cvPoint2D32f(center0_x, center0_y); // WARNING: float vs. double -- cv2DRotationMatrix requires this.
    //CvPoint2D32f center0 = cvPoint2D32f(0.0, 0.0);

    angle *= (180.0 / M_PI); // cv2DRotationMatrix() uses degrees.
    angle *= -1.0; // Inverse map.

    Print("angle = %f\n", angle);

    CvMat *rot_matrix = cvCreateMat(2, 3, CVMAT_TYPE_REAL); // WARNING: float vs. double -- cv2DRotationMatrix requires CV_32FC1.
    cv2DRotationMatrix(center0, angle, 1.0, rot_matrix);

    Print("rot_matrix[0][0-2] = (%.15e, %.15e, %.15e)\n", rot_matrix->data.fl[0], rot_matrix->data.fl[1], rot_matrix->data.fl[2]);
    Print("rot_matrix[0][0-2] = (%.15e, %.15e, %.15e)\n", rot_matrix->data.fl[3], rot_matrix->data.fl[4], rot_matrix->data.fl[5]);

    IplImage *slice0_cv = create_IplImage_from_Islice_copy(slice0, IPL_DEPTH_REAL); // WARNING: float vs. double -- cvWarpAffine requires IPL_DEPTH_32F.
    IplImage *slice_cv = create_IplImage_from_Islice_copy(slice, IPL_DEPTH_REAL); // WARNING: float vs. double -- cvWarpAffine requires IPL_DEPTH_32F.

// WARNING: It appears only bilinear interpolation has been implemented for cvWarpAffine().
//    Print("CV_INTER_NN = %i, CV_INTER_LINEAR = %i, CV_INTER_CUBIC = %i\n", CV_INTER_NN, CV_INTER_LINEAR, CV_INTER_CUBIC);
//    Print("CV_WARP_FILL_OUTLIERS = %i, CV_WARP_INVERSE_MAP = %i\n", CV_WARP_FILL_OUTLIERS, CV_WARP_INVERSE_MAP);
    int cvWarpAffine_flags;
//    cvWarpAffine_flags = CV_INTER_NN | CV_WARP_FILL_OUTLIERS | CV_WARP_INVERSE_MAP;
//    Print("cvWarpAffine_flags = %i\n", cvWarpAffine_flags);
    cvWarpAffine_flags = CV_INTER_LINEAR | CV_WARP_FILL_OUTLIERS | CV_WARP_INVERSE_MAP;
//    Print("cvWarpAffine_flags = %i\n", cvWarpAffine_flags);
//    cvWarpAffine_flags = CV_INTER_CUBIC | CV_WARP_FILL_OUTLIERS | CV_WARP_INVERSE_MAP;
//    Print("cvWarpAffine_flags = %i\n", cvWarpAffine_flags);

    cvWarpAffine(slice0_cv, slice_cv, rot_matrix, cvWarpAffine_flags, cvScalarAll(0));
    copy_IplImage_to_Islice(slice_cv, slice);

    free_imageData_cvReleaseImageHeader(slice0_cv);
    free_imageData_cvReleaseImageHeader(slice_cv);
}

// NOTE: This pulls pixel values from the original slice to the new one.
void transform_slice_pull_nocv
(
    Islice *slice0,
    real_type support0[4], // This is required because original slice has been padded.
    real_type rot_matrix[2][2],
    Islice *slice,
    real_type support[4]
)
{
#if !PROTOTYPE_COMPLIANT_INDEXING
    static const char *function_name = "transform_slice_pull_nocv()";
#endif

//    clock_t t_0, t_1;
//    double secs_per_clock = 1.0 / CLOCKS_PER_SEC;

    float v_clear = 0.0;
    sliceClear(slice, &v_clear);

    float *slice0_data_f = slice0->data.f;
    int n0_x = slice0->xsize;
    int n0_y = slice0->ysize;

    real_type center0_x = support0[0];
    real_type center0_y = support0[1];
#if PROTOTYPE_COMPLIANT_INDEXING
    real_type n0_x_real = round(support0[2]);
    real_type n0_y_real = round(support0[3]);
#else
    real_type n0_x_real = round(support0[2] + 1.0);
    real_type n0_y_real = round(support0[3] + 1.0);
    Abort("ERROR %s -- !PROTOTYPE_COMPLIANT_INDEXING not implemented!\n", function_name);
#endif

    Print("n0_x = %i, n0_y = %i, center0_x = %.15e, center0_y = %.15e, n0_x_real = %.15e, n0_y_real = %.15e\n", n0_x, n0_y, center0_x, center0_y, n0_x_real, n0_y_real);

    float *slice_data_f = slice->data.f;
    int n_x = slice->xsize; // This is required because original slice has been padded.
    int n_y = slice->ysize; // This is required because original slice has been padded.

    real_type center_x = support[0];
    real_type center_y = support[1];
    real_type n_x_real = round(support[2]);
    real_type n_y_real = round(support[3]);

    Print("n_x = %i, n_y = %i, center_x = %.15e, center_y = %.15e, n_x_real = %.15e, n_y_real = %.15e\n", n_x, n_y, center_x, center_y, n_x_real, n_y_real);

    real_type step;
    if (test_rotation_matrix_for_subsampling(rot_matrix))
        step = 0.25;
    else
        step = 1.0;

    //step = 0.5;  Print("DEBUG: WARNING: step is hardcoded to %.15e.\n", step);

    Print("step = %.15e\n", step);
//    exit(0);

//    real_type sample_factor = step; // MATLAB prototype uses step for number of samples per pixel.
    real_type sample_factor = step * step;
    //real_type sample_factor = 1.0 / (step * step); Print("DEBUG: WARNING: sample_factor is hardcoded to %.15e.\n", sample_factor);

    // NOTE: Use the inverse rotation matrix.
    real_type rot_matrix00 = rot_matrix[0][0];
    real_type rot_matrix01 = rot_matrix[1][0];
    real_type rot_matrix10 = rot_matrix[0][1];
    real_type rot_matrix11 = rot_matrix[1][1];

    for (real_type x = 1.0; x < n_x_real; x += step)
    {
        int x_floor = (int) floor(x);
        real_type x_alpha = x - (real_type) x_floor;
        --x_floor;
        real_type x_trans_x = x - center_x;
        real_type x_trans_x_rot_x = rot_matrix00 * x_trans_x;
        real_type x_trans_x_rot_y = rot_matrix10 * x_trans_x;
        real_type x_trans_x_rot_x_trans_x = x_trans_x_rot_x + center0_x;
        real_type x_trans_x_rot_y_trans_y = x_trans_x_rot_y + center0_y;

        for (real_type y = 1.0; y < n_y_real; y += step)
        {
//            t_0 = clock();

            int y_floor = (int) floor(y);

            real_type y_alpha = y - (real_type) y_floor;

            --y_floor;

//            Print("x_floor = %i\n", x_floor);
//            Print("y_floor = %i\n", y_floor);

//            Print("x_alpha = %.15e\n", x_alpha);
//            Print("y_alpha = %.15e\n", y_alpha);

            // In order to avoid yet another boundary check, we have padded slice.
//            real_type v = INTERPOLATE_2(slice_data_f, n_x, x_floor, y_floor, x_alpha, y_alpha) * sample_factor;
//            real_type v = INDEX2D(slice_data_f, n_x, x_floor, y_floor) * sample_factor;
              real_type v = 0.0;

//            Print("v = %.15e\n", v);

            real_type y_trans = y - center_y;

            real_type x0 = x_trans_x_rot_x_trans_x + (rot_matrix01 * y_trans);
            real_type y0 = x_trans_x_rot_y_trans_y + (rot_matrix11 * y_trans);

//            Print("x0 = %.15e\n", x0);
//            Print("y0 = %.15e\n", y0);

            int x0_floor = (int) floor(x0);
            int y0_floor = (int) floor(y0);

            real_type x0_alpha = x0 - (real_type) x0_floor;
            real_type y0_alpha = y0 - (real_type) y0_floor;

            --x0_floor;
            --y0_floor;

//            t_1 = clock();
//            Print("%i %i\n", t_1, t_0);
//            Print("Pre-boundary-test delta t:%.15e\n", secs_per_clock * ((double) t_1 - (double) t_0));

//            t_0 = clock();

            // NOTE: We can get away with this because we know both Islices are mode SLICE_MODE_FLOAT.
            pixel_type v0 = 0.0;

            if ((x0_floor >= 0) && (x0_floor < n0_x) && (y0_floor >= 0) && (y0_floor < n0_y))
            //if ((x0_floor >= 0) && (x0_floor < n0_x - 1) && (y0_floor >= 0) && (y0_floor < n0_y - 1)) // NOTE: Conforms to MATLAB prototype.
            {
                v0 = INDEX2D(slice0_data_f, n0_x, x0_floor, y0_floor) * (1.0 - x0_alpha) * (1.0 - y0_alpha);
                v += v0;
//                Print("(%i, %i) = %.15e\n", x0_floor, y0_floor, v0);
            }
//            else
//            {
//                Print("(%i, %i)\n", x_floor, y_floor);
//                Print("(%i, %i)\n", x0_floor, y0_floor);
//            }

            if ((x0_floor + 1 >= 0) && (x0_floor + 1 < n0_x) && (y0_floor >= 0) && (y0_floor < n0_y))
            //if ((x0_floor + 1 >= 0) && (x0_floor + 1 < n0_x - 1) && (y0_floor >= 0) && (y0_floor < n0_y - 1)) // NOTE: Conforms to MATLAB prototype.
            {
                v0 = INDEX2D(slice0_data_f, n0_x, x0_floor + 1, y0_floor) * x0_alpha * (1.0 - y0_alpha);
                v += v0;
//                Print("(%i, %i) = %.15e\n", x0_floor + 1, y0_floor, v0);
            }
//            else
//            {
//                Print("(%i, %i)\n", x_floor + 1, y_floor);
//                Print("(%i, %i)\n", x0_floor + 1, y0_floor);
//            }

            if ((x0_floor >= 0) && (x0_floor < n0_x) && (y0_floor + 1 >= 0) && (y0_floor + 1 < n0_y))
            //if ((x0_floor >= 0) && (x0_floor < n0_x - 1) && (y0_floor + 1 >= 0) && (y0_floor + 1 < n0_y - 1)) // NOTE: Conforms to MATLAB prototype.
            {
                v0 = INDEX2D(slice0_data_f, n0_x, x0_floor, y0_floor + 1) * (1.0 - x0_alpha) * y0_alpha;
                v += v0;
//                Print("(%i, %i) = %.15e\n", x0_floor, y0_floor + 1, v0);
            }
//            else
//            {
//                Print("(%i, %i)\n", x_floor, y_floor + 1);
//                Print("(%i, %i)\n", x0_floor, y0_floor + 1);
//            }

            if ((x0_floor + 1 >= 0) && (x0_floor + 1 < n0_x) && (y0_floor + 1 >= 0) && (y0_floor + 1 < n0_y))
            //if ((x0_floor + 1 >= 0) && (x0_floor + 1 < n0_x - 1) && (y0_floor + 1 >= 0) && (y0_floor + 1 < n0_y - 1)) // NOTE: Conforms to MATLAB prototype.
            {
                v0 = INDEX2D(slice0_data_f, n0_x, x0_floor + 1, y0_floor + 1) * x0_alpha * y0_alpha;
                v += v0;
//                Print("(%i, %i) = %.15e\n", x0_floor + 1, y0_floor + 1, v0);
            }
//            else
//            {
//                Print("(%i, %i)\n", x_floor + 1, y_floor + 1);
//                Print("(%i, %i)\n", x0_floor + 1, y0_floor + 1);
//            }

            v *= sample_factor;

//            t_1 = clock();
//            Print("%i %i\n", t_1, t_0);
//            Print("Boundary test delta t:%.15e\n", secs_per_clock * ((double) t_1 - (double) t_0));

//            PUTVAL2D(slice_data_f, n_x, x_floor, y_floor, v * (1.0 - x_alpha) * (1.0 - y_alpha) * sample_factor);
//            PUTVAL2D(slice_data_f, n_x, x_floor + 1, y_floor, v * x_alpha * (1.0 - y_alpha) * sample_factor);
//            PUTVAL2D(slice_data_f, n_x, x_floor, y_floor + 1, v * (1.0 - x_alpha) * y_alpha * sample_factor);
//            PUTVAL2D(slice_data_f, n_x, x_floor + 1, y_floor + 1, v * x_alpha * y_alpha * sample_factor);
            ADDVAL2D(slice_data_f, n_x, x_floor, y_floor, v * (1.0 - x_alpha) * (1.0 - y_alpha));
            ADDVAL2D(slice_data_f, n_x, x_floor + 1, y_floor, v * x_alpha * (1.0 - y_alpha));
            ADDVAL2D(slice_data_f, n_x, x_floor, y_floor + 1, v * (1.0 - x_alpha) * y_alpha);
            ADDVAL2D(slice_data_f, n_x, x_floor + 1, y_floor + 1, v * x_alpha * y_alpha);
        }
    }
    //exit(0);
}

// NOTE: This pushes pixel values from the original slice to the new one.  This is fine with rotations.
void transform_slice_push_nocv
(
    Islice *slice0,
    real_type support0[4], // This is required because original slice has been padded.
    real_type rot_matrix[2][2],
    Islice *slice,
    real_type support[4]
)
{
//    clock_t t_0, t_1;
//    double secs_per_clock = 1.0 / CLOCKS_PER_SEC;

    float v_clear = 0.0;
    sliceClear(slice, &v_clear);

    float *slice0_data_f = slice0->data.f;
    int n0_x = slice0->xsize; // This is required because original slice has been padded.
    int n0_y = slice0->ysize; // Unnecessary.

    real_type center0_x = support0[0];
    real_type center0_y = support0[1];
#if PROTOTYPE_COMPLIANT_INDEXING
    real_type n0_x_real = round(support0[2]);
    real_type n0_y_real = round(support0[3]);
#else
    real_type n0_x_real = round(support0[2] + 1.0);
    real_type n0_y_real = round(support0[3] + 1.0);
#endif

    Print("n0_x = %i, n0_y = %i, center0_x = %.15e, center0_y = %.15e, n0_x_real = %.15e, n0_y_real = %.15e\n", n0_x, n0_y, center0_x, center0_y, n0_x_real, n0_y_real);

    float *slice_data_f = slice->data.f;
    int n_x = slice->xsize;
    int n_y = slice->ysize;

    real_type center_x = support[0];
    real_type center_y = support[1];
#if PROTOTYPE_COMPLIANT_INDEXING
    real_type n_x_real = round(support[2]); // Unnecessary?
    real_type n_y_real = round(support[3]); // Unnecessary?
#else
    real_type n_x_real = round(support[2] + 1.0); // Unnecessary?
    real_type n_y_real = round(support[3] + 1.0); // Unnecessary?
#endif

    Print("n_x = %i, n_y = %i, center_x = %.15e, center_y = %.15e, n_x_real = %.15e, n_y_real = %.15e\n", n_x, n_y, center_x, center_y, n_x_real, n_y_real);

    real_type step;
    if (test_rotation_matrix_for_subsampling(rot_matrix))
        step = 0.25;
    else
        step = 1.0;

    //step = 0.25;  Print("DEBUG: WARNING: step is hardcoded to %.15e.\n", step);

    Print("step = %.15e\n", step);
//    exit(0);

    real_type sample_factor = step; // MATLAB prototype uses step for number of samples per pixel.
//    real_type sample_factor = step * step;
    //real_type sample_factor = 1.0 / (step * step); Print("DEBUG: WARNING: sample_factor is hardcoded to %.15e.\n", sample_factor);

    real_type rot_matrix00 = rot_matrix[0][0];
    real_type rot_matrix01 = rot_matrix[0][1];
    real_type rot_matrix10 = rot_matrix[1][0];
    real_type rot_matrix11 = rot_matrix[1][1];

#if PROTOTYPE_COMPLIANT_INDEXING
    for (real_type x0 = 1.0; x0 <= n0_x_real; x0 += step)
#else
    for (real_type x0 = 0.0; x0 < n0_x_real; x0 += step)
#endif
    {
        int x0_floor = (int) floor(x0);
        real_type x0_alpha = x0 - (real_type) x0_floor;
#if PROTOTYPE_COMPLIANT_INDEXING
        --x0_floor;
#endif
        real_type x0_trans_x = x0 - center0_x;
        real_type x0_trans_x_rot_x = rot_matrix00 * x0_trans_x;
        real_type x0_trans_x_rot_y = rot_matrix10 * x0_trans_x;
        real_type x0_trans_x_rot_x_trans_x = x0_trans_x_rot_x + center_x;
        real_type x0_trans_x_rot_y_trans_y = x0_trans_x_rot_y + center_y;

#if PROTOTYPE_COMPLIANT_INDEXING
        for (real_type y0 = 1.0; y0 <= n0_y_real; y0 += step)
#else
        for (real_type y0 = 0.0; y0 < n0_y_real; y0 += step)
#endif
        {
//            t_0 = clock();

            int y0_floor = (int) floor(y0);

            real_type y0_alpha = y0 - (real_type) y0_floor;

#if PROTOTYPE_COMPLIANT_INDEXING
            --y0_floor;
#endif

//            Print("x0_floor = %i\n", x0_floor);
//            Print("y0_floor = %i\n", y0_floor);

//            Print("x0_alpha = %.15e\n", x0_alpha);
//            Print("y0_alpha = %.15e\n", y0_alpha);

            // In order to avoid yet another boundary check, we have padded slice0.
            real_type v0 = INTERPOLATE_2(slice0_data_f, n0_x, x0_floor, y0_floor, x0_alpha, y0_alpha) * sample_factor;
//            real_type v0 = INDEX2D(slice0_data_f, n0_x, x0_floor, y0_floor) * sample_factor;

            //Print("v0 = %.15e\n", v0);

            real_type y0_trans = y0 - center0_y;

            real_type x = x0_trans_x_rot_x_trans_x + (rot_matrix01 * y0_trans);
            real_type y = x0_trans_x_rot_y_trans_y + (rot_matrix11 * y0_trans);

//            Print("x = %.15e\n", x);
//            Print("y = %.15e\n", y);

            int x_floor = (int) floor(x);
            int y_floor = (int) floor(y);

            real_type x_alpha = x - (real_type) x_floor;
            real_type y_alpha = y - (real_type) y_floor;

#if PROTOTYPE_COMPLIANT_INDEXING
            --x_floor;
            --y_floor;
#endif

//            t_1 = clock();
//            Print("%i %i\n", t_1, t_0);
//            Print("Pre-boundary-test delta t:%.15e\n", secs_per_clock * ((double) t_1 - (double) t_0));

//            t_0 = clock();

            // NOTE: We can get away with this because we know both Islices are mode SLICE_MODE_FLOAT.
            pixel_type v = 0.0;

#if PROTOTYPE_COMPLIANT_INDEXING
            if ((x_floor >= 0) && (x_floor < n_x - 1) && (y_floor >= 0) && (y_floor < n_y - 1)) // NOTE: Conforms to MATLAB prototype.
#else
            if ((x_floor >= 0) && (x_floor < n_x) && (y_floor >= 0) && (y_floor < n_y))
#endif
            {
                v = INDEX2D(slice_data_f, n_x, x_floor, y_floor) + v0 * (1.0 - x_alpha) * (1.0 - y_alpha);
                PUTVAL2D(slice_data_f, n_x, x_floor, y_floor, v);
//                Print("(%i, %i) = %.15e\n", x_floor, y_floor, v);
            }
//            else
//            {
//                Print("(%i, %i)\n", x0_floor, y0_floor);
//                Print("(%i, %i)\n", x_floor, y_floor);
//            }

#if PROTOTYPE_COMPLIANT_INDEXING
            if ((x_floor + 1 >= 0) && (x_floor + 1 < n_x - 1) && (y_floor >= 0) && (y_floor < n_y - 1)) // NOTE: Conforms to MATLAB prototype.
#else
            if ((x_floor + 1 >= 0) && (x_floor + 1 < n_x) && (y_floor >= 0) && (y_floor < n_y))
#endif
            {
                v = INDEX2D(slice_data_f, n_x, x_floor + 1, y_floor) + v0 * x_alpha * (1.0 - y_alpha);
                PUTVAL2D(slice_data_f, n_x, x_floor + 1, y_floor, v);
//                Print("(%i, %i) = %.15e\n", x_floor + 1, y_floor, v);
            }
//            else
//            {
//                Print("(%i, %i)\n", x0_floor + 1, y0_floor);
//                Print("(%i, %i)\n", x_floor + 1, y_floor);
//            }

#if PROTOTYPE_COMPLIANT_INDEXING
            if ((x_floor >= 0) && (x_floor < n_x - 1) && (y_floor + 1 >= 0) && (y_floor + 1 < n_y - 1)) // NOTE: Conforms to MATLAB prototype.
#else
            if ((x_floor >= 0) && (x_floor < n_x) && (y_floor + 1 >= 0) && (y_floor + 1 < n_y))
#endif
            {
                v = INDEX2D(slice_data_f, n_x, x_floor, y_floor + 1) + v0 * (1.0 - x_alpha) * y_alpha;
                PUTVAL2D(slice_data_f, n_x, x_floor, y_floor + 1, v);
//                Print("(%i, %i) = %.15e\n", x_floor, y_floor + 1, v);
            }
//            else
//            {
//                Print("(%i, %i)\n", x0_floor, y0_floor + 1);
//                Print("(%i, %i)\n", x_floor, y_floor + 1);
//            }

#if PROTOTYPE_COMPLIANT_INDEXING
            if ((x_floor + 1 >= 0) && (x_floor + 1 < n_x - 1) && (y_floor + 1 >= 0) && (y_floor + 1 < n_y - 1)) // NOTE: Conforms to MATLAB prototype.
#else
            if ((x_floor + 1 >= 0) && (x_floor + 1 < n_x) && (y_floor + 1 >= 0) && (y_floor + 1 < n_y))
#endif
            {
                v = INDEX2D(slice_data_f, n_x, x_floor + 1, y_floor + 1) + v0 * x_alpha * y_alpha;
                PUTVAL2D(slice_data_f, n_x, x_floor + 1, y_floor + 1, v);
//                Print("(%i, %i) = %.15e\n", x_floor + 1, y_floor + 1, v);
            }
//            else
//            {
//                Print("(%i, %i)\n", x0_floor + 1, y0_floor + 1);
//                Print("(%i, %i)\n", x_floor + 1, y_floor + 1);
//            }

//            t_1 = clock();
//            Print("%i %i\n", t_1, t_0);
//            Print("Boundary test delta t:%.15e\n", secs_per_clock * ((double) t_1 - (double) t_0));
        }
    }
//    exit(0);
}

////////////////////////////////////////////////////////////////////////////////
// END: Transforms.
////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////
// BEGIN: Misc.
////////////////////////////////////////////////////////////////////////////////

void calc_transformed_support_corners
(
    real_type rot_matrix[2][2],
    real_type support[4],
    real_type corners[4][2] // Image coordinates of rotated corners.
)
{
    Print("support[0-3] = (%.15e, %.15e, %.15e, %.15e)\n", support[0], support[1], support[2], support[3]);

    //real_type center0_x = support[0];
    //real_type center0_y = support[1];

#if PROTOTYPE_COMPLIANT_INDEXING
    real_type half0_x = support[2] / 2.0; // WARNING: Expands support by 0.5 on each side.
    real_type half0_y = support[3] / 2.0; // WARNING: Expands support by 0.5 on each side.
#else
    real_type half0_x = (support[2] + 1.0) / 2.0; // WARNING: Expands support by 0.5 on each side.
    real_type half0_y = (support[3] + 1.0) / 2.0; // WARNING: Expands support by 0.5 on each side.
//    real_type half0_x = support[2] / 2.0;
//    real_type half0_y = support[3] / 2.0;
#endif

    // p[1-4][2], four corners of the support in projection coordinates
    real_type p0[4][2]; 

    p0[0][0] = -half0_x; p0[0][1] = -half0_y; 
    p0[1][0] = half0_x; p0[1][1] = -half0_y;
    p0[2][0] = -half0_x; p0[2][1] = half0_y;
    p0[3][0] = half0_x; p0[3][1] = half0_y;

    Print("p0[1-4][0-1] = (%.15e, %.15e), (%.15e, %.15e), (%.15e, %.15e), (%.15e, %.15e)\n",
        p0[0][0], p0[0][1], p0[1][0], p0[1][1], p0[2][0], p0[2][1], p0[3][0], p0[3][1]);

    // p[1-4][2], four rotated corners of the support in projection coordinates
    real_type p[4][2]; 

/*  
    // BEGIN: Complies with MATLAB prototype.
    p[0][0] = (rot_matrix[0][0] * p0[0][0]) + (rot_matrix[0][1] * p0[0][1]) + center0_x;
    p[0][1] = (rot_matrix[1][0] * p0[0][0]) + (rot_matrix[1][1] * p0[0][1]) + center0_y;

    p[1][0] = (rot_matrix[0][0] * p0[1][0]) + (rot_matrix[0][1] * p0[1][1]) + center0_x;
    p[1][1] = (rot_matrix[1][0] * p0[1][0]) + (rot_matrix[1][1] * p0[1][1]) + center0_y;

    p[2][0] = (rot_matrix[0][0] * p0[2][0]) + (rot_matrix[0][1] * p0[2][1]) + center0_x;
    p[2][1] = (rot_matrix[1][0] * p0[2][0]) + (rot_matrix[1][1] * p0[2][1]) + center0_y;

    p[3][0] = (rot_matrix[0][0] * p0[3][0]) + (rot_matrix[0][1] * p0[3][1]) + center0_x;
    p[3][1] = (rot_matrix[1][0] * p0[3][0]) + (rot_matrix[1][1] * p0[3][1]) + center0_y;
    // END: Complies with MATLAB prototype.
*/

    p[0][0] = (rot_matrix[0][0] * p0[0][0]) + (rot_matrix[0][1] * p0[0][1]);
    p[0][1] = (rot_matrix[1][0] * p0[0][0]) + (rot_matrix[1][1] * p0[0][1]);

    p[1][0] = (rot_matrix[0][0] * p0[1][0]) + (rot_matrix[0][1] * p0[1][1]);
    p[1][1] = (rot_matrix[1][0] * p0[1][0]) + (rot_matrix[1][1] * p0[1][1]);

    p[2][0] = (rot_matrix[0][0] * p0[2][0]) + (rot_matrix[0][1] * p0[2][1]);
    p[2][1] = (rot_matrix[1][0] * p0[2][0]) + (rot_matrix[1][1] * p0[2][1]);

    p[3][0] = (rot_matrix[0][0] * p0[3][0]) + (rot_matrix[0][1] * p0[3][1]);
    p[3][1] = (rot_matrix[1][0] * p0[3][0]) + (rot_matrix[1][1] * p0[3][1]);

    Print("p[1-4][0-1] = (%.15e, %.15e), (%.15e, %.15e), (%.15e, %.15e), (%.15e, %.15e)\n",
        p[0][0], p[0][1], p[1][0], p[1][1], p[2][0], p[2][1], p[3][0], p[3][1]);

    // BEGIN: Build a bounding rectangle.

    real_type x_min = p[0][0];
    x_min = TXBR_MIN(x_min, p[1][0]);
    x_min = TXBR_MIN(x_min, p[2][0]);
    x_min = TXBR_MIN(x_min, p[3][0]);

    real_type x_max = p[0][0];
    x_max = TXBR_MAX(x_max, p[1][0]);
    x_max = TXBR_MAX(x_max, p[2][0]);
    x_max = TXBR_MAX(x_max, p[3][0]);

    real_type y_min = p[0][1];
    y_min = TXBR_MIN(y_min, p[1][1]);
    y_min = TXBR_MIN(y_min, p[2][1]);
    y_min = TXBR_MIN(y_min, p[3][1]);

    real_type y_max = p[0][1];
    y_max = TXBR_MAX(y_max, p[1][1]);
    y_max = TXBR_MAX(y_max, p[2][1]);
    y_max = TXBR_MAX(y_max, p[3][1]);

    // END: Build a bounding rectangle.

#if PROTOTYPE_COMPLIANT_INDEXING
    support[0] = (x_max - x_min + 1.0) / 2.0;
    support[1] = (y_max - y_min + 1.0) / 2.0;
    support[2] = x_max - x_min + 1.0; // WARNING: Expands support by an additional 0.5 on each side.
    support[3] = y_max - y_min + 1.0; // WARNING: Expands support by an additional 0.5 on each side.
#else
    support[0] = (x_max - x_min) / 2.0;
    support[1] = (y_max - y_min) / 2.0;
    //support[0] = (x_max - x_min - 1.0) / 2.0; // NOTE: This doesn't look right, but it removes the discrepancy for the IPLIMAGE_PUSH versions.
    //support[1] = (y_max - y_min - 1.0) / 2.0; // NOTE: This doesn't look right, but it removes the discrepancy for the IPLIMAGE_PUSH versions.
    support[2] = x_max - x_min;
    support[3] = y_max - y_min;
    //support[2] = x_max - x_min + 1.0; // WARNING: Expands support by an additional 0.5 on each side.
    //support[3] = y_max - y_min + 1.0; // WARNING: Expands support by an additional 0.5 on each side.
#endif

    real_type half_x = support[2] / 2.0;
    real_type half_y = support[3] / 2.0;

    real_type center_trans[2] = { half_x - half0_x, half_y - half0_y };

    p[0][0] += center_trans[0]; 
    p[0][1] += center_trans[1];

    p[1][0] += center_trans[0];
    p[1][1] += center_trans[1];

    p[2][0] += center_trans[0];
    p[2][1] += center_trans[1];

    p[3][0] += center_trans[0];
    p[3][1] += center_trans[1];

    memcpy(corners, p, sizeof(real_type) * 4 * 2);

//    Print("p[1-4][0-1] = (%.15e, %.15e), (%.15e, %.15e), (%.15e, %.15e), (%.15e, %.15e)\n",
//        p[0][0], p[0][1], p[1][0], p[1][1], p[2][0], p[2][1], p[3][0], p[3][1]);

    Print("support[0-3] = (%.15e, %.15e, %.15e, %.15e)\n", support[0], support[1], support[2], support[3]);
}

void calc_transformed_support(real_type rot_matrix[2][2], real_type support[4])
{
    real_type corners[4][2];
    calc_transformed_support_corners(rot_matrix, support, corners);
}

void slice_resize_copy_cv
(
    Islice *slice0,
    Islice *slice,
    real_type resize_factor
)
{
    static const char *function_name = "slice_resize_copy_cv()";

    if (slice0 == slice)
        Abort("ERROR: %s -- slice0 == slice.\n", function_name);

//    if ((slice->xsize != round((real_type) slice0->xsize * resize_factor)) || (slice->ysize != round((real_type) slice0->ysize * resize_factor)))
//        Abort("ERROR: %s -- slice0->(xsize, ysize) = (%i, %i), slice->(xsize, ysize) = (%i, %i), but resize_factor = %.15e.\n",
//            function_name, slice0->xsize, slice0->ysize, slice->xsize, slice->ysize, resize_factor);

    IplImage *slice0_cv = create_IplImage_from_Islice_copy(slice0, IPL_DEPTH_REAL); // WARNING: float vs. double -- cvResize() requires IPL_DEPTH_32F.
    IplImage *slice_cv = create_IplImage_from_Islice_copy(slice, IPL_DEPTH_REAL); // WARNING: float vs. double -- cvResize() requires IPL_DEPTH_32F.

    cvResize(slice0_cv, slice_cv, CV_INTER_CUBIC);
    copy_IplImage_to_Islice(slice_cv, slice);

    free_imageData_cvReleaseImageHeader(slice0_cv);
    free_imageData_cvReleaseImageHeader(slice_cv);
}

void slice_resize_copy
(
    Islice *slice0,
    Islice *slice,
    real_type resize_factor
)
{
    slice_resize_copy_cv(slice0, slice, resize_factor);
}

// If slice0 extent < slice extent, excess slice is filled with zeros.
// If slice0 extent > slice extent, slice is a crop of slice0.
// NOTE: Assumes SLICE_MODE_FLOAT.
void slice_recanvas_center_copy
(
    Islice *slice0,
    Islice *slice
)
{
    static const char *function_name = "slice_recanvas_center_copy()";

    if (slice0 == slice)
        Abort("ERROR: %s -- slice0 == slice.\n", function_name);

    float *slice0_data_f = slice0->data.f;
    int n0_x = slice0->xsize;
    int n0_y = slice0->ysize;

    float *slice_data_f = slice->data.f;
    int n_x = slice->xsize;
    int n_y = slice->ysize;

    if ((n0_x < n_x) || (n0_y < n_y))
    {
        float v_clear = 0.0;
        sliceClear(slice, &v_clear);
    }

    center_copy_params_type params = calc_center_copy_params(n0_x, n0_y, n_x, n_y);

    pixel_type v = 0.0;

    int i_y = params.i_y_start;
    for (int i0_y = params.i0_y_start; i0_y < params.i0_y_stop; ++i0_y)
    {
        int i_x = params.i_x_start;
        for (int i0_x = params.i0_x_start; i0_x < params.i0_x_stop; ++i0_x)
        {
            //Print("(i0_x, i0_y) = (%i, %i)\n", i0_x, i0_y);
            //Print("(i_x, i_y) = (%i, %i)\n", i_x, i_y);

            v = INDEX2D(slice0_data_f, n0_x, i0_x, i0_y);
            PUTVAL2D(slice_data_f, n_x, i_x, i_y, v);
            ++i_x;
        }
        ++i_y;
    }
}

// If slice0 extent < slice extent, excess slice (i.e., right and/or top) is filled with zeros.
// If slice0 extent > slice extent, slice is a crop (i.e., right and/or top) of slice0.
// NOTE: Assumes SLICE_MODE_FLOAT.
void slice_recanvas_copy
(
    Islice *slice0,
    Islice *slice
)
{
    static const char *function_name = "slice_recanvas_copy()";

    if (slice0 == slice)
        Abort("ERROR: %s -- slice0 == slice.\n", function_name);

    float *slice0_data_f = slice0->data.f;
    int n0_x = slice0->xsize;
    int n0_y = slice0->ysize;

    float *slice_data_f = slice->data.f;
    int n_x = slice->xsize;
    int n_y = slice->ysize;

    if ((n0_x < n_x) || (n0_y < n_y))
    {
        float v_clear = 0.0;
        sliceClear(slice, &v_clear);
    }

    int i0_x_stop = TXBR_MIN(n0_x, n_x);
    int i0_y_stop = TXBR_MIN(n0_y, n_y);

    pixel_type v = 0.0;

    for (int i0_y = 0; i0_y < i0_y_stop; ++i0_y)
        for (int i0_x = 0; i0_x < i0_x_stop; ++i0_x)
        {
            v = INDEX2D(slice0_data_f, n0_x, i0_x, i0_y);
            PUTVAL2D(slice_data_f, n_x, i0_x, i0_y, v);
        }

    //for (int i_x = 0; i_x < n_x; ++i_x)
    //    Print("%.15e\n", INDEX2D(slice_data_f, n_x, i_x, n_y - 1));
    //exit(0);
}

////////////////////////////////////////////////////////////////////////////////
// END: Misc.
////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////
// BEGIN: projection_series_filter_1D().
////////////////////////////////////////////////////////////////////////////////

#define PROJECTION_SERIES_FILTER_1D_CV_IPLIMAGE_PULL
//#define PROJECTION_SERIES_FILTER_1D_CV_IPLIMAGE_PUSH
//#define PROJECTION_SERIES_FILTER_1D_CV_CV_ISLICE_PUSH

#if defined PROJECTION_SERIES_FILTER_1D_CV_IPLIMAGE_PULL

// NOTE: New version.  Uses IplImage for workspace.  Pulls w/out index check.
void projection_series_filter_1D_cv
//void projection_series_filter_1D
(
    const char *filepath_in, 
    const char *filepath_out,
    transform_params_type *transform_params,
    filter_1D_params_type *filter_1D_params
) 
{
    static const char *function_name = "projection_series_filter_1D_cv()";

#if PROTOTYPE_COMPLIANT_INDEXING
    Abort("ERROR %s -- PROTOTYPE_COMPLIANT_INDEXING not implemented!\n", function_name);
#endif

    Print("filepath_in = \"%s\"\n", filepath_in);
    Print("filepath_out = \"%s\"\n", filepath_out);

    Print("transform_params->angle = %f\n", transform_params->angle);
    print_matrix2x2("transform_params->rot_matrix", transform_params->rot_matrix);
    print_matrix2x2("transform_params->inv_rot_matrix", transform_params->inv_rot_matrix);

    Print("filter_1D_params->type = %i\n", filter_1D_params->type);
    Print("filter_1D_params->length_rs (original) = %i\n", filter_1D_params->length_rs);
    Print("filter_1D_params->length_fs = %i\n", filter_1D_params->length_fs); // Should be 0.
    Print("filter_1D_params->cut_off = %f\n", filter_1D_params->cut_off);
    Print("filter_1D_params->roll_off = %f\n", filter_1D_params->roll_off);

    clock_t t_0_total, t_1_total;
    clock_t t_0, t_1;

    double secs_per_clock = 1.0 / (double) CLOCKS_PER_SEC;

    t_0_total = clock();

    // BEGIN: Open input MRC file.
    MrcHeader file_header_in;

    FILE *file_in = NULL;

    openMRCFile_general(filepath_in, &file_header_in, &file_in);
    // END: Open input MRC file.

    int n0_x = file_header_in.nx;
    int n0_y = file_header_in.ny;
    int n_tilts = file_header_in.nz;
    int mode = file_header_in.mode;

    // BEGIN: Create and open output MRC file.
    // BEGIN: Create output MRC file.
    if (mode != SLICE_MODE_FLOAT)
        Print("WARNING: Input mode == %i but using mode SLICE_MODE_FLOAT == %i for output!\n", mode, SLICE_MODE_FLOAT);

    MrcHeader file_header_out;

    FILE *file_out = NULL;

    createNewMRCFile(filepath_out, n0_x, n0_y, n_tilts, /*mode*/ SLICE_MODE_FLOAT);
    // END: Create output MRC file.

    // BEGIN: Open output MRC file.
    openMRCFile_general(filepath_out, &file_header_out, &file_out);
    // END: Open output MRC file.
    // END: Create and open output MRC file.

    real_type support0[4];
    support0[0] = ((real_type) n0_x - 1.0) / 2.0; // y-coordinate of projection center
    support0[1] = ((real_type) n0_y - 1.0) / 2.0; // y-coordinate of projection center
    support0[2] = (real_type) n0_x - 1.0; // max x-coordinate of projection
    support0[3] = (real_type) n0_y - 1.0; // max y-coordinate of projection

    real_type support[4];
    support[0] = support0[0]; // x-coordinate of transformed projection center
    support[1] = support0[1]; // y-coordinate of transformed projection center
    support[2] = support0[2]; // max x-coordinate of transformed projection
    support[3] = support0[3]; // max y-coordinate of transformed projection

    // NOTE: I think the transform should be the same as that used to transform the original projection, but cf. the MATLAB prototype.
    calc_transformed_support(transform_params->rot_matrix, support);
    //calc_transformed_support(transform_params->inv_rot_matrix, support);

    real_type support00[4];
    support00[0] = support[0]; // x-coordinate of untransformed projection center
    support00[1] = support[1]; // y-coordinate of untransformed projection center
    support00[2] = support[2]; // max x-coordinate of untransformed projection
    support00[3] = support[3]; // max y-coordinate of untransformed projection

    // NOTE: I think the transform should be the same as that used to transform the transformed projection, but cf. the MATLAB prototype.
    calc_transformed_support(transform_params->inv_rot_matrix, support00);
    //calc_transformed_support(transform_params->rot_matrix, support00);

    int n_x = round(support[2] + 1.0);
    int n_y = round(support[3] + 1.0);
    int n00_x = round(support00[2] + 1.0);
    int n00_y = round(support00[3] + 1.0);

    int row_pad = 1;
    int col_pad = 1;

    int n00_x_padded = n00_x + row_pad;
    int n00_y_padded = n00_y + col_pad;
    if ((n0_x % 2) != (n00_x_padded % 2)) ++n00_x_padded;
    if ((n0_y % 2) != (n00_y_padded % 2)) ++n00_y_padded;

    int n_x_padded = n_x + row_pad;
    int n_y_padded = n_y + col_pad;
    if ((n00_x_padded % 2) != (n_x_padded % 2)) ++n_x_padded;
    if ((n00_y_padded % 2) != (n_y_padded % 2)) ++n_y_padded;

    // Calculate filter.
    filter_1D_data_type *filter_data = create_filter_1D_data_n_xy(filter_1D_params, n_x_padded, n_y_padded);

    IplImage *projection00 = create_IplImage_SetZero(n00_x_padded, n00_y_padded, IPL_DEPTH_REAL); // NOTE: Used for both original projection and untransformed filtered transformed projection.
    IplImage *projection = create_IplImage_SetZero(n_x_padded, n_y_padded, IPL_DEPTH_REAL); // NOTE: Used for both transformed projection and filtered transformed projection.

    for (int i_tilt = 0; i_tilt < n_tilts; i_tilt++)
    {
        Print("i_tilt = %i\n", i_tilt);

        // Reuse slice later to transfer data back to the MRC file.
        Islice *slice = NULL;
        slice = sliceReadMRC(&file_header_in, i_tilt, 'z');
        if (slice == NULL)
            Abort("ERROR: %s -- Cannot read file: \"%s\".\n", function_name, filepath_in);

        // NOTE: Output floating-point data.
        if (slice->mode != SLICE_MODE_FLOAT)
            sliceNewMode(slice, SLICE_MODE_FLOAT);

        copy_Islice_to_IplImage_center(slice, projection00);

        //write_MRC_image_from_IplImage(projection00, "/home/akulo/filter_1D_images/projection00.mrc");

        t_0 = clock();

        // NOTE: inv_rot_matrix to conform to MATLAB prototype.
        transform_projection(projection00, support00, transform_params->inv_rot_matrix, projection, support);

        //write_MRC_image_from_IplImage(projection, "/home/akulo/filter_1D_images/projection.mrc");

        t_1 = clock();
        Print("Transform delta t:%.15e\n", secs_per_clock * ((double) t_1 - (double) t_0));

        t_0 = clock();

        projection_filter_1D_fs(projection, filter_data);

        //write_MRC_image_from_IplImage(projection, "/home/akulo/filter_1D_images/projection.filtered.mrc");

        t_1 = clock();
        Print("Filtering delta t:%.15e\n", secs_per_clock * ((double) t_1 - (double) t_0));

        t_0 = clock();

        // NOTE: rot_matrix to conform to MATLAB prototype.
        transform_projection(projection, support, transform_params->rot_matrix, projection00, support0);

        t_1 = clock();
        Print("Inv. transform delta t:%.15e\n", secs_per_clock * ((double) t_1 - (double) t_0));

        //write_MRC_image_from_IplImage(projection00, "/home/akulo/filter_1D_images/projection00.filtered.mrc");

        copy_IplImage_to_Islice_center(projection00, slice);

        sliceWriteMRC(&file_header_out, slice, i_tilt, 'z');
        sliceFree(slice);

#ifdef MEX
        mexEvalString("fprintf('Done processing projection.\\n');");
#endif
    }

    calc_mmm_of_MRC(&file_header_out);

    // Free resources.

    cvReleaseImage(&projection00);
    cvReleaseImage(&projection);

    filter_1D_data_release(filter_data);

    if(fclose(file_in))
        Abort("ERROR: %s -- Cannot close input file: \"%s\".\n", function_name, filepath_in);

    if(fclose(file_out))
        Abort("ERROR: %s -- Cannot close output file \"%s\".\n", function_name, filepath_out);

    t_1_total = clock();
 
    Print("Total duration: %.15e\n", secs_per_clock * ((double) t_1_total - (double) t_0_total));
}

#elif defined PROJECTION_SERIES_FILTER_1D_CV_IPLIMAGE_PUSH

// NOTE: Uses IplImage for workspace.
void projection_series_filter_1D_cv
//void projection_series_filter_1D
(
    const char *filepath_in, 
    const char *filepath_out,
    transform_params_type *transform_params,
    filter_1D_params_type *filter_1D_params
) 
{
    static const char *function_name = "projection_series_filter_1D_cv()";

    Print("filepath_in = \"%s\"\n", filepath_in);
    Print("filepath_out = \"%s\"\n", filepath_out);

    Print("transform_params->angle = %f\n", transform_params->angle);
    print_matrix2x2("transform_params->rot_matrix", transform_params->rot_matrix);
    print_matrix2x2("transform_params->inv_rot_matrix", transform_params->inv_rot_matrix);

    Print("filter_1D_params->type = %i\n", filter_1D_params->type);
    Print("filter_1D_params->length_rs (original) = %i\n", filter_1D_params->length_rs);
    Print("filter_1D_params->length_fs = %i\n", filter_1D_params->length_fs); // Should be 0.
    Print("filter_1D_params->cut_off = %f\n", filter_1D_params->cut_off);
    Print("filter_1D_params->roll_off = %f\n", filter_1D_params->roll_off);

    clock_t t_0_total, t_1_total;
    clock_t t_0, t_1;

    double secs_per_clock = 1.0 / (double) CLOCKS_PER_SEC;

    t_0_total = clock();

    // BEGIN: Open input MRC file.
    MrcHeader file_header_in;

    FILE *file_in = NULL;

    openMRCFile_general(filepath_in, &file_header_in, &file_in);
    // END: Open input MRC file.

    int n0_x = file_header_in.nx;
    int n0_y = file_header_in.ny;
    int n_tilts = file_header_in.nz;
    int mode = file_header_in.mode;

    // BEGIN: Create and open output MRC file.
    // BEGIN: Create output MRC file.
    if (mode != SLICE_MODE_FLOAT)
        Print("WARNING: Input mode == %i but using mode SLICE_MODE_FLOAT == %i for output!\n", mode, SLICE_MODE_FLOAT);

    MrcHeader file_header_out;

    FILE *file_out = NULL;

    createNewMRCFile(filepath_out, n0_x, n0_y, n_tilts, /*mode*/ SLICE_MODE_FLOAT);
    // END: Create output MRC file.

    // BEGIN: Open output MRC file.
    openMRCFile_general(filepath_out, &file_header_out, &file_out);
    // END: Open output MRC file.
    // END: Create and open output MRC file.

    real_type support0[4];
#if PROTOTYPE_COMPLIANT_INDEXING
    support0[0] = ((real_type) n0_x + 1.0) / 2.0; // x-coordinate of projection center // MATLAB prototype
    support0[1] = ((real_type) n0_y + 1.0) / 2.0; // y-coordinate of projection center // MATLAB prototype
    support0[2] = (real_type) n0_x; // max x-coordinate of projection // MATLAB prototype
    support0[3] = (real_type) n0_y; // max y-coordinate of projection // MATLAB prototype
#else
    support0[0] = ((real_type) n0_x - 1.0) / 2.0; // y-coordinate of projection center
    support0[1] = ((real_type) n0_y - 1.0) / 2.0; // y-coordinate of projection center
    support0[2] = (real_type) n0_x - 1.0; // max x-coordinate of projection
    support0[3] = (real_type) n0_y - 1.0; // max y-coordinate of projection
#endif

    real_type corners0[4][2];
    corners0[0][0] = 0.0; corners0[0][1] = 0.0;
    corners0[1][0] = support0[2]; corners0[1][1] = 0.0;
    corners0[2][0] = 0.0; corners0[2][1] = support0[3];
    corners0[3][0] = support0[2]; corners0[3][1] = support0[3];

    real_type support[4];
    support[0] = support0[0]; // x-coordinate of transformed projection center
    support[1] = support0[1]; // y-coordinate of transformed projection center
    support[2] = support0[2]; // max x-coordinate of transformed projection
    support[3] = support0[3]; // max y-coordinate of transformed projection

    real_type corners[4][2];
    memcpy(corners, corners0, sizeof(real_type));

    // NOTE: I think the transform should be the same as that used to transform the original slice, but cf. the MATLAB prototype.
    calc_transformed_support(transform_params->rot_matrix, support);
    //calc_transformed_support(transform_params->inv_rot_matrix, support);

    //calc_transformed_support_corners(transform_params->rot_matrix, support, corners);

    // NOTE: To conform to the MATLAB prototype, both projections must be padded with a row and a column of zeros.
    int row_right_pad = 1;
    int col_top_pad = 1;

#if PROTOTYPE_COMPLIANT_INDEXING
    int n0_x_padded = round(support0[2]) + row_right_pad;
    int n0_y_padded = round(support0[3]) + col_top_pad;
    int n_x_padded = round(support[2]) + row_right_pad;
    int n_y_padded = round(support[3]) + col_top_pad;
#else
    int n0_x_padded = round(support0[2] + 1.0) + row_right_pad;
    int n0_y_padded = round(support0[3] + 1.0) + col_top_pad;
    int n_x_padded = round(support[2] + 1.0) + row_right_pad;
    int n_y_padded = round(support[3] + 1.0) + col_top_pad;
#endif

    // Calculate filter.
    filter_1D_data_type *filter_data = create_filter_1D_data_n_xy(filter_1D_params, n_x_padded, n_y_padded);

    IplImage *projection0 = create_IplImage_SetZero(n0_x_padded, n0_y_padded, IPL_DEPTH_REAL);
    IplImage *projection = create_IplImage_SetZero(n_x_padded, n_y_padded, IPL_DEPTH_REAL);

    for (int i_tilt = 0; i_tilt < n_tilts; i_tilt++)
    {
        Print("i_tilt = %i\n", i_tilt);

        // Reuse slice later to transfer data back to the MRC file.
        Islice *slice = NULL;
        slice = sliceReadMRC(&file_header_in, i_tilt, 'z');
        if (slice == NULL)
            Abort("ERROR: %s -- Cannot read file: \"%s\".\n", function_name, filepath_in);

        // NOTE: Output floating-point data.
        if (slice->mode != SLICE_MODE_FLOAT)
            sliceNewMode(slice, SLICE_MODE_FLOAT);

        copy_Islice_to_IplImage(slice, projection0);

        t_0 = clock();

        // NOTE: inv_rot_matrix to conform to MATLAB prototype.
        transform_projection(projection0, support0, transform_params->inv_rot_matrix, projection, support);
        //transform_projection(projection0, support0, corners0, transform_params->inv_rot_matrix, projection, support, corners);

        //write_MRC_image_from_IplImage(projection, "/home/akulo/filter_1D_images/projection.mrc");

        t_1 = clock();
        Print("Transform delta t:%.15e\n", secs_per_clock * ((double) t_1 - (double) t_0));

        t_0 = clock();

        projection_filter_1D_fs(projection, filter_data);

//        write_MRC_image_from_IplImage(projection, "/home/akulo/filter_1D_images/projection.mrc");

        t_1 = clock();
        Print("Filtering delta t:%.15e\n", secs_per_clock * ((double) t_1 - (double) t_0));

        t_0 = clock();

        // NOTE: rot_matrix to conform to MATLAB prototype.
        transform_projection(projection, support, transform_params->rot_matrix, projection0, support0);
        //transform_projection(projection, support, corners, transform_params->rot_matrix, projection0, support0, corners0);

        t_1 = clock();
        Print("Inv. transform delta t:%.15e\n", secs_per_clock * ((double) t_1 - (double) t_0));

        //write_MRC_image_from_IplImage(projection0, "/home/akulo/filter_1D_images/projection0.mrc");

        copy_IplImage_to_Islice(projection0, slice);

        sliceWriteMRC(&file_header_out, slice, i_tilt, 'z');
        sliceFree(slice);

#ifdef MEX
        mexEvalString("fprintf('Done processing projection.\\n');");
#endif
    }

    calc_mmm_of_MRC(&file_header_out);

    // Free resources.

    cvReleaseImage(&projection0);
    cvReleaseImage(&projection);

    filter_1D_data_release(filter_data);

    if(fclose(file_in))
        Abort("ERROR: %s -- Cannot close input file: \"%s\".\n", function_name, filepath_in);

    if(fclose(file_out))
        Abort("ERROR: %s -- Cannot close output file \"%s\".\n", function_name, filepath_out);

    t_1_total = clock();
 
    Print("Total duration: %.15e\n", secs_per_clock * ((double) t_1_total - (double) t_0_total));
}

#elif defined PROJECTION_SERIES_FILTER_1D_CV_CV_ISLICE_PUSH

// NOTE: Uses Islice for workspace.
void projection_series_filter_1D_cv
//void projection_series_filter_1D
(
    const char *filepath_in, 
    const char *filepath_out,
    transform_params_type *transform_params,
    filter_1D_params_type *filter_1D_params
) 
{
    static const char *function_name = "projection_series_filter_1D_cv()";

    real_type resize_factor = 4.0;
    Print("resize_factor = \"%.15e\"\n", resize_factor);

    Print("filepath_in = \"%s\"\n", filepath_in);
    Print("filepath_out = \"%s\"\n", filepath_out);

    Print("transform_params->angle = %f\n", transform_params->angle);
    print_matrix2x2("transform_params->rot_matrix", transform_params->rot_matrix);
    print_matrix2x2("transform_params->inv_rot_matrix", transform_params->inv_rot_matrix);

    Print("filter_1D_params->type = %i\n", filter_1D_params->type);
    Print("filter_1D_params->length_rs (original) = %i\n", filter_1D_params->length_rs);
//    filter_1D_params->length_rs = round((real_type) filter_1D_params->length_rs * resize_factor); // Uncomment if filtering resized image.
//    if (filter_1D_params->length_rs % 2 == 0) ++(filter_1D_params->length_rs); // Uncomment if filtering resized image.
//    Print("filter_1D_params->length_rs (resized) = %i\n", filter_1D_params->length_rs); // Uncomment if filtering resized image.
    Print("filter_1D_params->length_fs = %i\n", filter_1D_params->length_fs); // Should be 0.
    Print("filter_1D_params->cut_off = %f\n", filter_1D_params->cut_off);
    Print("filter_1D_params->roll_off = %f\n", filter_1D_params->roll_off);

    clock_t t_0_total, t_1_total;
    clock_t t_0, t_1;

    double secs_per_clock = 1.0 / (double) CLOCKS_PER_SEC;

    t_0_total = clock();

    // BEGIN: Open input MRC file.
    MrcHeader file_header_in;

    FILE *file_in = NULL;

    openMRCFile_general(filepath_in, &file_header_in, &file_in);
    // END: Open input MRC file.

    int n0_x = file_header_in.nx;
    int n0_y = file_header_in.ny;
    int num_tilts = file_header_in.nz;
    int mode = file_header_in.mode;

    // BEGIN: Create and open output MRC file.
    // BEGIN: Create output MRC file.
    if (mode != SLICE_MODE_FLOAT)
        Print("WARNING: Input mode == %i but using mode SLICE_MODE_FLOAT == %i for output!\n", mode, SLICE_MODE_FLOAT);

    MrcHeader file_header_out;

    FILE *file_out = NULL;

    createNewMRCFile(filepath_out, n0_x, n0_y, num_tilts, /*mode*/ SLICE_MODE_FLOAT);
    // END: Create output MRC file.

    // BEGIN: Open output MRC file.
    openMRCFile_general(filepath_out, &file_header_out, &file_out);
    // END: Open output MRC file.
    // END: Create and open output MRC file.

    real_type support_orig[4];
    support_orig[0] = ((real_type) n0_x + 1.0) / 2.0 - 1.0; // x-coordinate of projection center
    support_orig[1] = ((real_type) n0_y + 1.0) / 2.0 - 1.0; // y-coordinate of projection center
    support_orig[2] = (real_type) n0_x - 1.0; // max x-coordinate of projection
    support_orig[3] = (real_type) n0_y - 1.0; // max y-coordinate of projection

    // NOTE: I think the transform should be the same as that used to transform the original slice, but cf. the MATLAB prototype.
    calc_transformed_support(transform_params->rot_matrix, support_orig);
    //calc_transformed_support(transform_params->inv_rot_matrix, support);

    int n0_x_resize = round(n0_x * resize_factor);
    int n0_y_resize = round(n0_y * resize_factor);

    real_type support0[4];
    support0[0] = ((real_type) n0_x_resize + 1.0) / 2.0 - 1.0; // x-coordinate of resized projection center
    support0[1] = ((real_type) n0_y_resize + 1.0) / 2.0 - 1.0; // y-coordinate of resized projection center
    support0[2] = (real_type) n0_x_resize - 1.0; // max x-coordinate of resized projection
    support0[3] = (real_type) n0_y_resize - 1.0; // max y-coordinate of resized projection

    real_type support[4];
    support[0] = support0[0]; // x-coordinate of transformed resized projection center
    support[1] = support0[1]; // y-coordinate of transformed resized projection center
    support[2] = support0[2]; // max x-coordinate of transformed resized projection
    support[3] = support0[3]; // max y-coordinate of transformed resized projection

    // NOTE: I think the transform should be the same as that used to transform the original slice, but cf. the MATLAB prototype.
    calc_transformed_support(transform_params->rot_matrix, support);
    //calc_transformed_support(transform_params->inv_rot_matrix, support);

    // Calculate filter.
    filter_1D_data_type *filter_data = create_filter_1D_data(filter_1D_params, support_orig);

    // BEGIN: WARNING: Some of this is unnecessary!  Use OpenCV ROIs!
    Islice *slice0_unpadded = sliceCreateZeros(round(support0[2] + 1.0), round(support0[3] + 1.0), SLICE_MODE_FLOAT);

    Islice *slice0 = sliceCreateZeros(round(support[2] + 1.0), round(support[3] + 1.0), SLICE_MODE_FLOAT);

    // The projection data transformed.
    Islice *slice = sliceCreateZeros(round(support[2] + 1.0), round(support[3] + 1.0), SLICE_MODE_FLOAT);

    Islice *slice_orig = sliceCreateZeros(round(support_orig[2] + 1.0), round(support_orig[3] + 1.0), SLICE_MODE_FLOAT);
    // END: WARNING: Some of this is unnecessary!  Use OpenCV ROIs!

    for (int i_tilt = 0; i_tilt < num_tilts; i_tilt++)
    {
        Print("i_tilt = %i\n", i_tilt);

        // Use this slice to transfer data to the MRC file.
        Islice *slice0_orig = NULL;
        slice0_orig = sliceReadMRC(&file_header_in, i_tilt, 'z');
        if (slice0_orig == NULL)
            Abort("ERROR: %s -- Cannot read file: \"%s\".\n", function_name, filepath_in);

        // NOTE: Work on floating-point data.
        if (slice0_orig->mode != SLICE_MODE_FLOAT)
            sliceNewMode(slice0_orig, SLICE_MODE_FLOAT);

        //write_MRC_image_from_Islice(slice0_orig, "/home/akulo/filter_1D_images/slice0_orig.mrc");

        t_0 = clock();

        // NOTE: These calls should be in transform_slice, but putting them there would complicate things.
        if (resize_factor != 1.0)
        {
            slice_resize_copy(slice0_orig, slice0_unpadded, resize_factor);
            slice_recanvas_center_copy(slice0_unpadded, slice0);
        }
        else
        {
            slice_recanvas_center_copy(slice0_orig, slice0);
        }

        //write_MRC_image_from_Islice(slice0, "/home/akulo/filter_1D_images/slice0.mrc");

        // NOTE: Negative angle to conform to MATLAB prototype.
        transform_slice_cv(slice0, support, -transform_params->angle, slice, support);

        //write_MRC_image_from_Islice(slice, "/home/akulo/filter_1D_images/slice.mrc");

        t_1 = clock();
        Print("Transform delta t:%.15e\n", secs_per_clock * ((double) t_1 - (double) t_0));

        t_0 = clock();

        if (resize_factor != 1.0)
            slice_resize_copy(slice, slice_orig, 1.0 / resize_factor);
        else
            slice_recanvas_copy(slice, slice_orig);

        //slice_filter_1D_rs(slice_orig, filter_data->filter_rs, filter_data->params.length_rs, filter_data->workspace);
        slice_filter_1D_fs_cv(slice_orig, filter_data);

        //write_MRC_image_from_Islice(slice_orig, "/home/akulo/filter_1D_images/slice_orig.mrc");

        if (resize_factor != 1.0)
            slice_resize_copy(slice_orig, slice, resize_factor);
        else
            slice_recanvas_copy(slice_orig, slice);

        t_1 = clock();
        Print("Filtering delta t:%.15e\n", secs_per_clock * ((double) t_1 - (double) t_0));

        t_0 = clock();

        // NOTE: Positive angle to conform to MATLAB prototype.
        transform_slice_cv(slice, support, transform_params->angle, slice0, support);

        //write_MRC_image_from_Islice(slice0, "/home/akulo/filter_1D_images/slice0.mrc");

        // NOTE: These calls should be in transform_slice, but putting them there would complicate things.
        if (resize_factor != 1.0)
        {
            slice_recanvas_center_copy(slice0, slice0_unpadded);
            slice_resize_copy(slice0_unpadded, slice0_orig, 1.0 / resize_factor);
        }
        else
        {
            slice_recanvas_center_copy(slice0, slice0_orig);
        }

        t_1 = clock();
        Print("Inv. transform delta t:%.15e\n", secs_per_clock * ((double) t_1 - (double) t_0));

        sliceWriteMRC(&file_header_out, slice0_orig, i_tilt, 'z');
        sliceFree(slice0_orig);

#ifdef MEX
        mexEvalString("fprintf('Done processing projection.\\n');");
#endif
    }

    calc_mmm_of_MRC(&file_header_out);

    // Free resources.

    filter_1D_data_release(filter_data);

    sliceFree(slice_orig);
    sliceFree(slice);
    sliceFree(slice0);
    sliceFree(slice0_unpadded);

    if(fclose(file_in))
        Abort("ERROR: %s -- Cannot close input file: \"%s\".\n", function_name, filepath_in);

    if(fclose(file_out))
        Abort("ERROR: %s -- Cannot close output file \"%s\".\n", function_name, filepath_out);

    t_1_total = clock();
 
    Print("Total duration: %.15e\n", secs_per_clock * ((double) t_1_total - (double) t_0_total));
}

#endif

void projection_series_filter_1D_nocv
//void projection_series_filter_1D
(
    const char *filepath_in, 
    const char *filepath_out,
    transform_params_type *transform_params,
    filter_1D_params_type *filter_1D_params
) 
{
    static const char *function_name = "projection_series_filter_1D_nocv()";

    Print("filepath_in = \"%s\"\n", filepath_in);
    Print("filepath_out = \"%s\"\n", filepath_out);

    Print("transform_params->angle = %f\n", transform_params->angle);
    print_matrix2x2("transform_params->rot_matrix", transform_params->rot_matrix);
    print_matrix2x2("transform_params->inv_rot_matrix", transform_params->inv_rot_matrix);

    Print("filter_1D_params->type = %i\n", filter_1D_params->type);
    Print("filter_1D_params->length_rs = %i\n", filter_1D_params->length_rs);
    Print("filter_1D_params->length_fs = %i\n", filter_1D_params->length_fs); // Should be 0.
    Print("filter_1D_params->cut_off = %f\n", filter_1D_params->cut_off);
    Print("filter_1D_params->roll_off = %f\n", filter_1D_params->roll_off);

    clock_t t_0_total, t_1_total;
    clock_t t_0, t_1;

    double secs_per_clock = 1.0 / (double) CLOCKS_PER_SEC;

    t_0_total = clock();

    // BEGIN: Open input MRC file.
    MrcHeader file_header_in;

    FILE *file_in = NULL;

    openMRCFile_general(filepath_in, &file_header_in, &file_in);
    // END: Open input MRC file.

    int n0_x = file_header_in.nx;
    int n0_y = file_header_in.ny;
    int n_tilts = file_header_in.nz;
    int mode = file_header_in.mode;

    // BEGIN: Create and open output MRC file.
    // BEGIN: Create output MRC file.
    if (mode != SLICE_MODE_FLOAT)
        Print("WARNING: Input mode == %i but using mode SLICE_MODE_FLOAT == %i for output!\n", mode, SLICE_MODE_FLOAT);

    MrcHeader file_header_out;

    FILE *file_out = NULL;

    createNewMRCFile(filepath_out, n0_x, n0_y, n_tilts, /*mode*/ SLICE_MODE_FLOAT);
    // END: Create output MRC file.

    // BEGIN: Open output MRC file.
    openMRCFile_general(filepath_out, &file_header_out, &file_out);
    // END: Open output MRC file.
    // END: Create and open output MRC file.

    real_type support0[4];
#if PROTOTYPE_COMPLIANT_INDEXING
    support0[0] = ((real_type) n0_x + 1.0) / 2.0; // x-coordinate of projection center // MATLAB prototype
    support0[1] = ((real_type) n0_y + 1.0) / 2.0; // y-coordinate of projection center // MATLAB prototype
    support0[2] = (real_type) n0_x; // max x-coordinate of projection // MATLAB prototype
    support0[3] = (real_type) n0_y; // max y-coordinate of projection // MATLAB prototype
#else
    support0[0] = ((real_type) n0_x + 1.0) / 2.0 - 1.0; // x-coordinate of projection center
    support0[1] = ((real_type) n0_y + 1.0) / 2.0 - 1.0; // y-coordinate of projection center
    support0[2] = (real_type) n0_x - 1.0; // max x-coordinate of projection
    support0[3] = (real_type) n0_y - 1.0; // max y-coordinate of projection
#endif

    real_type support[4];
    support[0] = support0[0]; // x-coordinate of transformed projection center
    support[1] = support0[1]; // y-coordinate of transformed projection center
    support[2] = support0[2]; // max x-coordinate of transformed projection
    support[3] = support0[3]; // max y-coordinate of transformed projection

    // NOTE: I think the transform should be the same as that used to transform the original slice, but cf. the MATLAB prototype.
    calc_transformed_support(transform_params->rot_matrix, support);
    //calc_transformed_support(transform_params->inv_rot_matrix, support);

    // Calculate filter.
    filter_1D_data_type *filter_data = create_filter_1D_data(filter_1D_params, support);

    // NOTE: To conform to the MATLAB prototype, slice0 must be padded with a row and a column of zeros.
    int row_right_pad = 1;
    int col_top_pad = 1;

#if PROTOTYPE_COMPLIANT_INDEXING
    int n0_x_unpadded = round(support0[2]);
    int n0_y_unpadded = round(support0[3]);
    int n_x_unpadded = round(support[2]);
    int n_y_unpadded = round(support[3]);

    int n0_x_padded = n0_x_unpadded + row_right_pad;
    int n0_y_padded = n0_y_unpadded + col_top_pad;
    int n_x_padded = n_x_unpadded + row_right_pad;
    int n_y_padded = n_y_unpadded + col_top_pad;
#else
    int n0_x_unpadded = round(support0[2] + 1.0);
    int n0_y_unpadded = round(support0[3] + 1.0);
    int n_x_unpadded = round(support[2] + 1.0);
    int n_y_unpadded = round(support[3] + 1.0);

    int n0_x_padded = n0_x_unpadded + row_right_pad;
    int n0_y_padded = n0_y_unpadded + col_top_pad;
    int n_x_padded = n_x_unpadded + row_right_pad;
    int n_y_padded = n_y_unpadded + col_top_pad;
#endif

#if PROTOTYPE_COMPLIANT_TRANSFORM
    Islice *slice0 = sliceCreateZeros(n0_x_padded, n0_y_padded, SLICE_MODE_FLOAT); // NOTE: Push.
#else
    Islice *slice0 = sliceCreateZeros(n0_x_unpadded, n0_y_unpadded, SLICE_MODE_FLOAT); // NOTE: Pull.
#endif

    // The projection data transformed.
    Islice *slice_unpadded = sliceCreateZeros(n_x_unpadded, n_y_unpadded, SLICE_MODE_FLOAT);
    //Islice *slice_unpadded = sliceCreateZeros(n_x_padded, n_y_padded, SLICE_MODE_FLOAT); // NOTE: For pull, recall that transformed support contains an extra row and column of pixels.

#if PROTOTYPE_COMPLIANT_TRANSFORM
    // NOTE: To conform to the MATLAB prototype, slice must be padded with a row and a column of zeros.
    Islice *slice = sliceCreateZeros(n_x_padded, n_y_padded, SLICE_MODE_FLOAT); // NOTE: Push.
#else
    Islice *slice = sliceCreateZeros(n_x_unpadded, n_y_unpadded, SLICE_MODE_FLOAT); // NOTE: Pull.
#endif

    for (int i_tilt = 0; i_tilt < n_tilts; i_tilt++)
    {
        Print("i_tilt = %i\n", i_tilt);

        // Use this slice to transfer data to the MRC file.
        Islice *slice0_unpadded = NULL;
        slice0_unpadded = sliceReadMRC(&file_header_in, i_tilt, 'z');
        if (slice0_unpadded == NULL)
            Abort("ERROR: %s -- Cannot read file: \"%s\".\n", function_name, filepath_in);

        // NOTE: Work on floating-point data.
        if (slice0_unpadded->mode != SLICE_MODE_FLOAT)
            sliceNewMode(slice0_unpadded, SLICE_MODE_FLOAT);

        t_0 = clock();

        // NOTE: This call should be in transform_slice, but putting it there would complicate things.
        slice_recanvas_copy(slice0_unpadded, slice0);

        // NOTE: I think the transform should be rot_matrix, but cf. the MATLAB prototype.
#if PROTOTYPE_COMPLIANT_TRANSFORM
        transform_slice_push_nocv(slice0, support0, transform_params->inv_rot_matrix, slice_unpadded, support);
        //transform_slice_push_nocv(slice0, support0, transform_params->rot_matrix, slice_unpadded, support);
#else
        transform_slice_pull_nocv(slice0, support0, transform_params->inv_rot_matrix, slice_unpadded, support);
        //transform_slice_pull_nocv(slice0, support0, transform_params->rot_matrix, slice_unpadded, support);
#endif

        //write_MRC_image_from_Islice(slice_unpadded, "/home/akulo/filter_1D_images/slice_unpadded.mrc");

        t_1 = clock();
        Print("Transform delta t:%.15e\n", secs_per_clock * ((double) t_1 - (double) t_0));

        t_0 = clock();

//        slice_filter_1D_rs(slice_unpadded, filter_data->filter_rs, filter_data->params.length_rs, filter_data->workspace);

        t_1 = clock();
        Print("Filtering delta t:%.15e\n", secs_per_clock * ((double) t_1 - (double) t_0));

        t_0 = clock();

        // NOTE: This call should be in transform_slice, but putting it there would complicate things.
        slice_recanvas_copy(slice_unpadded, slice);

        //write_MRC_image_from_Islice(slice_unpadded, "/home/akulo/filter_1D_images/slice_unpadded.mrc");

        // NOTE: I think the transform should be inv_rot_matrix, but cf. the MATLAB prototype.
#if PROTOTYPE_COMPLIANT_TRANSFORM
        transform_slice_push_nocv(slice, support, transform_params->rot_matrix, slice0_unpadded, support0);
        //transform_slice_push_nocv(slice, support, transform_params->inv_rot_matrix, slice0_unpadded, support0);
#else
        transform_slice_pull_nocv(slice, support, transform_params->rot_matrix, slice0, support0);
        //transform_slice_pull_nocv(slice, support, transform_params->inv_rot_matrix, slice0_unpadded, support0);
        slice_recanvas_copy(slice0, slice0_unpadded); // NOTE: Pull.
#endif

        t_1 = clock();
        Print("Inv. transform delta t:%.15e\n", secs_per_clock * ((double) t_1 - (double) t_0));

        sliceWriteMRC(&file_header_out, slice0_unpadded, i_tilt, 'z');
        sliceFree(slice0_unpadded);

#ifdef MEX
        mexEvalString("fprintf('Done processing projection.\\n');");
#endif
    }

    calc_mmm_of_MRC(&file_header_out);

    // Free resources.

    filter_1D_data_release(filter_data);

    sliceFree(slice);
    sliceFree(slice_unpadded);
    sliceFree(slice0);

    if(fclose(file_in))
        Abort("ERROR: %s -- Cannot close input file: \"%s\".\n", function_name, filepath_in);

    if(fclose(file_out))
        Abort("ERROR: %s -- Cannot close output file \"%s\".\n", function_name, filepath_out);

    t_1_total = clock();
 
    Print("Total duration: %.15e\n", secs_per_clock * ((double) t_1_total - (double) t_0_total));
}

void projection_series_filter_1D
(
    const char *filepath_in, 
    const char *filepath_out,
    transform_params_type *transform_params,
    filter_1D_params_type *filter_1D_params
) 
{
    if (PROTOTYPE_COMPLIANT_INDEXING == 1)
        Print("PROTOTYPE_COMPLIANT_INDEXING == 1\n");
    else
        Print("PROTOTYPE_COMPLIANT_INDEXING != 1\n");

    if (PROTOTYPE_COMPLIANT_TRANSFORM == 1)
        Print("PROTOTYPE_COMPLIANT_TRANSFORM == 1\n");
    else
        Print("PROTOTYPE_COMPLIANT_TRANSFORM != 1\n");

    if (USE_FFTW == 1)
        Print("USE_FFTW == 1\n");
    else
        Print("USE_FFTW != 1\n");

    int filepath_max_length = 1024;

    char filepath_out_nocv[filepath_max_length];
    char filepath_out_cv[filepath_max_length];

    snprintf(filepath_out_nocv, filepath_max_length, "%s.nocv", filepath_out);
//    snprintf(filepath_out_cv, filepath_max_length, "%s.cv", filepath_out);
//    snprintf(filepath_out_nocv, filepath_max_length, "%s", filepath_out);
    snprintf(filepath_out_cv, filepath_max_length, "%s", filepath_out);

//    projection_series_filter_1D_nocv(filepath_in, filepath_out_nocv, transform_params, filter_1D_params);
    projection_series_filter_1D_cv(filepath_in, filepath_out_cv, transform_params, filter_1D_params);
}

////////////////////////////////////////////////////////////////////////////////
// END: projection_series_filter_1D().
////////////////////////////////////////////////////////////////////////////////
