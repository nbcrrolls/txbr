"""modl -- Model package.

Package allowing to use IMOD model.
"""

from model import *
from modfile import *
from structure import *
