#ifndef FILTER_1D_H
#define FILTER_1D_H

typedef double real_type;
typedef real_type pixel_type;

int Print(char* format, ...);
void Abort(char* format, ...);

typedef struct 
{
    real_type angle;
    int angle_valid;

    real_type rot_matrix[2][2];
    int rot_matrix_valid;

    real_type inv_rot_matrix[2][2];
    int inv_rot_matrix_valid;
}
transform_params_type;

transform_params_type *create_transform_params_from_angle
(
    real_type angle
);

transform_params_type *create_transform_params_from_rot_matrix2x2
(
    real_type rot_matrix2x2[2][2]
);

enum filter_1D_type_enum
{
    SHEPPLOGAN = 0,
    RAMLAK = 1,
    CUSTOMRWEIGHTED = 2
};

typedef struct 
{
    enum filter_1D_type_enum type;
    int length_rs;
    int length_fs;
    real_type cut_off;
    real_type roll_off;
}
filter_1D_params_type;

filter_1D_params_type *create_filter_1D_params
(
    const char *type_string,
    int length,
    real_type cut_off,
    real_type roll_off
);

filter_1D_params_type *create_filter_1D_params_from_strings
(
    const char *type_string,
    const char *length_string,
    const char *cut_off_string,
    const char *roll_off_string
);

void projection_series_filter_1D
(
    const char *filepath_in, 
    const char *filepath_out,
    transform_params_type *transform_params,
    filter_1D_params_type *filter_1D_params
);

#endif // FILTER_1D_H
