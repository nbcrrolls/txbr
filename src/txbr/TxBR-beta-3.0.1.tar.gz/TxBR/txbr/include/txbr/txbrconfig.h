#ifndef TXBRCONFIG_H
#define TXBRCONFIG_H 

typedef float txbrFloat;

#endif
