numberOfCPUForNode = { 'localhost': 2 }
    
def infoForCPUHosts():

    nodes = sorted(numberOfCPUForNode.keys())
        
    return ( nodes, numberOfCPUForNode )


def numberOfCPUs():
    '''Returns the total number of available CPU.'''
        
    values = numberOfCPUForNode.values()
    
    n = 0

    for value in values:
        n += value
        
    return n
    
    
