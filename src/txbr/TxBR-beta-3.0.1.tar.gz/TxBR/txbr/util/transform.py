import numpy,numpy.linalg
import scipy.optimize
import util

CONFORMAL_TRANSFORMATION = 'conformal'
AFFINE_TRANSFORMATION = 'affine'
PROJECTIVE_TRANSFORMATION = 'projective'
POLYNOMIAL_TRANSFORMATION = 'projective'


class AffineTransformation2D:

    def __init__(self,mxx,mxy,myx,myy,tx,ty,x0=0,y0=0.0):
        """(x0,y0) center of the transformation/image.
        """
        self.M = numpy.array([[mxx,mxy],[myx,myy]],dtype=float)
        self.T = numpy.array([tx,ty],dtype=float)
        self.C = numpy.array([x0,y0],dtype=float)

        self.Minv = numpy.linalg.inv(self.M)

    def forward(self,x,x0=None):
        if x0!=None: self.C = x0
        y = self.C + self.T + numpy.dot(self.M,x-self.C)
        return y

    def reverse(self,x,x0=None):
        if x0!=None: self.C = x0
        y = self.C + numpy.dot(self.Minv,x-self.C-self.T)
        return y

    def inv(self):
        Minv = self.Minv
        Tinv = -self.T
        return AffineTransformation2D(Minv[0,0],Minv[0,1],Minv[1,0],Minv[1,1],Tinv[0],Tinv[1])

    def compose(self,g):
        M = numpy.dot(self.M,g.M)
        T = numpy.dot(self.M,g.T) + self.T
        return AffineTransformation2D(M[0,0],M[0,1],M[1,0],M[1,1],T[0],T[1])


class Rotation3D:
    '''A class for 3D Rotation.'''

    def __init__(self,center,axis,theta):

        self.center = numpy.asarray(center)
        self.axis = numpy.asarray(axis)
        self.theta = theta

        self.axis = self.axis/numpy.sqrt(numpy.dot(self.axis,self.axis))

        #print 'Rotation: Center %s    Axis %s    Angle %f' %(str(self.center),str(self.axis),self.theta)

        self.T = numpy.zeros((3))
        self.M = numpy.zeros((3,3))

        cos_theta = numpy.cos(self.theta)
        sin_theta = numpy.sin(self.theta)

        self.M[0,0] = self.axis[0]*self.axis[0]*(1-cos_theta) + cos_theta
        self.M[0,1] = self.axis[0]*self.axis[1]*(1-cos_theta) - self.axis[2]*sin_theta
        self.M[0,2] = self.axis[0]*self.axis[2]*(1-cos_theta) + self.axis[1]*sin_theta

        self.M[1,0] = self.axis[1]*self.axis[0]*(1-cos_theta) + self.axis[2]*sin_theta
        self.M[1,1] = self.axis[1]*self.axis[1]*(1-cos_theta) + cos_theta
        self.M[1,2] = self.axis[1]*self.axis[2]*(1-cos_theta) - self.axis[0]*sin_theta

        self.M[2,0] = self.axis[2]*self.axis[0]*(1-cos_theta) - self.axis[1]*sin_theta
        self.M[2,1] = self.axis[2]*self.axis[1]*(1-cos_theta) + self.axis[0]*sin_theta
        self.M[2,2] = self.axis[2]*self.axis[2]*(1-cos_theta) + cos_theta

        self.T = self.center - numpy.dot(self.M,self.center)

    def inv(self):

        return Rotation3D(self.center,self.axis,-self.theta)


    def forward(self,X):
        '''Last index of X contains the 3 coorinates of X
        '''

        X = numpy.asarray(X)
        s = X.shape
        n = X.size/3

        X = numpy.resize(X,(n,3))

        rX = numpy.tile(self.T,(n,1)) + numpy.dot(X,self.M.T)
        rX = numpy.resize(rX,s)

        return rX



def polynomial_regression(x,points,orders):
    '''This routine allows to perform polynomial regressions in multidimensional space. We
    note the dimension of the input space dim1, while the output space is dim2
    Variable x is a numpy array of shape (ndata,dim1) and represent the input parameters
    Variable points is a numpy array of shape (ndata,dim2) and contain the image of x.
    Variable orders is a numpy array of shape (dim1) and contains the polynomial order
    used for each component of x.
    Returns a polynom or an array of polynom.'''
    
    x = numpy.asarray(x)
    points = numpy.asarray(points)
    orders = numpy.asarray(orders)

    (ndata,dim1) = x.shape

    if points.shape[0]!=ndata or orders.shape[0]!=dim1:
        raise ValueError

    if len(points.shape)==2:
        dim2 = points.shape[1]
    else:
        dim2 = 1
        points = numpy.resize(points,(ndata,dim2))

    nn = util.numberOfTerms(orders,dim=dim1)

    coeffs = numpy.zeros((dim2*nn))

    def residuals(coeffs_):
        res = numpy.zeros((dim2*ndata))
        for i in range(dim2):
           res[i*ndata:(i+1)*ndata] = points[:,i]-util.poleval(coeffs_[i*nn:(i+1)*nn],orders,x)
        return res

    lsq = scipy.optimize.leastsq(residuals,coeffs)
    coeffs = lsq[0]

    if dim2==1:
        return util.Poly(coeffs,orders)
    else:
        return [util.Poly(coeffs[i*nn:(i+1)*nn],orders) for i in range(dim2)]



def orthogonal_regression_2d(x,points):
    '''This routine allows to perform an polynomial regressions in a 2D space.
    Variable x is a numpy array of shape (ndata,2) and represent the input parameters
    Variable points is a numpy array of shape (ndata,2) and contain the image of x.
    Returns a polynom or an array of polynom.'''

    ndata = x.shape[0]

    if x.shape[1]!=2 or points.shape!=(ndata,2):
        raise ValueError

    coeffs = numpy.zeros(3)
    R = numpy.zeros((2,2))

    def residuals(coeffs_):
        x1,x2,theta = coeffs_
        c,s = numpy.cos(theta),numpy.sin(theta)
        R[0,:] = [c,-s]
        R[1,:] = [s,c]
        rx = numpy.tensordot(R,x,(1,1))
        res = numpy.zeros((2*ndata))
        res[:ndata] = points[:,0] - x1 - rx[0,:]
        res[ndata:] = points[:,1] - x2 - rx[1,:]
        return res

    lsq = scipy.optimize.leastsq(residuals,coeffs)
    x1,x2,theta = lsq[0]
    c,s = numpy.cos(theta),numpy.sin(theta)

    rot = util.Poly([x1,c,-s,x2,s,c],[1,1])

    return (rot,theta,x1,x2)


def cp2tform(input_points, base_points, transformation_type):

    if input_points.shape!=base_points.shape:
        raise ValueError("Input and Base points must have the same shape.")

    if transformation_type==PROJECTIVE_TRANSFORMATION:    # Needs at least 4 pair of points
        n = input_points.shape[0]
        M = numpy.zeros((2*n,8))
        X = numpy.zeros(2*n)
        M[::2,0] = 1.0
        M[1::2,1] = 1.0
        M[::2,2:4] = input_points[:,:]
        M[1::2,4:6] = input_points[:,:]
        M[::2,6] = -base_points[:,0]*input_points[:,0]
        M[::2,7] = -base_points[:,0]*input_points[:,1]
        M[1::2,6] = -base_points[:,1]*input_points[:,0]
        M[1::2,7] = -base_points[:,1]*input_points[:,1]
        X[::2] = base_points[:,0]
        X[1::2] = base_points[:,1]
        M = numpy.dot(numpy.linalg.pinv(M),X)
        T = numpy.array([[M[2],M[3],M[0]],[M[4],M[5],M[1]],[M[6],M[7],1.0]])
        return T


