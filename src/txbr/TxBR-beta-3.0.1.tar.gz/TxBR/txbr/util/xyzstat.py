def g2_correlation():
    print 'toto'