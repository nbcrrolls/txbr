"""util -- Utility package.

Define power sequences in space of dimension less than 3.

numberOfTerms(approximationOrder,dim=3):
powerOrder(approximationOrder,dim=3):
"""

from geom import *
from powerseq import *
from poly import *
from sympoly import extractCoefficient
from transform import *
from xyzstat import *
from interp import mapSurface
from utilGPU import *
from utilMPI import *