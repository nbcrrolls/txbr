class Point:

    def __init__(self,x,y,z):
        self.x = x
        self.y = y
        self.z = z

    def __str__( self ):
        return "(" + str(self.x) + "," + str(self.y) + "," + str(self.z) + ")"

class Vector:

    def __init__(self,x,y,z):
        self.x = x
        self.y = y
        self.z = z

    def __str__( self ):
        return "(" + str(self.x) + "," + str(self.y) + "," + str(self.z) + ")"

class Plane:

    def __init__(self,a,b,c,d): # Plane Equation: ax+by+cz+d=0
        self.a = a
        self.b = b
        self.c = c
        self.d = d

    def __str__(self):
       return "(" + str(self.a) + "," + str(self.b) + "," + str(self.c)  + "," + str(self.d) + ")"
