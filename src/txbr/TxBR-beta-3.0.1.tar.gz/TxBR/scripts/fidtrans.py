#!/usr/bin/python

import sys,os.path,getopt
from txbr.utilities import *

import logging.config

from txbr import LOG_CONF
logging.config.fileConfig(LOG_CONF)

log = logging.getLogger('align')


def make_marker_model(directory,basename):

    log.info('Make marker model from (%s,%s)' %(directory,basename))

    makeMarkerModel(directory,basename)


def create_marker_model(directory,basename):

    fid_path = os.path.join(directory,basename+'.fid')
    prexg_path =  os.path.join(directory,basename+'.prexg')
    xg_path =  os.path.join(directory,basename+'.xf')

    log.info('Create marker model from %s' %fid_path)

    model = transfmod(fid_path,src='preali',dest='ali',prexgPath=prexg_path,xgPath=xg_path)
    model = makeMarkerModel(model.filename)


def usage():

    print "Usage: %s option -b basename -d directory -n n" % sys.argv[0]
    print "          option in [create,decimate]"


def main():

    try:
        option = sys.argv[1]
        opts, args = getopt.getopt(sys.argv[2:],
            "hd:w:b:n:",["help","directory=","base="])
    except getopt.GetoptError, err:
        # print help information and exit:
        print str(err) # will print something like "option -a not recognized"
        usage()
        sys.exit(2)

    directory = '.'
    basename = None
    n = 2

    for option_,value in opts:
        if option_ in ("-h", "--help"):
            usage()
            sys.exit()
        elif option_ in ("-d","--directory"):
            directory = value
        elif option_ in ("-b","--basename"):
            basename = value.split(',')
        elif option_ in ("-n"):
            n = int(value)
        else:
            assert False, "unhandled option"

    if basename==None:
        usage()
        raise SystemExit

    if option=='create':
        for b in basename:
            make_marker_model(directory,b)

    if option=='decimate':
        for b in basename:
            model_path = os.path.join(directory,b+'.fid')
            decimateModel(model_path,n)


main()
