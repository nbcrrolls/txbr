#!/usr/bin/python

import sys,getopt,os,math
import txbr.combine
import txbr.utilities

def getGeneratedFiles(directory,basenames,zstart,zstop,number_of_nodes,blocksize):
    '''Get the list of all the generated files after the initial backprojection step is completed.'''

    nserie = len(basenames)

    depth = zstop-zstart
    lpack = math.ceil(depth/number_of_nodes)

    number_of_blocks = int(math.ceil(lpack/blocksize))

    files = [[] for i in range(nserie)]
    fails = []

    for iserie in range(nserie):
        for inode in range(number_of_nodes):
            zpack = zstart + inode*lpack
            for iblock in range(number_of_blocks):
                filename = basenames[iserie] + '_z_' + '%.2f' %zpack + '-' + str(iblock) + '.out'
                filename = os.path.join(directory,filename)
                if not os.path.exists(filename):
                    fails.append(filename)
                else:
                    files[iserie].append(filename)

    return (files,fails)


def usage():

    print 'Usage: %s.py -b basename1[,...] -d directory -z zstart,zstop' %sys.argv[0]
    print '             -l block_size -n number_of_nodes'


def combine(directory,basenames,zstart,inputfiles):
    '''Combine the file outputs for each serie in one MRC file.'''

    outputs = []

    nserie = len(inputfiles)

    for iserie in range(nserie):
        output = basenames[iserie] + '_z_' + '%.1f' %zstart + '.out'
        output = os.path.join(directory,output)
        outputs.append(output)
        command = 'newstack'
        for file in inputfiles[iserie]:
            command += ' ' + file
        command += ' ' + output
        print command
        os.system(command)

    return outputs


def deleteFiles(files):

    nserie = len(files)

    for iserie in range(nserie):
        for file in files[iserie]:
            os.remove(file)


def main():

    try:
        opts, args = getopt.getopt(sys.argv[1:], "hb:d:z:l:n:", ["help","directory=","basename=","wd=","blocksize=","mpinodes=","doCombine","doClean"])
    except getopt.GetoptError, err:
        print str(err) # will print something like "option -a not recognized"
        usage()
        sys.exit(2)

    directory = "."
    work_directory = "."
    basenames = None
    output = None
    z = None
    blocksize = 5
    number_of_nodes = 1
    doCombine = False
    doClean = False

    for option,value in opts:
        if option in ('-h','--help'):
            usage()
            sys.exit()
        elif option in ('-d','--directory'):
            directory = value
        elif option in ('--wd'):
            work_directory = value
        elif option in ('-b','--basename'):
            basename = value
        elif option in ("-z"):
            try:
                z = [float(s) for s in value.split(',')]
            except TypeError:
                z = None
        elif option in ('-l','--blocksize'):
            blocksize = int(value)
        elif option in ('-n','--mpinodes'):
            number_of_nodes = int(value)
        elif option in ('--doCombine'):
            doCombine = True
        elif option in ('--doClean'):
            doClean = True
        else:
            assert False, "unhandled option"

    if basename==None:
        usage()
        sys.exit()

    basenames = basename.split(',')
    
    if z==None:
        project = txbr.TxBRproject( directory, basename, work_directory=work_directory )
        project.load()
        
        basenames = [s.basename for s in project.series]
        basename = ",".join([s.basename for s in project.series])
        
        zstart = project.reconstruction.origin.z
        zstop = project.reconstruction.end.z
    else:
        zstart = z[0]
        zstop = z[1]

    print 'To process: %s' %basenames
    print '(zstart,zstop)=(%.2f,%.2f)' %(zstart,zstop)
    print 'Number of nodes=%f' %number_of_nodes

    (inputfiles,fails) = getGeneratedFiles(work_directory,basenames,zstart,zstop,number_of_nodes,blocksize)

    if len(fails)!=0:
        print 'Error! The following files do not exist'
        print fails

    outputfiles = combine(work_directory,basenames,zstart,inputfiles)

    nserie = len(outputfiles)

    for iserie in range(nserie):
        os.chmod(outputfiles[iserie],0644)
        try:
            inputfiles.remove(outputfiles[iserie])
        except ValueError:
            pass

    name,exts = txbr.utilities.extract_series_name(basenames)
    output = name + '_z_' + '%.1f' %zstart + '.out'
    output = os.path.join(work_directory,output)

    if doCombine:
        model3DFile = os.path.join(work_directory,name + '.mod')
        model3DFile_tz = os.path.join(work_directory,name + '_tz_' + '%.1f' %zstart + '.mod')
        if nserie>1:
            outdict = {}
            for iserie in range(nserie):
                outdict[basenames[iserie] + '_z_' + '%.1f' %zstart + '.out'] = 1.0
            txbr.combine.merge('.',outdict,output)
        os.system('imodtrans -tz %f %s %s' %(-zstart,model3DFile,model3DFile_tz))
        os.system('imod %s %s' %(output,model3DFile_tz))
    else:
        os.system('imod %s' %(output))

    if doClean:
        deleteFiles(inputfiles)     # Remove the file ouputs

    showIndividualVolumes = False

    if showIndividualVolumes:
        for iserie in range(nserie):
            model3DFile = os.path.join(work_directory,basenames[iserie] + '.mod')
            model3DFile_tz = os.path.join(work_directory,basenames[iserie] + '_tz_' + '%.1f' %zstart + '.mod')
            os.system('imodtrans -tz %f %s %s' %(-zstart,model3DFile,model3DFile_tz))
            os.system('imod %s %s' %(outputfiles[iserie],model3DFile_tz))

main()

