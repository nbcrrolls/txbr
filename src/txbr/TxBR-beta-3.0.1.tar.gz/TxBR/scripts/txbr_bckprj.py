#!/usr/bin/python

import sys,os,math,getopt,time
import logging
import numpy,mpi4py.MPI
import util,txbr.bckprj

try:
    import txbr.bckprj_cu
except ImportError:
    print 'No GPU backprojection module available'

from txbr import LOG_CONF
logging.config.fileConfig(LOG_CONF)

log = logging.getLogger()

def usage():

    print
    print 'Usage: %s.py -b basename1[,...] [Options]' %os.path.basename(sys.argv[0])
    print
    print "    -d directory (default .)"
    print "        Name of the directory containing the input files"
    print "    --wd work_directory (default to directory)"
    print "        Name of the directory where the output files are stored"
    print "    -x xstart,xstop,xinc (default from .txbr file)"
    print "        x properties of the reconstruction"
    print "    -y ystart,ystop,yinc (default from .txbr file)"
    print "        y properties of the reconstruction"
    print "    -z ztart,zstop,zinc (default from .txbr file)"
    print "        z properties of the reconstruction"
    print "    --gpu"
    print "        Run the backprojection on a cluster of GPU boards"
    print "    --mpi"
    print "        Run the backprojection within the MPI protocol"
    print "    -h or --help"
    print "        Help Information"
    

def run_backprojection(keywords):
    
    basenames = keywords['basenames']

    directory = keywords['directory']
    work_directory = keywords['wd']
        
#    z0 = float(keywords['z'][0])
#    z1 = float(keywords['z'][1])
    zinc = 1.0
    
    z0 = keywords['zstart']
    z1 = keywords['zstop']
    deviceID = keywords['deviceID']

    for basename in basenames:

        log.info('Run TxBR backprojection for series %s between [%f,%f]' %(basename,z0,z1))

        txbr.bckprj.reconstruct( directory, basename, work_directory, 1, z0, z1, zinc )


def run_GPU_backprojection(keywords):
    
#    if not util.isGPUEnabled():
#        return run_backprojection(keywords)
    
    myrank = mpi4py.MPI.COMM_WORLD.Get_rank()
    nprocs = mpi4py.MPI.COMM_WORLD.Get_size()
    procnm = mpi4py.MPI.Get_processor_name()

    n_GPU_tot = util.numberOfGPUBoards()
    
    zstart = float(keywords['z'][0])
    zstop = float(keywords['z'][1])  
    
    depth = (zstop-zstart)
    
    blockForGPU = math.ceil(depth/n_GPU_tot)
    
    print 'blockForGPU: %i    n_GPU_tot:%i' %(blockForGPU,n_GPU_tot)
        
    nodes, numberOfGPUBoardsForNode, infoGPUBoard = util.infoForGPUHosts()

    node, deviceID = infoGPUBoard[myrank]

    keywords['zstart'] = zstart + myrank*blockForGPU
    keywords['zstop'] = keywords['zstart'] + blockForGPU
    keywords['deviceID'] = deviceID
    
    log.info('Device %i of node %s reconstructs slices for z in [%f,%f]' %(deviceID,node,keywords['zstart'],keywords['zstop']))
       
    basenames = keywords['basenames']
    directory = keywords['directory']
    work_directory = keywords['wd']
    z0 = keywords['zstart']
    z1 = keywords['zstop']
    zinc = 1.0
    
    deviceID = keywords['deviceID']

    for basename in basenames:

        log.info('Run TxBR backprojection for series %s between [%f,%f]' %(basename,z0,z1))

        txbr.bckprj_cu.reconstruct( directory, basename, work_directory, 1, z0, z1, zinc, deviceID )
    
        
def run_MPI_backprojection(keywords):

    myrank = mpi4py.MPI.COMM_WORLD.Get_rank()
    nprocs = mpi4py.MPI.COMM_WORLD.Get_size()
    procnm = mpi4py.MPI.Get_processor_name()

    zstart = keywords['z'][0]
    zstop = keywords['z'][1]

    depth = zstop-zstart
    block = math.ceil(depth/nprocs)

    keywords['txbr'] = os.environ['TXBR']
    keywords['rank'] = myrank
    keywords['zstart'] = zstart + myrank*block
    keywords['zstop'] = zstart + (myrank+1)*block
    
    directory = keywords['directory']
    work_directory = keywords['wd']
    zstart = keywords['zstart']
    zstop = keywords['zstop']
    zinc = 1.0

    for basename in keywords['basenames']:

        log.info("Process %i/%i running between z=[%.1f,%.1f] for series %s" %( myrank, nprocs, zstart, zstop, basename ))

        txbr.bckprj.reconstruct( directory, basename, work_directory, 1, zstart, zstop, zinc )
        

def main():

    try:
        opts, args = getopt.getopt(  \
                 sys.argv[1:], \
                 "hd:b:x:y:z:", \
                 [ "help","directory=","basenames=","wd=","mpi","gpu","gpuid=" ]
                    )
    except getopt.GetoptError, err:
        # print help information and exit:
        print str(err) # will print something like "option -a not recognized"
        usage()
        sys.exit(2)

    directory = None
    basenames = None
    work_directory = None
    x,y,z = None,None,None
    run_MPI = False
    run_GPU = False
    gpuid = 1

    for option,value in opts:
        if option in ("-h", "--help"):
            usage()
            sys.exit()
        elif option in ("-d","--directory"):
            directory = value
        elif option in ("-b","--basenames"):
            basenames = value.split(',')
        elif option in ("--wd"):
            work_directory = value
        elif option in ("--gpu"):
            run_GPU = True
        elif option in ("--gpuid"):
            gpuid = int(value)
        elif option in ("--mpi"):
            run_MPI = True
        elif option in ("-x"):
            try:
                x = [float(s) for s in value.split(',')]
            except TypeError:
                x = None
        elif option in ("-y"):
            try:
                y = [float(s) for s in value.split(',')]
            except TypeError:
                y = None
        elif option in ("-z"):
            try:
                z = [float(s) for s in value.split(',')]
            except TypeError:
                z = None
        else:
            assert False, "unhandled option"

    if basenames==None:
        usage()
        sys.exit()

    if directory==None:
        directory = '.'

    if work_directory==None:
        work_directory = directory


    keywords = {}
    keywords['basenames'] = basenames
    keywords['basename'] = ",".join(keywords['basenames'])
    keywords['directory'] = os.path.abspath(directory)
    keywords['wd'] = os.path.abspath(work_directory)
    keywords['x'] = x
    keywords['y'] = y
    keywords['z'] = z
    keywords['deviceID'] = gpuid

    t_start = time.time()
    
    if keywords['z']==None:  # If z is not defined, load z from the .txbr file
        directory = keywords['directory']
        basename = keywords['basename']
        project = txbr.TxBRproject( directory, basename, work_directory=work_directory)
        project.load()
        
        keywords['basenames'] = [s.basename for s in project.series]
        keywords['basename'] = ",".join([s.basename for s in project.series])
        
        z_start = project.reconstruction.origin.z
        z_stop = project.reconstruction.end.z
        z_step = 1
        keywords['z'] = [z_start,z_stop,z_step]
        
    z_start = keywords['z'][0]
    z_stop = keywords['z'][1]
    
    keywords['zstart'] = z_start
    keywords['zstop'] = z_stop
    keywords['zinc'] = 1

    print keywords

    if run_MPI:
        run_MPI_backprojection(keywords)
    elif run_GPU:
        run_GPU_backprojection(keywords)
    else:
        run_backprojection(keywords)

    t_stop = time.time()

    print 'Total Time = %f' %(t_stop-t_start)


main()


