#!/usr/bin/python

import sys, getopt, os
import txbr
from txbr.align import contalign

def usage():

    print 'Usage: %s.py -b basename[,...]  [Options]' % os.path.basename(sys.argv[0])
    print
    print "    -d directory (default .)"
    print "        Name of the directory containing the input files (.fid and .txbr)"
    print "    --wd work_directory (default to directory)"
    print "        Name of the directory where the output files are stored"
    print "    --ortho"
    print "        Flag for the orthogonal model"
    print "    --multiple (default value for n2<=1)"
    print "        Flag for the multiple model"
    print "    --constant (default value for n2>1)"
    print "        Flag for the constant model, Override the multiple default flag"
    print "    --flatten-order order"
    print "        Do a on the fly flattening from the bundle adjustment"
    print "    --fix-angles 1[,2,3] (only with option --ortho)"
    print "        Fix rotation angles in the orthogonal approximation"
    print "    --fix-t 1[,2,3]"
    print "        Fix the fixed points axis"
    print "    --axis u1,u2,u3 (default 0.0,1.0,0.0)"
    print "        Estimate for the rotation axis"
    print "    --n1 n1"
    print "        Polynomial order of the approximation patches"
    print "    --n2 n2"
    print "        Polynomial order of the projaction map"
    print "    --n3 n3"
    print "        Polynomial order of the trace approximations"
    print "    --n4 n4"
    print "        Polynomial order of the contour approximations"
    print "    --flatten-order order"
    print "        Performs a flattening for the reference tracks..."
    print "    --full"
    print "        Do the full minimization at high order..."
    print "    --load"
    print "        Load last minimization value (from .ctl files)..."
    print "    --init"
    print "        Load last minimization value (from .txbr)..."
    print "    --no-contour"
    print "        Remove Contours from bundle adjustment..."
    print "    --doPlot"
    print "        Do some plottings"


def main():

    try:

        opts, args = getopt.getopt(sys.argv[1:], "hb:d:l:",
                [ "help", "directory=", "basenTrueame=", "wd=", \
                  "ortho", "multiple", "constant", "full", "flatten-order=", \
                  "blocksize=", "fix-angles=", "fix-t=", "axis=", \
                  'n1=', 'n2=', 'n3=', 'n4=', 'iter=', 'load', 'init', \
                  'no-contour', 'doPlot'] )

    except getopt.GetoptError, err:

        print str(err) # will print something like "option -a not recognized"
        usage()
        sys.exit(2)

    directory = "."
    work_directory = "."

    basenames = None

    orthogonal = False
    multiple = False
    constant = False
    fix_angles = [ False, False, False ]
    fix_t = [ False, False, False ]

    keywords = {}

    for option,value in opts:
        if option in ('-h','--help'):
            usage()
            sys.exit()
        elif option in ('-d','--directory'):
            directory = value
        elif option in ('--wd'):
            work_directory = value
        elif option in ('-b','--basename'):
            basenames = [str(s) for s in value.split(',')]
        elif option in ('--ortho'):
            orthogonal = True
        elif option in ('--multiple'):
            multiple = True
        elif option in ('--constant'):
            constant = True
        elif option in ('--fix-angles'):
            for s in value.split(','): fix_angles[int(s)-1] = True
        elif option in ('--fix-t'):
            for s in value.split(','): fix_t[int(s)-1] = True
        elif option in ('--flatten-order'):
            keywords['flatten_order'] = int(value)
        elif option in ('-l','--blocksize'):
            keywords['blocksize'] = int(value)
        elif option in ('--n1'):
            keywords['n1'] = int(value)
        elif option in ('--n2'):
            keywords['n2'] = int(value)
        elif option in ('--n3'):
            keywords['n3'] = int(value)
        elif option in ('--n4'):
            keywords['n4'] = int(value)
        elif option in ('--iter'):
            keywords['iter'] = int(value)
        elif option in ('--full'):
            keywords['shortcut'] = False
        elif option in ('--axis'):
            u = numpy.array([float(s) for s in value.split(',')])
            keywords['axis'] = u/numpy.sqrt(u*u)
        elif option in ('--load'):
            keywords['evaluateFromScratch'] = False
        elif option in ('--init'):
            keywords['init'] = True
        elif option in ('--doPlot'):
            keywords['doPlot'] = True
        elif option in ('--no-contour'):
            keywords['with_contour'] = False
        else:
            assert False, "unhandled option"

    if basenames==None:
        usage()
        sys.exit()
        
    try:
        n2 = keywords['n2']
        if n2<=1 and not constant: # Force a multiple model if it is projective
            multiple = True
    except KeyError:
        if not constant:
            multiple = True
            
    directory = os.path.abspath(directory)
    work_directory = os.path.abspath(work_directory)
    basename = ','.join(basenames)

    keywords['model'] = contalign.encodeModel( orthogonal, multiple, fix_angles, fix_t )

    project = txbr.TxBRproject( directory, basename, work_directory=work_directory )
    project.load()
    
    alignment = contalign.TxBRContourAlign( project, **keywords )
    alignment.process()

    if 'doPlot' in keywords.keys() and keywords['doPlot']:
        
        import pylab
        pylab.show()
        
        from enthought.mayavi import mlab
        mlab.show()

main()

