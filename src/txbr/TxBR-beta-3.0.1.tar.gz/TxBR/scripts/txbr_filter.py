#!/usr/bin/python

import sys,os.path,math,time,getopt
import logging
import numpy, mpi4py.MPI
import txbr.prefil

from txbr import LOG_CONF
logging.config.fileConfig(LOG_CONF)

log = logging.getLogger('align')

print "Check the sign for the filtering angle"
ANGLE_SIGN = -1.0

def usage():
    
    print
    print 'Usage: %s.py -b basename1[,...] [Options]' %os.path.basename(sys.argv[0])
    print
    print "    -d directory (default .)"
    print "        Name of the directory containing the input files"
    print "    -wd work_directory (default .)"
    print "        Name of the directory where the output files are stored"
    print "    --mpi"
    print "        Run the filter within the MPI protocol"
    print "    -h or --help"
    print "        Help Information"
    
    
def run_filter( work_directory, series ):
    
    global ANGLE_SIGN
    
    for serie in series:

        angle = serie.getFilteringAngle()
        
        angle = ANGLE_SIGN*numpy.degrees(angle)

        if not serie.enabled: continue
        if not serie.input in ['st','preali']: continue

        log.info('Filter serie %s at angle %f from %s file.' %(serie.basename, angle, serie.input))

        if serie.input=='st':
            input = os.path.join(serie.directory, serie.basename + '.st')
            output = os.path.join(work_directory, serie.basename + '.st.SL')
        elif serie.input=='preali':
            input = os.path.join(serie.directory, serie.basename + '.preali')
            output = os.path.join(work_directory, serie.basename + '.preali.SL')

        txbr.prefil.filter(input,output,angle)

        preali_rot_SL = os.path.join(work_directory, serie.basename + '.preali.rot.SL')

        if os.path.lexists(preali_rot_SL):
            os.unlink(preali_rot_SL)

        os.symlink(output,preali_rot_SL)


def run_MPI_filter( work_directory, series, finalize=False ):

    myrank = mpi4py.MPI.COMM_WORLD.Get_rank()
    nprocs = mpi4py.MPI.COMM_WORLD.Get_size()
    procnm = mpi4py.MPI.Get_processor_name()
    
    for serie in series:

        angle = serie.getFilteringAngle()
        
        angle = ANGLE_SIGN*numpy.degrees(angle)

        if not serie.enabled: continue
        if not serie.input in ['st','preali']: continue
        
        ntilts = serie.numberOfExposures()
        depth = float(ntilts)
        block = math.ceil(depth/nprocs)
        
        sec_start = myrank*block
        sec_stop = min((myrank+1)*block,ntilts)-1
        
        log.info('Filter serie %s at angle %f from %s file.' %(serie.basename, angle, serie.input))

        if serie.input=='st':
            base = serie.basename + '.st'
        elif serie.input=='preali':
            base = serie.basename + '.preali'
            
        src = os.path.join(serie.directory, base)
        input = os.path.join(work_directory, base + '.%i' %myrank)
        output = os.path.join(work_directory, base + '.SL.%i' %myrank)
            
        command = 'newstack -secs %i-%i %s %s' %(sec_start,sec_stop,src,input)
        os.system(command)

        txbr.prefil.filter(input,output,angle)
        
        
def finalize_MPI_filter( work_directory, series, nprocs, doClean=False ):
    
    log.info('Finalize filters')
    
    for serie in series:

        if not serie.enabled: continue
        if not serie.input in ['st','preali']: continue
        
        if serie.input=='st':
            base = serie.basename + '.st'
        elif serie.input=='preali':
            base = serie.basename + '.preali'
            
        src = os.path.join(serie.directory, base)
        
        wd_base = os.path.join(work_directory, base)
            
        stacks = [ wd_base + '.%i' %i for i in range(nprocs) ]
        inputs = [ wd_base + '.SL.%i' %i for i in range(nprocs) ]
        output = wd_base + '.SL'
        
        log.info('src: %s' %src)
        log.info('wd_base: %s' %wd_base)
    
        command = 'newstack %s %s' %(" ".join(inputs),output)
        
        log.info(command)
        os.system(command)
        
        preali_rot_SL = os.path.join(work_directory, serie.basename + '.preali.rot.SL')

        if os.path.lexists(preali_rot_SL):
            os.unlink(preali_rot_SL)

        log.info('Link %s to %s' %(preali_rot_SL,output))

        os.symlink(output,preali_rot_SL)
        
        if doClean:
            for file in stacks: os.remove(file)
            for file in inputs: os.remove(file)


def main():
    '''Main routine for this pitch calculation module'''

    try:
        opts, args = getopt.getopt(  \
                 sys.argv[1:], \
                 "hd:b:", \
                 ["help","directory=","basenames=","wd=","mpi","finalize-mpi=","doClean","doPlot"]
                    )
    except getopt.GetoptError, err:
        print str(err)
        usage()
        sys.exit(2)

    directory = None
    work_directory = None
    basenames = None
    
    run_MPI = False
    run_finalize_MPI = False

    doClean = False
    doPlot = False

    for option_,value_ in opts:
        if option_ in ("-h", "--help"):
            usage()
            sys.exit()
        elif option_ in ("-d"):
            directory = value_
        elif option_ in ("--wd"):
            work_directory = value_
        elif option_ in ("-b","--basenames"):
            basenames = value_.split(',')
        elif option_ in ("--mpi"):
            run_MPI = True
        elif option_ in ("--finalize-mpi"):
            run_finalize_MPI = True
            nprocs = int(value_)
        elif option_ in ("--doPlot"):
            doPlot = True
        elif option_ in ("--doClean"):
            doClean = True
        else:
            assert False, "unhandled option"

    if basenames==None:
        usage()
        sys.exit()

    if directory==None:
        directory = '.'

    if work_directory==None:
        work_directory = directory
        
    basename = ",".join(basenames)
    
    directory = os.path.abspath(directory)
    work_directory = os.path.abspath(work_directory)
    
    project = txbr.TxBRproject( directory, basename, work_directory=work_directory )
    project.load()

    if run_MPI:
        run_MPI_filter( work_directory, project.series )
    elif run_finalize_MPI:
        finalize_MPI_filter( work_directory, project.series, nprocs,doClean )
    else:
        run_filter( work_directory, project.series )
    
    
main()
