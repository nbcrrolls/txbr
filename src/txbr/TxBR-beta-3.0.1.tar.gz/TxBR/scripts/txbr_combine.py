#!/usr/bin/python

import sys,os.path,getopt

import logging.config

from txbr import LOG_CONF
logging.config.fileConfig(LOG_CONF)

log = logging.getLogger()

def combine(directory,inputs,output):

    command = os.path.join(os.environ['TXBR'],'util','icombine')
    args = "-i " + " 1 ".join(inputs) + " 1" + " -d " + directory + " -o " + output;

    print command + ' ' + args
    os.system(command + ' ' + args)


def crossvalidate(directory,inputs,output):

    print directory
    print inputs
    print output

    command = os.path.join(os.environ['TXBR'],'util','crossval')
    args = "-rm -i " + " ".join(inputs) + " -d " + directory + " -o " + output;

    os.system(command + ' ' + args)


def usage():

    print "Usage: %s option -i inputs" % sys.argv[0]


def main():

    try:
        option = sys.argv[1]
        opts, args = getopt.getopt(sys.argv[2:],
            "d:i:o:",["help","directory=","input=","output="])
    except getopt.GetoptError, err:
        # print help information and exit:
        print str(err) # will print something like "option -a not recognized"
        usage()
        sys.exit(2)
    except:
        usage()
        sys.exit(2)

    directory = '.'
    inputs = []
    output = None

    for option_,value in opts:
        if option_ in ("-h", "--help"):
            usage()
            sys.exit()
        elif option_ in ("-d","--directory"):
            directory = value
        elif option_ in ("-i","--input"):
            inputs = value.split(',')
            inputs = [file for file in inputs if os.path.exists(file)]
            print inputs
        elif option_ in ("-o","--output"):
            output = value
        else:
            assert False, "unhandled option"

    if len(inputs)==0:
        usage()
        raise SystemExit

    if option=='crossval':
        crossvalidate(directory,inputs,output)
    elif option=='combine':
        combine(directory,inputs,output)


main()
