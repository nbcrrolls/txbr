#!/usr/bin/python

import sys,os,math,getopt,time
import logging,logging.config
import modl,txbr.utilities
import numpy

from txbr import LOG_CONF
logging.config.fileConfig(LOG_CONF)

log = logging.getLogger()

def usage():

    print
    print "Usage: %s -b basenames [Options]" % os.path.basename(sys.argv[0])
    print
    print "    -d directory (default .)"
    print "        Name of the directory containing the input files (.fid and .txbr)"
    print "    --wd work_directory (default .)"
    print "        Name of the directory where output files will be stored"
    print "    -m model (basename.3dpkmod)"
    print "        Name of the model file that contains locations of the 3D markers"
    print "    --offset xoff,yoff,zoff"
    print "        Offset to add in the x,y and z directions"
    print


def main():

    try:
        opts, args = getopt.getopt(sys.argv[1:],
            "hd:w:m:b:",
            ["help","directory=","basenames=","wd=","offset="]
            )
    except getopt.GetoptError, err:    # print help information and exit:
        print str(err) # print something like "option -a not recognized"
        usage()
        sys.exit(2)

    directory = None
    basenames = None
    wdirectory = None
    XYZ_filename = None
    offset = [0.0,0.0,0.0]

    for option,value in opts:
        if option in ("-h", "--help"):
            usage()
            sys.exit()
        elif option in ("-d","--directory"):
            directory = value
        elif option in ("-b","--basenames"):
            basenames = value.split(',')
        elif option in ("--wd"):
            wdirectory = value
        elif option in ("-m"):
            XYZ_filename = value
        elif option in ("--offset"):
            offset = [float(v) for v in value.split(',')]
        else:
            assert False, "unhandled option"

    if basenames==None:
        usage()
        sys.exit(2)

    if directory==None:
        directory = '.'

    if wdirectory==None:
        wdirectory = '.'

    if XYZ_filename==None:
        XYZ_filename = os.path.join(directory,'%s.3dpkmod' %txbr.utilities.extract_series_name(basenames)[0])
        if not os.path.lexists(XYZ_filename):
            sys.exit('There is no 3D marker file (%s)!' %XYZ_filename)

    basename = ','.join(basenames)

    # Load the TxBR project

    project = txbr.TxBRproject(directory,basename)
    project.load()

    rotation = project.reconstruction.getRotation()

    print 'Load 3D points from %s' %(XYZ_filename)

    model = modl.Model(XYZ_filename)
    model.loadFromFile()

    XYZ = model.points()

    XYZ[:,0] += offset[0]
    XYZ[:,1] += offset[1]
    XYZ[:,2] += offset[2]

    XYZ = numpy.tensordot(XYZ,rotation,(1,0))    # Reorient the fiducials

    nseries = project.numberOfSeries()
    px,py = [],[]

    for s in project.series:

        ntilt = s.numberOfExposures()
        projmap = s.projection
        print 'Series %s: %i exposures' %(s.basename,ntilt)

        model_name = os.path.join(directory,'%s_test.mod' %(s.basename))
        template_name = os.path.join(directory,'%s.fid' %(s.basename))

        if not os.path.lexists(template_name):
            sys.exit('There is no template file (%s)!' %template_name)

        template = modl.Model(template_name)
        template.loadFromFile()

        model = modl.Model(model_name,template=template)

        o = model.addNewObject()

        for pt in XYZ:
            contour = o.addNewContour()
            for itilt in range(ntilt):
                x = projmap.x(pt[0],pt[1],pt[2],itilt)
                y = projmap.y(pt[0],pt[1],pt[2],itilt)
                contour.addPoint(x,y,itilt)

        model.save()

main()


