#!/usr/bin/python

import os

def main(directory):
    
    var = raw_input("Are you sure? (Y or N): ")
    if var!='Y': 
        return
    
    files = os.listdir(directory)
    
    for file in files:
        
        if file.endswith('.preali'): continue
        if file.endswith('.fid'): continue
        if file.endswith('.rawtlt'): continue
        if file.endswith('.contmod'): continue
        if file.endswith('.pbs'): continue
        if file.endswith('.py'): continue
        
        if os.path.isdir(file)==True: 
            if file=='txbr-align' or file=='txbr-filter' or file=='txbr-setup' or file=='txbr-backprojection': 
                for f in os.listdir(file):
                    os.remove(os.path.join(file,f))
                os.rmdir(file)
            continue
        
        os.remove(file)
        
main('.')