"""
.. `mrc-label`:

The package **mrc** allows to manipulate MRC files. It defines in partculare a class called *MRCFile*
for this purpose.

"""

from mrc import *
from mrcutil import *
from vimrc import *
from mrcfile import *
