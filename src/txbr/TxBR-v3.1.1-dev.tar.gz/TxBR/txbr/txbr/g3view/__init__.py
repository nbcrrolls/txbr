"""
Utility package for processing the 3view data.

.. automodule:: txbr.g3view.threeview
   :members:

"""

from threeview import *
