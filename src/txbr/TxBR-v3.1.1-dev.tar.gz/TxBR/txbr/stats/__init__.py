"""stats -- Stats package.

Package allowing to do some extra specific analysis.
"""

from ordering import *
from statsplot import *
from crystal import *