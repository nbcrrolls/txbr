"""misc -- Miscellaneous package.

Define power sequences in space of dimension less than 3.

numberOfTerms(approximationOrder,dim=3):
powerOrder(approximationOrder,dim=3):
"""
