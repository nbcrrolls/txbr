/*
 *  imodi.h -- Main IMOD image library header.
 */

#ifndef IMODI_H
#define IMODI_H
#include "iimage.h"

#include "mrcfiles.h"
#include "mrcslice.h"

#endif
