#ifndef EDGETAPER_2D
#define EDGETAPER_2D

#include "utilities.h"

void edgetaper_2D(IplImage *image, int edge_width);

#endif // EDGETAPER_2D
