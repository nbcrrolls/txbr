package etomo.comscript;
/**
* <p>Description: </p>
* 
* <p>Copyright: Copyright (c) 2006</p>
*
* <p>Organization:
* Boulder Laboratory for 3-Dimensional Electron Microscopy of Cells (BL3DEMC),
* University of Colorado</p>
* 
* @author $Author$
* 
* @version $Revision$
* 
* <p> $Log$
* <p> Revision 1.1  2006/04/06 18:58:22  sueh
* <p> bug# 808 Interface for the Fields inner classes.  Used by ProcessDetails
* <p> for generically retrieving data.
* <p> </p>
*/
public interface Field {
  public static  final String  rcsid =  "$Id$";
}
/**
* <p> $Log$
* <p> Revision 1.1  2006/04/06 18:58:22  sueh
* <p> bug# 808 Interface for the Fields inner classes.  Used by ProcessDetails
* <p> for generically retrieving data.
* <p> </p>
*/