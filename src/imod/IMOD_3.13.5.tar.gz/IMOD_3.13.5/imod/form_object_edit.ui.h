/****************************************************************************
** ui.h extension file, included from the uic-generated form implementation.
**
** If you wish to add, delete or rename slots use Qt Designer which will
** update this file, preserving your code. Create an init() slot in place of
** a constructor, and a destroy() slot in place of a destructor.
*****************************************************************************/

// Respond to signals from the widgets
void objectEditForm::helpPressed()
{
    ioew_help();
}

void objectEditForm::nameChanged( const QString & newName )
{
    ioew_nametext(newName.latin1());
}

void objectEditForm::symbolChanged( int value )
{
    ioew_symbol(value);
}

void objectEditForm::OKPressed()
{
    ioew_quit();
}

void objectEditForm::radiusChanged(int value)
{
    ioew_pointsize(value);
}

void objectEditForm::ptLimitChanged( int value )
{
  ioew_pointLimit(value);
}

void objectEditForm::selectedSurface( int value )
{
    ioew_surface(value);
}

void objectEditForm::selectedType( int value )
{
    ioew_open(value);
}

void objectEditForm::sizeChanged( int value )
{
    QString str;
    str.sprintf("%d", value);
    sizeLabel->setText(str);
    ioew_symsize(value);
}

void objectEditForm::toggledDraw( bool state )
{
    ioew_draw(state ? 1 : 0);
}

void objectEditForm::toggledFill( bool state )
{
    ioew_fill(state ? 1 : 0);
}

void objectEditForm::toggledMarkEnds( bool state )
{
    ioew_ends(state ? 1 : 0);
}

void objectEditForm::toggledTime( bool state )
{
    ioew_time(state ? 1 : 0);
}

void objectEditForm::toggledOnSection( bool state )
{
  ioew_sphere_on_sec(state ? 1 : 0);
}

void objectEditForm::widthChanged( int value )
{
     ioew_linewidth(value);
}	

void objectEditForm::toggledPlanar( bool state )
{
  ioew_planar(state ? 1 : 0);
}

// Set the state of the widgets initially or when a new object is selected
void objectEditForm::setSymbolProperties( int which, bool fill, bool markEnds, int size )
{
   symbolComboBox->setCurrentItem(which);
   diaSetChecked(fillCheckBox, fill);
   diaSetChecked(markCheckBox, markEnds);
    diaSetSlider(sizeSlider, size);
    QString str;
    str.sprintf("%d", size);
    sizeLabel->setText(str);
}

void objectEditForm::setDrawBox( bool state )
{
    diaSetChecked(drawCheckBox, state);
}

void objectEditForm::setObjectName( char *name )
{
    QString str = name;
    diaSetEditText(nameEdit, str);
}

void objectEditForm::setTimeBox( bool state, bool enabled )
{
    diaSetChecked(timeCheckBox, state);
    timeCheckBox->setEnabled(enabled);
}

void objectEditForm::setOnSecBox( bool state )
{
  diaSetChecked(onSecCheckBox, state);
}

void objectEditForm::setPointRadius( int value )
{
    diaSetSpinBox(radiusSpinBox, value);
}

void objectEditForm::setFrontSurface( int value )
{
    diaSetGroup(surfaceButtonGroup, value);
}

void objectEditForm::setObjectType( int value )
{
    diaSetGroup(typeButtonGroup, value);
}

void objectEditForm::setLineWidth( int value )
{
    diaSetSpinBox(widthSpinBox, value);
}

void objectEditForm::setPlanarBox( bool state, bool enabled )
{
  diaSetChecked(planarCheckBox, state);
  planarCheckBox->setEnabled(enabled);
}

void objectEditForm::setPointLimit( int value )
{
  diaSetSpinBox(ptsPerContSpinBox, value);
}

// Handle close event; pass on keypress
void objectEditForm::closeEvent( QCloseEvent *e )
{
    ioew_closing();
    e->accept();
}

void objectEditForm::keyPressEvent( QKeyEvent * e )
{
    if (e->key() == Qt::Key_Escape)
	ioew_quit();
    else
	ivwControlKey(0, e);
    //e->ignore();
}

void objectEditForm::keyReleaseEvent( QKeyEvent * e )
{
    ivwControlKey(1, e);
}
