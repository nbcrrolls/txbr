package etomo.storage;

import java.io.File;

import etomo.storage.autodoc.AutodocFactory;

/**
 * <p>Description: </p>
 * 
 * <p>Copyright: Copyright (c) 2005</p>
 *
 * <p>Organization:
 * Boulder Laboratory for 3-Dimensional Electron Microscopy of Cells (BL3DEM),
 * University of Colorado</p>
 * 
 * @author $Author: sueh $
 * 
 * @version $Revision: 8966dd95f1cb $
 */

public class AutodocFilter extends javax.swing.filechooser.FileFilter implements
    java.io.FileFilter {
  public static final String rcsid = "$Id: AutodocFilter.java,v 8966dd95f1cb 2013/05/30 21:57:07 sueh $";

  public boolean accept(File f) {
    if (!f.exists()) {
      System.err.println("Warning: " + f.getAbsolutePath() + " does not exist");
      return false;
    }
    if (f.isFile()) {
      return f.getName().endsWith(AutodocFactory.EXTENSION);
    }
    return true;
  }

  public String getDescription() {
    return "Autodoc file";
  }
}
/**
 * <p> $Log$
 * <p> Revision 1.1  2005/12/23 02:06:08  sueh
 * <p> bug# 675 Added a filter to find autodoc files.
 * <p> </p>
 */
