package etomo.process;

/**
* <p>Description: </p>
* 
* <p>Copyright: Copyright 2012</p>
*
* <p>Organization:
* Boulder Laboratory for 3-Dimensional Electron Microscopy of Cells (BL3DEMC),
* University of Colorado</p>
* 
* @author $Author: sueh $
* 
* @version $Revision: 9592d4074940 $
* 
* <p> $Log$ </p>
*/
interface Monitor extends Runnable {
  public static final String rcsid = "$Id:$";

  public boolean isPausing();

  public void setWillResume();
}
