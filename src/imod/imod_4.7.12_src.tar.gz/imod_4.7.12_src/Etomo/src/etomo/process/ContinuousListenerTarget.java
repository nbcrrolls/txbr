package etomo.process;

import etomo.type.AxisID;

/**
* <p>Description: </p>
* 
* <p>Copyright: Copyright 2008</p>
*
* <p>Organization:
* Boulder Laboratory for 3-Dimensional Electron Microscopy of Cells (BL3DEMC),
* University of Colorado</p>
* 
* @author $Author: sueh $
* 
* @version $Revision: 1378df96b492 $
* 
* <p> $Log$ </p>
*/
public interface ContinuousListenerTarget {
  public static  final String  rcsid =  "$Id: ContinuousListenerTarget.java,v 1378df96b492 2009/03/23 16:54:53 sueh $";
  
  public void getContinuousMessage(String message, AxisID axisID);
}
