package etomo.process;

/**
 * <p>Description: </p>
 * 
 * <p>Copyright: Copyright 2006</p>
 *
 * <p>Organization:
 * Boulder Laboratory for 3-Dimensional Electron Microscopy of Cells (BL3DEMC),
 * University of Colorado</p>
 * 
 * @author $Author: sueh $
 * 
 * @version $Revision: 9fe9078114cd $
 * 
 * <p> $Log$ </p>
 */
public final class UncaughtException {
  public static final String rcsid = "$Id: UncaughtException.java,v 9fe9078114cd 2006/10/11 10:12:46 sueh $";

  public static final UncaughtException INSTANCE = new UncaughtException();

  private Throwable throwable = null;

  private UncaughtException() {
  }

  public void setThrowable(Throwable throwable) {
    this.throwable = throwable;
  }

  public String getThrowableString() {
    String message = null;
    synchronized (this) {
      if (throwable != null) {
        message = throwable.getMessage();
        throwable = null;
      }
    }
    return message;
  }
}
