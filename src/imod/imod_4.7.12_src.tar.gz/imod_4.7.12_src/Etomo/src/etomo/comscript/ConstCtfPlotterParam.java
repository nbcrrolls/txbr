package etomo.comscript;

import etomo.type.ConstEtomoNumber;
import etomo.type.ConstStringParameter;

/**
* <p>Description: </p>
* 
* <p>Copyright: Copyright 2008</p>
*
* <p>Organization:
* Boulder Laboratory for 3-Dimensional Electron Microscopy of Cells (BL3DEMC),
* University of Colorado</p>
* 
* @author $Author: sueh $
* 
* @version $Revision: d719fa592547 $
* 
* <p> $Log$ </p>
*/
public interface ConstCtfPlotterParam {
  public static  final String  rcsid =  "$Id: ConstCtfPlotterParam.java,v d719fa592547 2011/11/18 20:49:30 sueh $";
  
  public ConstStringParameter getConfigFile();
  public ConstEtomoNumber getExpectedDefocus();
  public ConstEtomoNumber getOffsetToAdd();
}
