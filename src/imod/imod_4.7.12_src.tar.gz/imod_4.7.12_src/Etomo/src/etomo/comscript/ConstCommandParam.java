package etomo.comscript;

/**
 * <p>Description: </p>
 *
 * <p>Copyright: Copyright (c) 2004</p>
 *
 * <p>Organization:
 * Boulder Laboratory for 3-Dimensional Electron Microscopy of Cells (BL3DEM),
 * University of Colorado</p>
 *
 * @author $$Author: sueh $$
 *
 * @version $$Revision: acb6e0d37364 $$
 *
 * <p> $$Log$$ </p>
 */
public interface ConstCommandParam {
  public static final String rcsid = "$$Id: ConstCommandParam.java,v acb6e0d37364 2004/05/03 17:59:54 sueh $$";
  
  public boolean isParseComments();
  public String getProcessNameString();
  public String getCommand();
}
