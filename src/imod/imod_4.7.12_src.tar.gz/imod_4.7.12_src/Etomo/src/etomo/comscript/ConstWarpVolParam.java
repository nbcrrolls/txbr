package etomo.comscript;

/**
 * <p>Description: </p>
 * 
 * <p>Copyright: Copyright 2008</p>
 *
 * <p>Organization:
 * Boulder Laboratory for 3-Dimensional Electron Microscopy of Cells (BL3DEMC),
 * University of Colorado</p>
 * 
 * @author $Author: sueh $
 * 
 * @version $Revision: 24b4dfd78f32 $
 * 
 * <p> $Log$
 * <p> Revision 1.1  2009/06/05 01:46:19  sueh
 * <p> bug# 1219 Constant interface for WarpVolParam.
 * <p> </p>
 */
public interface ConstWarpVolParam extends Command {
  public static final String rcsid = "$Id: ConstWarpVolParam.java,v 24b4dfd78f32 2010/04/28 16:00:40 sueh $";

  public String getTemporaryDirectory();

  public String getOutputSizeZ();

  public boolean isInterpolationOrderLinear();
}
