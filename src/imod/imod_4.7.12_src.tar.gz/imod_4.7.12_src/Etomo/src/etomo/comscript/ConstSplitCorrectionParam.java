package etomo.comscript;

/**
 * <p>Description: </p>
 * 
 * <p>Copyright: Copyright 2008</p>
 *
 * <p>Organization:
 * Boulder Laboratory for 3-Dimensional Electron Microscopy of Cells (BL3DEMC),
 * University of Colorado</p>
 * 
 * @author $Author: sueh $
 * 
 * @version $Revision: 0e2552a401be $
 * 
 * <p> $Log$ </p>
 */
public interface ConstSplitCorrectionParam {
  public static final String rcsid = "$Id: ConstSplitCorrectionParam.java,v 0e2552a401be 2008/10/27 17:45:22 sueh $";

  public String[] getCommand();
}
