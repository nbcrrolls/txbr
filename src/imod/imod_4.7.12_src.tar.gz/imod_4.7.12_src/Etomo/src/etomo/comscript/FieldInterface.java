package etomo.comscript;
/**
* <p>Description: </p>
* 
* <p>Copyright: Copyright (c) 2006</p>
*
* <p>Organization:
* Boulder Laboratory for 3-Dimensional Electron Microscopy of Cells (BL3DEMC),
* University of Colorado</p>
* 
* @author $Author: sueh $
* 
* @version $Revision: 6b7bf2d8be44 $
* 
* <p> $Log$
* <p> Revision 1.1  2007/12/13 01:04:39  sueh
* <p> bug# 1038 Switching to html files for midas help.
* <p>
* <p> Revision 1.1  2006/04/06 18:58:22  sueh
* <p> bug# 808 Interface for the Fields inner classes.  Used by ProcessDetails
* <p> for generically retrieving data.
* <p> </p>
*/
public interface FieldInterface {
  public static  final String  rcsid =  "$Id: FieldInterface.java,v 6b7bf2d8be44 2009/09/01 03:18:33 sueh $";
}
/**
* <p> $Log$
* <p> Revision 1.1  2007/12/13 01:04:39  sueh
* <p> bug# 1038 Switching to html files for midas help.
* <p>
* <p> Revision 1.1  2006/04/06 18:58:22  sueh
* <p> bug# 808 Interface for the Fields inner classes.  Used by ProcessDetails
* <p> for generically retrieving data.
* <p> </p>
*/