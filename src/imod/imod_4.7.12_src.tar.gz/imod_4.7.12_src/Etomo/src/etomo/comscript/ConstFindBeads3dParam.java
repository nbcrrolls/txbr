package etomo.comscript;

import etomo.type.ConstEtomoNumber;

/**
 * <p>Description: </p>
 * 
 * <p>Copyright: Copyright 2009</p>
 *
 * <p>Organization:
 * Boulder Laboratory for 3-Dimensional Electron Microscopy of Cells (BL3DEMC),
 * University of Colorado</p>
 * 
 * @author $Author: sueh $
 * 
 * @version $Revision: 6b7bf2d8be44 $
 * 
 * <p> $Log$ </p>
 */
public interface ConstFindBeads3dParam extends CommandDetails{
  public static final String rcsid = "$Id: ConstFindBeads3dParam.java,v 6b7bf2d8be44 2009/09/01 03:18:33 sueh $";

  String getBeadSize();

  String getMinRelativeStrength();

  String getThresholdForAveraging();

  ConstEtomoNumber getStorageThreshold();

  String getMinSpacing();

  String getGuessNumBeads();

  String getMaxNumBeads();
}
