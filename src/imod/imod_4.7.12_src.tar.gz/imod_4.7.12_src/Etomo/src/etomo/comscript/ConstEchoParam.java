package etomo.comscript;

/**
 * <p>Description: </p>
 *
 * <p>Copyright: Copyright (c) 2004</p>
 *
 * <p>Organization: Boulder Laboratory for 3D Fine Structure,
 * University of Colorado</p>
 *
 * @author $$Author: sueh $$
 *
 * @version $$Revision: 754b4543a0ae $$
 *
 * <p> $$Log$
 * <p> $Revision 1.1  2004/08/19 01:30:31  sueh
 * <p> $Constant object for the echo command
 * <p> $$ </p>
 */

public class ConstEchoParam {
  public static final String rcsid = "$$Id: ConstEchoParam.java,v 754b4543a0ae 2011/02/21 21:27:33 sueh $$";

  public static final String COMMAND_NAME = "echo";

  protected StringBuffer string;

  public ConstEchoParam() {
    reset();
  }

  protected void reset() {
    string = new StringBuffer();
  }

  /**
   * @return String
   */
  public String getString() {
    return string.toString();
  }

}
