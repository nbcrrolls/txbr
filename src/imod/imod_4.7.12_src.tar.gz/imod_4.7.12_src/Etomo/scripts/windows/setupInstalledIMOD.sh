export IMOD_DIR="C:\\cygwin\\usr\\local\\IMOD-64"
source "${IMOD_DIR}\\IMOD-cygwin.sh"
echo IMOD_DIR=$IMOD_DIR
